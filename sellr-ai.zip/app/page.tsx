import Form from "@/components/Form";

export default function Home() {
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: 40 }}>
      <h1 style={{ fontSize: 48 }}>
        Turn any product into a sales machine.
      </h1>

      <p style={{ fontSize: 20, opacity: 0.7 }}>
        Generate high-converting product descriptions in seconds.
      </p>

      <Form />

      <section style={{ marginTop: 80 }}>
        <h2>Why it works</h2>
        <ul>
          <li>Emotion-driven copy</li>
          <li>Conversion-focused structure</li>
          <li>Built for ecommerce</li>
        </ul>
      </section>

      <section style={{ marginTop: 80 }}>
        <h2>Pricing</h2>
        <p>Free: 10 generations</p>
        <p>Pro: $19/month</p>
      </section>
    </main>
  );
}