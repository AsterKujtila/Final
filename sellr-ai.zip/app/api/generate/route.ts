import { NextResponse } from "next/server";
import { client } from "@/lib/ai";

export async function POST(req: Request) {
  try {
    const { product, audience, price } = await req.json();

    if (!product) {
      return NextResponse.json({ error: "Missing product" }, { status: 400 });
    }

    const prompt = `
Write a HIGH-CONVERTING ecommerce product page.

Product: ${product}
Audience: ${audience}
Price: ${price}

Include:
- Headline
- Emotional hook
- Bullet benefits
- CTA

Make it sound like a premium Shopify brand.
`;

    const res = await client.messages.create({
      model: "claude-3-haiku-20240307",
      max_tokens: 400,
      messages: [{ role: "user", content: prompt }],
    });

    return NextResponse.json({
      output: res.content[0]?.text || "No result",
    });
  } catch (e) {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}