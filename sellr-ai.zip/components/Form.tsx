"use client";

import { useState } from "react";

export default function Form() {
  const [product, setProduct] = useState("");
  const [audience, setAudience] = useState("");
  const [price, setPrice] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    setLoading(true);
    setResult("");

    const res = await fetch("/api/generate", {
      method: "POST",
      body: JSON.stringify({ product, audience, price }),
    });

    const data = await res.json();
    setResult(data.output || data.error);

    setLoading(false);
  };

  return (
    <div style={{ marginTop: 40 }}>
      <input placeholder="Product" onChange={(e) => setProduct(e.target.value)} />
      <input placeholder="Audience" onChange={(e) => setAudience(e.target.value)} />
      <input placeholder="Price range" onChange={(e) => setPrice(e.target.value)} />

      <button onClick={generate}>
        {loading ? "Generating..." : "Generate"}
      </button>

      <pre>{result}</pre>
    </div>
  );
}