const BASE_SYSTEM_PROMPT = `
You are MindCore, a warm, grounded therapy-style AI companion.
You respond in a calm, direct, non-clinical tone and focus on what matters most to the user right now.
You avoid generic platitudes and instead help the user notice patterns, name feelings, and find small next steps.
Keep answers concise and conversational, usually 2–5 short paragraphs.
`.trim()

export interface RecentMemory {
  summary: string
  memory_score: number
}

export interface BuildSystemPromptParams {
  latestMessage: string
  emotionScore: number
  crisisScore: number
  recentMemories: RecentMemory[]
  baseSystemPromptOverride?: string
}

export interface BuildSystemPromptResult {
  systemPrompt: string
  memoryInjected: boolean
}

/**
 * Build a system prompt that optionally injects user memory as bullet points.
 */
export function buildSystemPromptWithMemory(
  params: BuildSystemPromptParams
): BuildSystemPromptResult {
  const {
    latestMessage = "",
    emotionScore = 0,
    crisisScore = 0,
    recentMemories = [],
    baseSystemPromptOverride,
  } = params || ({} as BuildSystemPromptParams)

  const safeLatest = String(latestMessage || "")
  const safeEmotion = Number(emotionScore) || 0
  const safeCrisis = Number(crisisScore) || 0
  const safeMemories = Array.isArray(recentMemories) ? recentMemories : []

  const basePrompt = (baseSystemPromptOverride || BASE_SYSTEM_PROMPT).trim()
  const hasMemories = safeMemories.length > 0

  // Condition 1: crisis or emotion thresholds
  const crisisOrEmotionHigh = safeCrisis >= 0.2 || safeEmotion >= 0.3

  // Condition 2: user references the past
  const lowerMsg = safeLatest.toLowerCase()
  const referencesPast = /\b(again|before|same|still)\b/.test(lowerMsg)

  // Condition 3: any memory_score ≥ 0.5
  const hasHighScoreMemory = safeMemories.some((m) => {
    const score = Number(m && (m as any).memory_score)
    return !Number.isNaN(score) && score >= 0.5
  })

  let shouldInject =
    hasMemories && (crisisOrEmotionHigh || referencesPast || hasHighScoreMemory)

  let memorySection = ""
  let memoryInjected = false

  if (shouldInject) {
    const sorted = safeMemories
      .filter(
        (m) =>
          m &&
          typeof (m as any).summary === "string" &&
          (m as any).summary.trim().length > 0
      )
      .map((m) => ({
        summary: (m as any).summary.trim(),
        score: Number((m as any).memory_score) || 0,
      }))
      .sort((a, b) => b.score - a.score)

    if (sorted.length === 0) {
      shouldInject = false
    } else {
      const selected = sorted.slice(0, 5)
      const limited = selected // if fewer than 3 exist, use what we have

      const bulletLines = limited.map((m) => `- ${m.summary}`)

      memorySection =
        "\n\nRelevant context about the user (use only if clearly helpful):\n" +
        bulletLines.join("\n")

      memoryInjected = bulletLines.length > 0
    }
  }

  const systemPrompt = memoryInjected
    ? `${basePrompt}\n${memorySection}`
    : basePrompt

  return { systemPrompt, memoryInjected }
}

