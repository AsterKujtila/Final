/**
 * Shared chat completion: router + system prompt + optional memory + OpenAI.
 * Used by POST /api/chat and by start-insight / start-reflection.
 */
import OpenAI from "openai"
import { routeMessage, type Route } from "@/lib/chat-router"
import { CRISIS_SYSTEM_PROMPT } from "@/lib/crisis-prompt"
import { getEmbedding, queryMemory } from "@/lib/vector-memory"
import {
  buildSystemPromptWithMemory,
  type RecentMemory,
} from "@/lib/build-system-prompt-with-memory"

const CBT_MODEL = "ft:gpt-3.5-turbo-1106:rehalm:mindcore-v1:DArkDbVX"
const CRISIS_MODEL = "ft:gpt-3.5-turbo-1106:rehalm:crisis-mindcore:DDfn17lT"
const TEMPERATURE = 0.5
const MAX_TOKENS = 350
const MEMORY_TOP_K = 3

// Paste your CBT system prompt here (same as in chat route).
const CBT_SYSTEM_PROMPT = ""

export interface GetChatReplyParams {
  messages: { role: string; content: string }[]
  reflectionContext?: string | null
  userId?: string | null
  sessionId?: string | null
}

export interface GetChatReplyResult {
  content: string
  route: Route
}

export async function getChatReply(params: GetChatReplyParams): Promise<GetChatReplyResult> {
  const { messages, reflectionContext, userId, sessionId } = params
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return { content: "I'm here. Could you say a bit more?", route: "CBT" }
  }

  const lastUserMessage = [...messages].reverse().find((m) => m.role === "user" && m.content?.trim())
  const lastUserText = lastUserMessage?.content?.trim() ?? ""

  const { route, confidence } = await routeMessage(lastUserText)
  const openai = new OpenAI({ apiKey })

  const baseSystem =
    route === "Crisis"
      ? CRISIS_SYSTEM_PROMPT
      : CBT_SYSTEM_PROMPT || "" // fall back to generic in builder
  let systemContent = baseSystem

  const reflectionBlock =
    typeof reflectionContext === "string" && reflectionContext.trim()
      ? `The user is coming from their weekly reflection. Use this as context to discuss how to fix things and support them. Do not repeat the reflection verbatim.\n\nWeekly reflection:\n${reflectionContext.trim()}`
      : undefined
  if (reflectionBlock) {
    systemContent = systemContent ? `${systemContent}\n\n${reflectionBlock}` : reflectionBlock
  }

  if (route === "CBT" && userId && sessionId && messages.length > 1 && lastUserText) {
    try {
      const queryEmbedding = await getEmbedding(lastUserText)
      const matches = await queryMemory(userId, queryEmbedding, MEMORY_TOP_K)

      const recentMemories: RecentMemory[] = (matches ?? []).map((m) => ({
        summary: m.text,
        memory_score: typeof (m as any).score === "number" ? (m as any).score : 0,
      }))

      // Use router confidence as a proxy crisis score (Crisis => confidence, CBT => 0).
      const crisisScore = route === "Crisis" ? confidence : 0
      const emotionScore = 0 // Placeholder until an emotion model is wired in.

      const { systemPrompt } = buildSystemPromptWithMemory({
        latestMessage: lastUserText,
        emotionScore,
        crisisScore,
        recentMemories,
        baseSystemPromptOverride: systemContent || undefined,
      })

      systemContent = systemPrompt
    } catch (err) {
      console.error("Memory retrieval failed:", err)
    }
  }

  const openaiMessages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
    ...(systemContent
      ? [{ role: "system" as const, content: systemContent }]
      : []),
    ...messages.map((m) => ({
      role: (m.role === "assistant" ? "assistant" : "user") as "user" | "assistant",
      content: m.content,
    })),
  ]

  const model = route === "Crisis" ? CRISIS_MODEL : CBT_MODEL
  const completion = await openai.chat.completions.create({
    model,
    messages: openaiMessages,
    temperature: TEMPERATURE,
    max_tokens: MAX_TOKENS,
  })
  const content = completion.choices[0]?.message?.content?.trim() ?? "I'm here. Could you say a bit more?"
  return { content, route }
}
