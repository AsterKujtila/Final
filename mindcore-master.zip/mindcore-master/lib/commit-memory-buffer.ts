import type { SupabaseClient } from "@supabase/supabase-js"
import { upsertMemory } from "@/lib/vector-memory"

const STRENGTH_THRESHOLD = 0.5

export interface BufferRow {
  id: string
  user_id: string
  session_id: string
  memory_candidate: string
  strength_score: number
  is_crisis: boolean
}

/**
 * Load uncommitted buffer rows, filter (strength + crisis), dedupe, send each to Pinecone, set committed = true.
 * Call this from post-process (one user) or from cron (all users). Uses namespace = user_id so embeddings stay per-user.
 */
export async function commitUncommittedBufferToPinecone(
  supabase: SupabaseClient,
  options?: { userId?: string }
): Promise<{ processed: number; errors: number }> {
  let query = supabase
    .from("memory_buffer")
    .select("id, user_id, session_id, memory_candidate, strength_score, is_crisis")
    .eq("committed", false)
    .order("created_at", { ascending: true })

  if (options?.userId) {
    query = query.eq("user_id", options.userId)
  }

  const { data: bufferRows } = await query
  const rows = (bufferRows ?? []) as BufferRow[]

  const candidates = rows.filter(
    (r) =>
      r.memory_candidate?.trim() &&
      r.strength_score >= STRENGTH_THRESHOLD &&
      !r.is_crisis
  )

  if (candidates.length === 0) {
    return { processed: 0, errors: 0 }
  }

  const sessionIds = [...new Set(candidates.map((r) => r.session_id))]
  const { data: sessions } = await supabase
    .from("chat_sessions")
    .select("id, session_date")
    .in("id", sessionIds)
  const sessionDateBySessionId = new Map<string, string>()
  const today = new Date().toISOString().slice(0, 10)
  for (const s of sessions ?? []) {
    sessionDateBySessionId.set(
      s.id,
      s.session_date != null ? String(s.session_date) : today
    )
  }

  const seenByUser = new Map<string, Set<string>>()
  const deduped: BufferRow[] = []
  for (const r of candidates) {
    const key = r.memory_candidate.trim().toLowerCase().slice(0, 200)
    let seen = seenByUser.get(r.user_id)
    if (!seen) {
      seen = new Set()
      seenByUser.set(r.user_id, seen)
    }
    if (seen.has(key)) continue
    seen.add(key)
    deduped.push(r)
  }

  let processed = 0
  let errors = 0
  for (const row of deduped) {
    try {
      const sessionDate = sessionDateBySessionId.get(row.session_id) ?? today
      await upsertMemory(row.user_id, row.id, row.memory_candidate.trim(), {
        session_date: sessionDate,
        session_id: row.session_id,
        summary: row.memory_candidate.trim().slice(0, 1000),
      })
      await supabase
        .from("memory_buffer")
        .update({ committed: true })
        .eq("id", row.id)
      processed++
    } catch (err) {
      console.error("Commit upsert failed for buffer row:", row.id, err)
      errors++
    }
  }
  return { processed, errors }
}
