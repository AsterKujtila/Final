/**
 * Vector memory (Pinecone) for per-user distilled knowledge.
 * - All embeddings are stored in a namespace = user_id. No user's data is stored collectively;
 *   each user's vectors are isolated and only queryable by that user's id.
 * - The model uses a user's embeddings anytime we call queryMemory(userId, ...) and inject
 *   the results into the system prompt (e.g. in the chat route).
 * Uses OpenAI text-embedding-3-small (1536 dims).
 */

import { Pinecone } from "@pinecone-database/pinecone"
import OpenAI from "openai"

const EMBEDDING_MODEL = "text-embedding-3-small"
const EMBEDDING_DIMENSIONS = 1536

let pineconeClient: Pinecone | null = null

function getPinecone(): Pinecone {
  if (!pineconeClient) {
    const apiKey = process.env.PINECONE_API_KEY
    if (!apiKey) throw new Error("PINECONE_API_KEY is not set")
    pineconeClient = new Pinecone({ apiKey })
  }
  return pineconeClient
}

function getIndexName(): string {
  const name = process.env.PINECONE_INDEX_NAME ?? "mindcore-memory"
  return name
}

/** Normalize host: strip protocol so SDK gets hostname only. */
function getIndexHost(): string | undefined {
  const raw = process.env.PINECONE_INDEX_HOST
  if (!raw?.trim()) return undefined
  const host = raw.trim().replace(/^https?:\/\//i, "")
  return host || undefined
}

/** Cached index instance (lazy). */
let indexInstance: ReturnType<Pinecone["index"]> | null = null

/**
 * Returns the Pinecone index (lazy init).
 * Uses PINECONE_INDEX_HOST when set (recommended); otherwise name and SDK resolves host via describeIndex.
 */
export async function getIndex() {
  if (indexInstance) return indexInstance
  const pinecone = getPinecone()
  const host = getIndexHost()
  if (host) {
    indexInstance = pinecone.index({ host })
  } else {
    const indexName = getIndexName()
    indexInstance = pinecone.index({ name: indexName })
  }
  return indexInstance
}

/**
 * Get embedding for text using OpenAI text-embedding-3-small.
 */
export async function getEmbedding(text: string): Promise<number[]> {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) throw new Error("OPENAI_API_KEY is not set")
  const openai = new OpenAI({ apiKey })
  const res = await openai.embeddings.create({
    model: EMBEDDING_MODEL,
    input: text.slice(0, 8000), // avoid overlong input
  })
  const vec = res.data[0]?.embedding
  if (!vec || vec.length !== EMBEDDING_DIMENSIONS) {
    throw new Error("Unexpected embedding response")
  }
  return vec
}

export interface UpsertMemoryMetadata {
  session_date: string
  session_id: string
  summary?: string
}

/**
 * Upsert one vector into this user's namespace only. Not stored collectively; only this user can retrieve it via queryMemory(userId, ...).
 */
export async function upsertMemory(
  userId: string,
  recordId: string,
  text: string,
  metadata: UpsertMemoryMetadata
): Promise<void> {
  const embedding = await getEmbedding(text)
  const index = await getIndex()
  await index.upsert({
    namespace: userId,
    records: [
      {
        id: recordId,
        values: embedding,
        metadata: {
          session_date: metadata.session_date,
          session_id: metadata.session_id,
          ...(metadata.summary ? { summary: metadata.summary.slice(0, 1000) } : {}),
        },
      },
    ],
  })
}

export interface MemoryMatch {
  text: string
  metadata?: Record<string, string | number | boolean>
}

/**
 * Query this user's memory only (namespace = userId). Used by the model when needed; returns only this user's stored context.
 */
export async function queryMemory(
  userId: string,
  queryEmbedding: number[],
  topK: number = 3
): Promise<MemoryMatch[]> {
  const index = await getIndex()
  const result = await index.query({
    namespace: userId,
    vector: queryEmbedding,
    topK,
    includeMetadata: true,
  })
  const matches: MemoryMatch[] = []
  for (const m of result.matches ?? []) {
    const meta = m.metadata as Record<string, unknown> | undefined
    const text = (meta?.summary as string) ?? ""
    if (text) {
      matches.push({ text, metadata: meta as Record<string, string | number | boolean> })
    }
  }
  return matches
}
