/**
 * Small model: turn summary (session-only) + memory candidate + strength score.
 * Build_plan: After selected model answers → Small model generates these → Store in Supabase buffer.
 */

import OpenAI from "openai"

const MODEL = "gpt-4o-mini"
const MAX_TOKENS = 280
const TEMPERATURE = 0.3

const SYSTEM = `You analyze one chat turn (user message + assistant reply) and output exactly three lines:
Line 1 (turn summary): One short sentence summarizing this exchange for the session only. No labels.
Line 2 (memory candidate): First decide if this turn is worth storing long-term. If nothing worth storing (chit-chat, one-off, transient), write "NONE". If yes, output exactly one short factual sentence about the user (e.g. "Lost his job", "Prefers morning exercise"). No labels.
Line 3 (strength): A number 0.0 to 1.0 indicating how strong/stable this memory candidate is (1.0 = clear fact or preference, 0.0 = nothing to store).`

export interface TurnMemoryResult {
  turn_summary: string
  memory_candidate: string
  strength_score: number
}

export async function generateTurnMemory(
  userMessage: string,
  assistantReply: string
): Promise<TurnMemoryResult> {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return {
      turn_summary: "",
      memory_candidate: "NONE",
      strength_score: 0,
    }
  }

  const openai = new OpenAI({ apiKey })
  const input = `User: ${userMessage.slice(0, 1500)}\nAssistant: ${assistantReply.slice(0, 1500)}`

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: SYSTEM },
        { role: "user", content: input },
      ],
      temperature: TEMPERATURE,
      max_tokens: MAX_TOKENS,
    })
    const text = completion.choices[0]?.message?.content?.trim() ?? ""
    const lines = text.split("\n").map((l) => l.trim()).filter(Boolean)
    const turn_summary = lines[0] ?? ""
    const memory_candidate = (lines[1] ?? "NONE").toUpperCase() === "NONE" ? "" : (lines[1] ?? "")
    const numMatch = (lines[2] ?? "0").match(/([0-9]*\.?[0-9]+)/)
    const strength_score = Math.min(1, Math.max(0, Number(numMatch?.[1] ?? 0) || 0))
    return { turn_summary, memory_candidate, strength_score }
  } catch {
    return { turn_summary: "", memory_candidate: "", strength_score: 0 }
  }
}
