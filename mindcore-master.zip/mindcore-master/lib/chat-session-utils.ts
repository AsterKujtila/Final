/**
 * Logical day: 00:00–04:59 counts as previous calendar day (5h grace after midnight).
 * Time-of-day: morning < 12:00, day 12:00–17:59, evening >= 18:00 (local).
 */

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] as const

export type TimeOfDay = "morning" | "day" | "evening"

export interface SessionDayInfo {
  sessionDate: string // YYYY-MM-DD
  dayOfWeek: string
  timeOfDay: TimeOfDay
}

/**
 * Returns the logical session date and metadata for the given time.
 * Between 00:00 and 04:59 local, the session belongs to yesterday.
 */
export function getSessionDayInfo(now: Date = new Date()): SessionDayInfo {
  const hours = now.getHours()
  const minutes = now.getMinutes()
  const isGracePeriod = hours < 5

  const date = new Date(now)
  if (isGracePeriod) {
    date.setDate(date.getDate() - 1)
  }

  const sessionDate = formatDate(date)
  const dayOfWeek = DAYS[date.getDay()]
  const timeOfDay = getTimeOfDay(now)

  return { sessionDate, dayOfWeek, timeOfDay }
}

function formatDate(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${y}-${m}-${day}`
}

function getTimeOfDay(d: Date): TimeOfDay {
  const h = d.getHours()
  if (h < 12) return "morning"
  if (h < 18) return "day"
  return "evening"
}
