/**
 * Distills raw user messages into a short, stable memory paragraph using a small model.
 * Used only in post-process (after 2h idle). Kept low-cost: gpt-4o-mini, strict max_tokens.
 */

import OpenAI from "openai"

const DISTILL_MODEL = "gpt-4o-mini"
const MAX_TOKENS = 200
const TEMPERATURE = 0.3

const DISTILL_SYSTEM = `You are a memory compressor. Given a user's chat messages (user side only), output one short paragraph (2-5 sentences, under 200 tokens) that captures only stable, long-term knowledge: preferences, recurring themes, goals, and concrete facts. Omit transient chit-chat, greetings, and one-off remarks. Be concise and factual. Output nothing else.`

/**
 * Minimum total user text length to run distillation (skip very short sessions to save cost).
 */
const MIN_USER_TEXT_LENGTH = 80

export function shouldRunDistillation(userMessagesText: string): boolean {
  return userMessagesText.trim().length >= MIN_USER_TEXT_LENGTH
}

/**
 * Returns a short distilled "memory" paragraph from raw user message text.
 * Uses gpt-4o-mini with strict max_tokens for low cost.
 */
export async function distillUserMessages(userMessagesText: string): Promise<string> {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) throw new Error("OPENAI_API_KEY is not set")

  const openai = new OpenAI({ apiKey })
  const input = userMessagesText.slice(0, 12000) // cap input length

  const completion = await openai.chat.completions.create({
    model: DISTILL_MODEL,
    messages: [
      { role: "system", content: DISTILL_SYSTEM },
      { role: "user", content: `User's messages from this session:\n\n${input}` },
    ],
    temperature: TEMPERATURE,
    max_tokens: MAX_TOKENS,
  })

  const content = completion.choices[0]?.message?.content?.trim() ?? ""
  return content
}
