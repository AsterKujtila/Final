/**
 * Router: decides CBT (main fine-tuned) vs Crisis (crisis-mindcore + prompt) and returns confidence.
 * Build_plan: User message → Router model (CBT / Crisis + confidence score).
 */

import OpenAI from "openai"

const ROUTER_MODEL = "gpt-4o-mini"
const ROUTER_MAX_TOKENS = 60
/** Only route to Crisis when confidence is at least this (reduces false positives). */
const CRISIS_CONFIDENCE_THRESHOLD = 0.6

export type Route = "CBT" | "Crisis"

export interface RouterResult {
  route: Route
  confidence: number
}

const ROUTER_SYSTEM = `You are a triage router. Given the user's latest message, decide if it is CBT or Crisis.

Crisis = urgent distress, immediate safety concern, or risk of self-harm/suicide. Examples: self-harm or suicide ideation/plan/attempt; "don't want to be here anymore"; overdose or standing on balcony; severe hopelessness ("nothing left to live for"); goodbye letters; "hurting myself"; "end things"; severe emptiness or "everyone would be better off without me"; acute crisis (just took pills, need help now).

CBT = normal reflective or therapeutic conversation. Examples: general mood, daily stress, non-urgent worries, reflection on the week, goals, relationships without immediate safety risk, "had a rough day", "feeling anxious about work".

Reply with exactly two lines:
Line 1: CBT or Crisis (only one word)
Line 2: A number 0.0 to 1.0 (your confidence in that choice).

Examples:
User: I had a rough week at work and I'm not sure how to set boundaries.
CBT
0.85

User: I don't want to be here anymore. I'm so tired of everything.
Crisis
0.95

User: I've been feeling a bit down lately, wanted to talk it through.
CBT
0.9

User: I keep having thoughts about hurting myself and I can't make them stop.
Crisis
0.98`

/**
 * Returns route (CBT or Crisis) and confidence in [0, 1].
 * Crisis is only returned when confidence >= CRISIS_CONFIDENCE_THRESHOLD.
 */
export async function routeMessage(lastUserMessage: string): Promise<RouterResult> {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) return { route: "CBT", confidence: 0.5 }

  const openai = new OpenAI({ apiKey })
  const input = lastUserMessage.slice(0, 2000)

  try {
    const completion = await openai.chat.completions.create({
      model: ROUTER_MODEL,
      messages: [
        { role: "system", content: ROUTER_SYSTEM },
        { role: "user", content: input },
      ],
      temperature: 0.2,
      max_tokens: ROUTER_MAX_TOKENS,
    })
    const text = completion.choices[0]?.message?.content?.trim() ?? ""
    const routeFromModel: Route = /crisis/i.test(text) ? "Crisis" : "CBT"
    const numMatch = text.match(/(?:^|\n)\s*([0-9]*\.?[0-9]+)\s*$/) ?? text.match(/([0-9]*\.?[0-9]+)/)
    const confidence = Math.min(1, Math.max(0, Number(numMatch?.[1] ?? 0.5) || 0.5))
    // Only route to Crisis when confidence meets threshold; default to CBT otherwise
    const route: Route =
      routeFromModel === "Crisis" && confidence >= CRISIS_CONFIDENCE_THRESHOLD ? "Crisis" : "CBT"
    return { route, confidence }
  } catch {
    return { route: "CBT", confidence: 0.5 }
  }
}
