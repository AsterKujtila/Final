-- Chat sessions: one per user per "logical day" (see app logic for 12AM + 5h rule)
create table if not exists public.chat_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  session_date date not null,
  day_of_week text not null,
  time_of_day text not null check (time_of_day in ('morning', 'day', 'evening')),
  started_at timestamptz not null default now(),
  last_message_at timestamptz,
  title text,
  summary text,
  reflection text,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (user_id, session_date)
);

-- Chat messages: every user/ai message in a session
create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.chat_sessions (id) on delete cascade,
  role text not null check (role in ('user', 'ai')),
  content text not null,
  created_at timestamptz default now()
);

create index if not exists idx_chat_messages_session_id on public.chat_messages (session_id);
create index if not exists idx_chat_sessions_user_date on public.chat_sessions (user_id, session_date desc);

alter table public.chat_sessions enable row level security;
alter table public.chat_messages enable row level security;

create policy "Users can manage own chat_sessions"
  on public.chat_sessions for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "Users can manage messages of own sessions"
  on public.chat_messages for all
  using (
    exists (select 1 from public.chat_sessions s where s.id = session_id and s.user_id = auth.uid())
  )
  with check (
    exists (select 1 from public.chat_sessions s where s.id = session_id and s.user_id = auth.uid())
  );
