-- User theme preference: dark (default) or light
alter table public.profiles
  add column if not exists prefer_dark boolean not null default true;

comment on column public.profiles.prefer_dark is 'When true, use dark theme; when false, use light theme. Default dark.';
