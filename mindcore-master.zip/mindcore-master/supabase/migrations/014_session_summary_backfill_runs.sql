-- Run session title/summary backfill at most once per user per calendar day (triggered at relogin).
create table if not exists public.session_summary_backfill_runs (
  user_id uuid not null references auth.users (id) on delete cascade,
  run_date date not null,
  created_at timestamptz default now(),
  primary key (user_id, run_date)
);

alter table public.session_summary_backfill_runs enable row level security;

create policy "Users can read own session_summary_backfill_runs"
  on public.session_summary_backfill_runs for select
  using (auth.uid() = user_id);

create policy "Service can insert session_summary_backfill_runs"
  on public.session_summary_backfill_runs for insert
  with check (auth.uid() = user_id);
