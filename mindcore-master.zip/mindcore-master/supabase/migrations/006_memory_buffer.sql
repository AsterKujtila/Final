-- Buffer for memory candidates before commit to Pinecone (build_plan: Store in Supabase buffer → Commit trigger → Pinecone)
create table if not exists public.memory_buffer (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  session_id uuid not null references public.chat_sessions (id) on delete cascade,
  turn_summary text,
  memory_candidate text not null,
  strength_score float not null default 0,
  is_crisis boolean not null default false,
  committed boolean not null default false,
  created_at timestamptz default now()
);

create index if not exists idx_memory_buffer_user_uncommitted
  on public.memory_buffer (user_id, committed) where not committed;

alter table public.memory_buffer enable row level security;

create policy "Users can manage own memory_buffer"
  on public.memory_buffer for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
