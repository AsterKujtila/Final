-- One report per user per message. Used to show "Reported" and prevent double-report.
create table if not exists public.message_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  message_id uuid not null references public.chat_messages (id) on delete cascade,
  created_at timestamptz default now(),
  unique (user_id, message_id)
);

create index if not exists idx_message_reports_user_id on public.message_reports (user_id);

alter table public.message_reports enable row level security;

create policy "Users can insert own message_reports"
  on public.message_reports for insert
  with check (auth.uid() = user_id);

create policy "Users can read own message_reports"
  on public.message_reports for select
  using (auth.uid() = user_id);
