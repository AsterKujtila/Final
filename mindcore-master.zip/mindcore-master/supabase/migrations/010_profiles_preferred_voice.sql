alter table public.profiles
  add column if not exists preferred_voice text not null default 'alloy';

comment on column public.profiles.preferred_voice is 'OpenAI TTS voice id: alloy, nova, or shimmer. Used for Read Aloud and voice samples.';
