-- Structured reflection sections (optional; backfill keeps reflection text)
alter table public.weekly_reflections
  add column if not exists what_we_noticed text,
  add column if not exists how_things_going text,
  add column if not exists where_to_start text;

-- Feedback for weekly reflections: yes / somehow / no
create table if not exists public.reflection_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  week_start date not null,
  helpful text not null check (helpful in ('yes', 'somehow', 'no')),
  created_at timestamptz default now(),
  unique (user_id, week_start)
);

alter table public.reflection_feedback enable row level security;

create policy "Users can manage own reflection_feedback"
  on public.reflection_feedback
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
