-- Mark that the user has started a chat conversation from this reflection (one-time only).
alter table public.weekly_reflections
  add column if not exists conversation_started_at timestamptz default null;
