alter table public.memory_buffer
  add column if not exists is_crisis boolean not null default false;
