-- Run insight generation at most once per user per calendar day (triggered at relogin).
create table if not exists public.insight_generation_runs (
  user_id uuid not null references auth.users (id) on delete cascade,
  run_date date not null,
  created_at timestamptz default now(),
  primary key (user_id, run_date)
);

alter table public.insight_generation_runs enable row level security;

create policy "Users can read own insight_generation_runs"
  on public.insight_generation_runs for select
  using (auth.uid() = user_id);

create policy "Service can insert insight_generation_runs"
  on public.insight_generation_runs for insert
  with check (auth.uid() = user_id);
