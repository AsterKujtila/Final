-- Countries: name + flag (helplines for you to fill later)
create table if not exists public.countries (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  flag text not null,
  helplines jsonb default '[]'::jsonb,
  created_at timestamptz default now()
);

-- Profiles: one per auth user, filled after onboarding
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  name text,
  country_id uuid references public.countries (id),
  age int check (age >= 13 and age <= 105),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Sessions: log when user enters the app
create table if not exists public.sessions_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  created_at timestamptz default now()
);

-- RLS
alter table public.profiles enable row level security;
alter table public.countries enable row level security;
alter table public.sessions_log enable row level security;

create policy "Users can read own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Users can insert own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "Anyone can read countries"
  on public.countries for select
  using (true);

create policy "Users can insert own session log"
  on public.sessions_log for insert
  with check (auth.uid() = user_id);

create policy "Users can read own session logs"
  on public.sessions_log for select
  using (auth.uid() = user_id);
