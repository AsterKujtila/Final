-- New reflection layout: summary, what has been going on, letter, something good, what next
alter table public.weekly_reflections
  add column if not exists summary text,
  add column if not exists what_has_been_going_on text,
  add column if not exists letter_reflection text,
  add column if not exists something_good text,
  add column if not exists what_next text;
