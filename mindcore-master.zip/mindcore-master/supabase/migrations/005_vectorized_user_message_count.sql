-- Track how many user messages have been vectorized (per 10-message cycle)
alter table public.chat_sessions
  add column if not exists vectorized_user_message_count int not null default 0;
