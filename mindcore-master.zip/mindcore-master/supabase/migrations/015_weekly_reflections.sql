-- Weekly reflections: one per user per calendar week (Sunday–Saturday).
-- week_start matches the Sunday date used in the History page week grouping.

create table if not exists public.weekly_reflections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  week_start date not null,
  week_end date not null,
  reflection text not null,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique (user_id, week_start)
);

alter table public.weekly_reflections enable row level security;

create policy "Users can manage own weekly_reflections"
  on public.weekly_reflections
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

