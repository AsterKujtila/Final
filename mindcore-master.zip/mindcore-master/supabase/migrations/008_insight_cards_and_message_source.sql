-- Insight cards: 1–2 per day, generated from chat logs. When user taps a card it’s used in that day’s chat and marked discussed.
create table if not exists public.insight_cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  session_id uuid not null references public.chat_sessions (id) on delete cascade,
  title text not null,
  description text not null,
  question text not null,
  discussed boolean not null default false,
  created_at timestamptz default now()
);

create index if not exists idx_insight_cards_user_discussed
  on public.insight_cards (user_id, discussed);

alter table public.insight_cards enable row level security;

create policy "Users can manage own insight_cards"
  on public.insight_cards for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- Optional source on messages so we can render “insight” prompts as the special full-width block.
alter table public.chat_messages
  add column if not exists source text default null;
