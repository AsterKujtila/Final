-- Experimental features opt-in flag
alter table public.profiles
  add column if not exists experimental_features_enabled boolean not null default false;

comment on column public.profiles.experimental_features_enabled is 'When true, enable experimental product features for this user.';

