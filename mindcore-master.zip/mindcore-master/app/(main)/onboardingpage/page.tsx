"use client"

import { useRouter } from "next/navigation"
import { useShell } from "@/app/(main)/shell-context"
import { OnboardingPage } from "@/components/onboarding-page"

export default function OnboardingRoute() {
  const router = useRouter()
  const { preOnboardingPath, setChatActive } = useShell()
  return (
    <OnboardingPage
      onComplete={() => {
        setChatActive(false)
        router.push("/chat")
      }}
      onBack={() => router.push(preOnboardingPath)}
    />
  )
}
