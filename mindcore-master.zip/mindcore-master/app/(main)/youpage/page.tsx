"use client"

import { useRouter } from "next/navigation"
import { YouPage } from "@/components/you-page"

export default function YouPageRoute() {
  const router = useRouter()
  return (
    <YouPage
      onNavigateInsights={() => router.push("/insights")}
      onNavigateReflection={() => router.push("/reflection")}
    />
  )
}
