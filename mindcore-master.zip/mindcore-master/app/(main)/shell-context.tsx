"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"

type TabPath = "/chat" | "/youpage" | "/history"

interface ShellContextValue {
  chatActive: boolean
  setChatActive: (active: boolean) => void
  settingsOpen: boolean
  openSettings: () => void
  closeSettings: () => void
  preOnboardingPath: TabPath
  setPreOnboardingPath: (path: TabPath) => void
  handleSettingsItemClick: (label: string) => void
}

const ShellContext = createContext<ShellContextValue | null>(null)

export function ShellProvider({ children }: { children: ReactNode }) {
  const [chatActive, setChatActive] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [preOnboardingPath, setPreOnboardingPath] = useState<TabPath>("/chat")

  const openSettings = useCallback(() => setSettingsOpen(true), [])
  const closeSettings = useCallback(() => setSettingsOpen(false), [])

  const handleSettingsItemClick = useCallback((label: string) => {
    if (label === "About") {
      setPreOnboardingPath("/chat") // will be overridden by layout when opening from a tab
      closeSettings()
      // Navigation to onboarding is done by the caller with current path
    }
  }, [closeSettings])

  const value: ShellContextValue = {
    chatActive,
    setChatActive,
    settingsOpen,
    openSettings,
    closeSettings,
    preOnboardingPath,
    setPreOnboardingPath,
    handleSettingsItemClick,
  }

  return <ShellContext.Provider value={value}>{children}</ShellContext.Provider>
}

export function useShell() {
  const ctx = useContext(ShellContext)
  if (!ctx) throw new Error("useShell must be used within ShellProvider")
  return ctx
}
