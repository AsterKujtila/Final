"use client"

import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import { ShellProvider, useShell } from "@/app/(main)/shell-context"
import { AuthGuard } from "@/components/auth-guard"
import { BottomNavigation } from "@/components/bottom-navigation"
import { SettingsMenu } from "@/components/settings-menu"
import { PageHeader } from "@/components/page-header"
import { MenuIcon } from "@/components/menu-icon"
import { AppLogo } from "@/components/app-logo"
import { createClient } from "@/lib/supabase/client"
import { Drawer, DrawerContent, DrawerTrigger, DrawerHeader, DrawerDescription, DrawerFooter } from "@/components/ui/drawer"
import { Button } from "@/components/ui/button"
import { ReflectionStatusIcon } from "@/components/reflection-status"
import { cn } from "@/lib/utils"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

const DESKTOP_BREAKPOINT = 1024

function useIsDesktop() {
  const [isDesktop, setIsDesktop] = useState<boolean | null>(null)

  useEffect(() => {
    if (typeof window === "undefined") return
    const mql = window.matchMedia(`(min-width: ${DESKTOP_BREAKPOINT}px)`)
    const handleChange = (event: MediaQueryListEvent) => {
      setIsDesktop(event.matches)
    }

    setIsDesktop(mql.matches)
    mql.addEventListener("change", handleChange)

    return () => {
      mql.removeEventListener("change", handleChange)
    }
  }, [])

  return isDesktop
}

function DesktopShell({
  children,
  gradient = false,
}: {
  children: React.ReactNode
  gradient?: boolean
}) {
  return (
    <div className="min-h-dvh flex flex-col bg-background md:items-center md:justify-center">
      <div
        className={cn(
          "relative w-full h-dvh flex flex-col overflow-hidden",
          gradient && "corl-gradient",
          "md:h-[min(720px,100dvh)] md:max-w-[430px] md:rounded-[32px] md:border md:border-white/10 md:shadow-[0_24px_80px_rgba(0,0,0,0.6)]",
        )}
      >
        {children}
      </div>
    </div>
  )
}

function MainLayoutInner({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const {
    chatActive,
    setChatActive,
    settingsOpen,
    openSettings,
    closeSettings,
    setPreOnboardingPath,
    handleSettingsItemClick,
  } = useShell()

  const isDesktop = useIsDesktop()
  const [desktopNoticeOpen, setDesktopNoticeOpen] = useState(false)

  useEffect(() => {
    if (isDesktop !== true) return
    if (typeof window === "undefined") return

    try {
      const dismissed = window.localStorage.getItem("mindcore_desktop_notice_dismissed")
      if (dismissed === "true") return
      setDesktopNoticeOpen(true)
    } catch {
      setDesktopNoticeOpen(true)
    }
  }, [isDesktop])

  const handleCloseDesktopNotice = () => {
    setDesktopNoticeOpen(false)
    if (typeof window === "undefined") return
    try {
      window.localStorage.setItem("mindcore_desktop_notice_dismissed", "true")
    } catch {
      // ignore
    }
  }

  const desktopNoticeDialog = (
    <Dialog
      open={isDesktop === true && desktopNoticeOpen}
      onOpenChange={(open) => {
        if (!open) {
          handleCloseDesktopNotice()
        } else {
          setDesktopNoticeOpen(true)
        }
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>MindCore is a mobile app demo</DialogTitle>
          <DialogDescription className="space-y-2">
            <p>
              MindCore is designed and optimized for mobile screens. The desktop view you are
              seeing is just a preview of the mobile experience.
            </p>
            <p>
              Some layouts and interactions may not behave exactly as intended on larger screens.
              For the best experience, we recommend using MindCore on your phone.
            </p>
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button type="button" className="w-full" onClick={handleCloseDesktopNotice}>
            Continue on desktop
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )

  const isOnboarding = pathname === "/onboardingpage"
  const isInsights = pathname === "/insights"
  const isHistory = pathname === "/history"
  const isChat = pathname === "/chat"
  const isYou = pathname === "/youpage"
  const isReflection = pathname === "/reflection"

  const showBottomNav = !(isChat && chatActive) && !isReflection
  const showChatHeader = isChat && !chatActive

  const navigateToInsights = () => router.push("/insights")
  const navigateBack = () => router.back()

  const handleSettingsItemClickWithNav = async (label: string) => {
    if (label === "Logout") {
      closeSettings()
      const supabase = createClient()
      await supabase.auth.signOut()
      router.replace("/login")
      router.refresh()
      return
    }
    if (label === "About") {
      const tabPath = isChat ? "/chat" : isYou ? "/youpage" : isHistory ? "/history" : isInsights ? "/youpage" : "/chat"
      setPreOnboardingPath(tabPath)
      closeSettings()
      setTimeout(() => router.push("/onboardingpage"), 300)
      return
    }
    handleSettingsItemClick(label)
  }

  if (isOnboarding) {
    return (
      <AuthGuard>
        {children}
      </AuthGuard>
    )
  }

  if (isInsights) {
    return (
      <DesktopShell gradient>
        <main className="flex flex-col flex-1 overflow-hidden">
          {children}
          <SettingsMenu
            isOpen={settingsOpen}
            onClose={closeSettings}
            onItemClick={handleSettingsItemClickWithNav}
          />
        </main>
        {desktopNoticeDialog}
      </DesktopShell>
    )
  }

  if (isReflection) {
    return (
      <AuthGuard>
        <DesktopShell>
          <main className="flex flex-col flex-1 overflow-hidden">
            {children}
          </main>
          {desktopNoticeDialog}
        </DesktopShell>
      </AuthGuard>
    )
  }

  return (
    <AuthGuard>
      <DesktopShell gradient>
        <main className="flex flex-col flex-1 overflow-hidden">
          {showChatHeader && (
            <header className="flex items-center justify-between px-5 pt-4 pb-2">
              <div className="w-10 h-10 flex items-center justify-center">
                <AppLogo className="w-10 h-10 object-contain" />
              </div>
              <div className="flex items-center gap-3">
                <Drawer>
                  <DrawerTrigger asChild>
                    <button
                      className="rounded-full glass flex items-center justify-center w-10 h-10"
                      aria-label="Open reflection status"
                    >
                      <ReflectionStatusIcon size="sm" />
                    </button>
                  </DrawerTrigger>
                  <DrawerContent className="border-t bg-background rounded-t-3xl flex flex-col">
                    <DrawerHeader className="flex flex-col items-center gap-4 pt-6">
                      <ReflectionStatusIcon size="lg" />
                      <div className="space-y-2 text-center px-6">
                        <p className="text-xs font-sans font-semibold tracking-[0.2em] uppercase text-foreground/70">
                          Keep talking, reflection is forming.
                        </p>
                        <DrawerDescription className="text-sm text-foreground/75">
                          As you share more of what&apos;s on your mind, we&apos;re quietly connecting the dots in
                          the background. When you&apos;re ready, you can always return here to continue where you
                          left off.
                        </DrawerDescription>
                      </div>
                    </DrawerHeader>
                    <DrawerFooter>
                      <Button className="w-full" size="lg">
                        Resume Conversation
                      </Button>
                    </DrawerFooter>
                  </DrawerContent>
                </Drawer>
                <button
                  onClick={openSettings}
                  className="w-10 h-10 rounded-full glass flex items-center justify-center"
                  aria-label="Open menu"
                >
                  <MenuIcon />
                </button>
              </div>
            </header>
          )}
          {isYou && (
            <PageHeader
              title="Last 10 Days"
              showBack={false}
              onBack={navigateBack}
              onMenu={openSettings}
            />
          )}
          <div key={pathname} className="flex flex-col flex-1 overflow-hidden page-enter">
            {children}
          </div>
          {showBottomNav && (
            <BottomNavigation
              activeTab={isChat ? "chat" : isYou ? "you" : "history"}
              onTabChange={(tab) => {
                setChatActive(false)
                if (tab === "chat") router.push("/chat")
                else if (tab === "you") router.push("/youpage")
                else router.push("/history")
              }}
            />
          )}
          {!isHistory && !chatActive && (
            <SettingsMenu
              isOpen={settingsOpen}
              onClose={closeSettings}
              onItemClick={handleSettingsItemClickWithNav}
            />
          )}
        </main>
        {desktopNoticeDialog}
      </DesktopShell>
    </AuthGuard>
  )
}

export default function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <ShellProvider>
      <MainLayoutInner>{children}</MainLayoutInner>
    </ShellProvider>
  )
}
