"use client"

import { Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useEffect, useState } from "react"
import Image from "next/image"
import { ArrowLeft, ThumbsUp, Share2 } from "lucide-react"

type ReflectionPhase = "loading" | "done" | "content"

const LOADING_MS = 4500
const DONE_MS = 1800

const STORAGE_KEY = "mindcore_reflection_context"
const STORAGE_WEEK_KEY = "mindcore_reflection_week"
const STORAGE_TITLE_KEY = "mindcore_reflection_title"
const STORAGE_SUMMARY_KEY = "mindcore_reflection_summary"

const CARD_COLOR_CURRENT = "#b09e8f"
const CARD_COLOR_PAST = "#8f8276"

type ReflectionData = {
  reflection: string
  weekStart?: string
  summary?: string
  whatHasBeenGoingOn?: string
  letterReflection?: string
  somethingGood?: string
  whatNext?: string
  whatWeNoticed?: string
  howThingsAreGoing?: string
  whereToStart?: string
  feedbackHelpful?: "yes" | "somehow" | "no"
  conversationStarted?: boolean
}

type FeedbackChoice = "yes" | "somehow" | "no" | null

function parseReflectionJson(json: Record<string, unknown>): ReflectionData {
  const feedback = json.feedbackHelpful
  const helpful = feedback === "yes" || feedback === "somehow" || feedback === "no" ? feedback : undefined
  return {
    reflection: typeof json.reflection === "string" ? json.reflection : "",
    weekStart: typeof json.weekStart === "string" ? json.weekStart : undefined,
    summary: typeof json.summary === "string" ? json.summary : undefined,
    whatHasBeenGoingOn: typeof json.whatHasBeenGoingOn === "string" ? json.whatHasBeenGoingOn : undefined,
    letterReflection: typeof json.letterReflection === "string" ? json.letterReflection : undefined,
    somethingGood: typeof json.somethingGood === "string" ? json.somethingGood : undefined,
    whatNext: typeof json.whatNext === "string" ? json.whatNext : undefined,
    whatWeNoticed: typeof json.whatWeNoticed === "string" ? json.whatWeNoticed : undefined,
    howThingsAreGoing: typeof json.howThingsAreGoing === "string" ? json.howThingsAreGoing : undefined,
    whereToStart: typeof json.whereToStart === "string" ? json.whereToStart : undefined,
    feedbackHelpful: helpful,
    conversationStarted: json.conversationStarted === true,
  }
}

function ReflectionPageInner() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const weekStartParam = searchParams.get("weekStart")?.trim()
  const isViewingPastReflection = !!weekStartParam && /^\d{4}-\d{2}-\d{2}$/.test(weekStartParam)
  const [phase, setPhase] = useState<ReflectionPhase>("loading")
  const [data, setData] = useState<ReflectionData>({ reflection: "" })
  const [isPastReflection, setIsPastReflection] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [feedbackSent, setFeedbackSent] = useState<FeedbackChoice | null>(null)
  const [feedbackLoading, setFeedbackLoading] = useState(false)

  useEffect(() => {
    let cancelled = false
    let t1: ReturnType<typeof setTimeout> | null = null
    let t2: ReturnType<typeof setTimeout> | null = null

    const run = async () => {
      try {
        if (isViewingPastReflection && weekStartParam) {
          const res = await fetch(`/api/reflection?weekStart=${encodeURIComponent(weekStartParam)}`)
          if (!res.ok) {
            const json = await res.json().catch(() => ({}))
            throw new Error(json.error ?? "Failed to load reflection")
          }
        const json = await res.json()
        if (!cancelled) {
          const parsed = parseReflectionJson(json)
          setData(parsed)
          if (parsed.feedbackHelpful) setFeedbackSent(parsed.feedbackHelpful)
          setIsPastReflection(true)
          setPhase("content")
        }
        return
      }

      const res = await fetch("/api/reflection/generate", { method: "POST" })
        if (!res.ok) {
          const json = await res.json().catch(() => ({}))
          throw new Error(json.error ?? "Failed to load reflection")
        }
        const json = await res.json()
        if (!cancelled) {
          const parsed = parseReflectionJson(json)
          setData(parsed)
          if (parsed.feedbackHelpful) setFeedbackSent(parsed.feedbackHelpful)
          if (json.fromCache === true) {
            setIsPastReflection(true)
            setPhase("content")
            return
          }
        }

        t1 = setTimeout(() => {
          if (!cancelled) setPhase("done")
        }, LOADING_MS)
        t2 = setTimeout(() => {
          if (!cancelled) setPhase("content")
        }, LOADING_MS + DONE_MS)
      } catch (e) {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : "Failed to load reflection")
          setPhase("content")
        }
      }
    }

    run().catch(() => {})

    return () => {
      cancelled = true
      if (t1) clearTimeout(t1)
      if (t2) clearTimeout(t2)
    }
  }, [weekStartParam])

  const [conversationStarting, setConversationStarting] = useState(false)

  const handleLetsStartHere = async () => {
    if (!data.reflection || !data.weekStart || data.conversationStarted) return
    setConversationStarting(true)
    try {
      const res = await fetch("/api/chat/start-reflection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          weekStart: data.weekStart,
          title: data.summary?.trim() || "Weekly Reflection",
          summary: data.summary?.trim() || data.reflection.slice(0, 300),
          reflectionContext: data.reflection,
        }),
      })
      const json = await res.json().catch(() => ({}))
      if (!res.ok) {
        console.error(json.error ?? "Failed to start conversation")
        return
      }
      const sessionId = json.sessionId
      if (sessionId) {
        router.push(`/chat?sessionId=${encodeURIComponent(sessionId)}`)
      } else {
        router.push("/chat")
      }
    } catch (e) {
      console.error(e)
    } finally {
      setConversationStarting(false)
    }
  }

  const shareText = data.letterReflection || data.reflection
  const handleShare = async () => {
    if (!shareText) return
    const title = data.summary || "Weekly Reflection"
    const toShare = `${title}\n\n${shareText}`
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({
          title: "My MindCore Reflection",
          text: toShare,
        })
      } catch {
        copyToClipboard(toShare)
      }
    } else {
      copyToClipboard(toShare)
    }
  }

  function copyToClipboard(text: string) {
    if (typeof navigator === "undefined") return
    navigator.clipboard.writeText(text).catch(() => {})
  }

  const sendFeedback = async (helpful: "yes" | "somehow" | "no") => {
    if (!data.weekStart || feedbackSent !== null) return
    setFeedbackLoading(true)
    try {
      const res = await fetch("/api/reflection/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ weekStart: data.weekStart, helpful }),
      })
      if (res.ok) setFeedbackSent(helpful)
    } finally {
      setFeedbackLoading(false)
    }
  }

  if (phase === "loading") {
    return (
      <div className="fixed inset-0 flex flex-col overflow-hidden">
        <div className="reflection-loading-gradient absolute inset-0" />
        <button
          onClick={() => router.back()}
          className="relative z-10 w-10 h-10 rounded-full mt-4 ml-5 flex items-center justify-center bg-[#666] border-0"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="relative z-10 flex-1 flex items-center justify-center">
          <h1 className="reflection-writing-text text-3xl font-serif text-[#f5f0eb] text-center px-6">
            {isViewingPastReflection ? "Loading Past Reflection" : "Writing Reflection"}
          </h1>
        </div>
      </div>
    )
  }

  if (phase === "done") {
    return (
      <div className="fixed inset-0 flex flex-col overflow-hidden">
        <div className="reflection-loading-gradient absolute inset-0" />
        <button
          onClick={() => router.back()}
          className="relative z-10 w-10 h-10 rounded-full mt-4 ml-5 flex items-center justify-center bg-[#666] border-0"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="relative z-10 flex-1 flex items-center justify-center">
          <h1 className="text-3xl font-serif text-[#f5f0eb] text-center">
            Done
          </h1>
        </div>
      </div>
    )
  }

  const introSummary = data.summary ?? (data.reflection ? data.reflection.split("\n\n")[0] : "")

  return (
    <div className="flex flex-col h-full bg-background overflow-y-auto no-scrollbar">
      {/* Back button overlay */}
      <div className="absolute top-0 left-0 z-20 p-4">
        <button
          onClick={() => router.back()}
          className="w-10 h-10 rounded-full flex items-center justify-center bg-[#3e3a38]/90 border-0"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 text-[#e8e4e0]" />
        </button>
      </div>

      <div className="flex-1 pb-32">
        {/* Hero: image touching all margins, taller; title in white, left-aligned */}
        <div className="relative w-full aspect-[4/3] min-h-[280px] bg-[#615a55]">
          <Image
            src="/hero-reflection.png"
            alt=""
            fill
            className="object-cover"
            sizes="100vw"
            priority
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: "linear-gradient(to top, rgba(42, 34, 32, 0.07) 0rgba(42, 34, 32, 0.11).4) 45%, transparent 70%)",
            }}
          />
          <div className="absolute inset-0 flex flex-col justify-end p-5 pb-8 items-start text-left">
            <span className="inline-block text-[10px] font-sans font-semibold tracking-[0.2em] text-white/90 uppercase mb-3">
              {isPastReflection ? "VIEW PAST REFLECTION" : "REFLECTION FOR YOU"}
            </span>
            <h1 className="text-2xl md:text-3xl font-serif text-white leading-tight max-w-full">
              {error
                ? "We couldn’t load your reflection."
                : introSummary || "Weekly reflection"}
            </h1>
          </div>
        </div>

        {/* Body: dark bg, no gradient */}
        {data.reflection && !error && (
          <div className="px-5 -mt-2 pt-6 bg-background rounded-t-3xl">
            {/* What has been going on (2 paras) */}
            <section className="mb-8">
              <h2 className="text-lg font-serif text-foreground mb-3">
                What has been going on
              </h2>
              <div className="font-sans text-base leading-relaxed text-muted-foreground space-y-3">
                {(data.whatHasBeenGoingOn || data.whatWeNoticed || data.howThingsAreGoing || data.reflection.split("\n\n")[0])
                  .split(/\n\n+/)
                  .filter(Boolean)
                  .map((p, i) => (
                    <p key={i}>{p}</p>
                  ))}
              </div>
            </section>

            {/* Image background with centered white card */}
            <section className="relative w-full my-8 overflow-hidden">
              <div className="relative flex items-center justify-center py-6 sm:py-8 px-4 sm:px-6">
                <div className="absolute inset-0 bg-[#615a55]">
                  <Image
                    src="/hero-reflection.png"
                    alt=""
                    fill
                    className="object-cover"
                    sizes="100vw"
                  />
                </div>
                <div className="relative w-full max-w-md sm:max-w-lg mx-auto rounded-2xl bg-white shadow-lg p-5 sm:p-6 text-[#1a1412]">
                  <p className="font-serif text-sm sm:text-base leading-relaxed whitespace-pre-line pr-10">
                    {data.letterReflection || data.reflection}
                  </p>
                  <button
                    type="button"
                    onClick={handleShare}
                    className="absolute top-3 right-3 w-9 h-9 shrink-0 rounded-lg border border-black/10 flex items-center justify-center hover:bg-black/5 transition"
                    aria-label="Share reflection"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </section>

            {/* Something good */}
            <section className="mb-8">
              <h2 className="text-lg font-serif text-foreground mb-3">
                Something good
              </h2>
              <p className="font-sans text-base leading-relaxed text-muted-foreground">
                {data.somethingGood || data.whereToStart || ""}
              </p>
            </section>

            {/* What next? */}
            <section className="mb-8">
              <h2 className="text-lg font-serif text-foreground mb-3">
                What next?
              </h2>
              <p className="font-sans text-base leading-relaxed text-muted-foreground">
                {data.whatNext || data.whereToStart || ""}
              </p>
            </section>

            {data.conversationStarted ? (
              <p className="w-full py-3.5 rounded-xl font-sans text-sm text-center text-muted-foreground border border-border">
                You’ve already started a conversation about this reflection.
              </p>
            ) : (
              <button
                type="button"
                onClick={handleLetsStartHere}
                disabled={conversationStarting}
                className="w-full py-3.5 rounded-xl font-sans font-semibold text-background transition opacity hover:opacity-90 disabled:opacity-70"
                style={{ backgroundColor: isPastReflection ? CARD_COLOR_PAST : CARD_COLOR_CURRENT }}
              >
                {conversationStarting ? "Opening chat…" : "Lets start here"}
              </button>
            )}

            {/* Feedback */}
            <div className="mt-8 pt-6 border-t border-border">
              <p className="font-sans text-sm text-foreground mb-3">
                Did you find this helpful?
              </p>
              {feedbackSent !== null ? (
                <p className="font-sans text-sm text-muted-foreground">
                  Thanks for your feedback.
                </p>
              ) : (
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => sendFeedback("yes")}
                    disabled={feedbackLoading}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-card text-foreground font-sans text-sm hover:bg-secondary transition disabled:opacity-50"
                    aria-label="Yes"
                  >
                    <ThumbsUp className="w-4 h-4" />
                    Yes
                  </button>
                  <button
                    type="button"
                    onClick={() => sendFeedback("somehow")}
                    disabled={feedbackLoading}
                    className="px-4 py-2 rounded-lg border border-border bg-card text-foreground font-sans text-sm hover:bg-secondary transition disabled:opacity-50"
                  >
                    Somehow
                  </button>
                  <button
                    type="button"
                    onClick={() => sendFeedback("no")}
                    disabled={feedbackLoading}
                    className="px-4 py-2 rounded-lg border border-border bg-card text-foreground font-sans text-sm hover:bg-secondary transition disabled:opacity-50"
                  >
                    No
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default function ReflectionPage() {
  return (
    <Suspense fallback={
      <div className="flex flex-col h-full bg-background items-center justify-center">
        <p className="font-sans text-muted-foreground">Loading...</p>
      </div>
    }>
      <ReflectionPageInner />
    </Suspense>
  )
}
