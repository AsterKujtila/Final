"use client"

import { useShell } from "@/app/(main)/shell-context"
import { ChatPage } from "@/components/chat-page"

export default function ChatRoute() {
  const { setChatActive } = useShell()
  return (
    <ChatPage
      onBack={() => setChatActive(false)}
      onActiveChange={setChatActive}
    />
  )
}
