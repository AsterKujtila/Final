"use client"

import { useRouter } from "next/navigation"
import { useShell } from "@/app/(main)/shell-context"
import { InsightsPage } from "@/components/insights-page"

export default function InsightsRoute() {
  const router = useRouter()
  const { openSettings } = useShell()
  return (
    <InsightsPage
      onBack={() => router.back()}
      onMenu={openSettings}
    />
  )
}
