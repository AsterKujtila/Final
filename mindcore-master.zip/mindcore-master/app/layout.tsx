import type { Metadata, Viewport } from 'next'
import { Instrument_Sans } from 'next/font/google'
import localFont from 'next/font/local'
import { Analytics } from '@vercel/analytics/next'
import { CorlThemeProvider } from '@/components/corl-theme-provider'
import { PWAInstallProvider } from '@/components/pwa-install-provider'
import './globals.css'

const instrumentSans = Instrument_Sans({
  subsets: ['latin'],
  variable: '--font-instrument-sans',
  weight: ['400', '500', '600', '700'],
})

const instrumentSerif = localFont({
  src: '../SeasonMix-TRIAL-SemiBold.ttf',
  variable: '--font-instrument-serif',
  weight: '600',
  style: 'normal',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'MindCore',
  description: 'Your personal reflection companion',
  manifest: '/favicons/manifest.json',
  icons: {
    icon: [
      { url: '/favicons/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/favicons/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/favicons/favicon.ico' },
    ],
    apple: '/favicons/apple-touch-icon.png',
    other: [
      {
        rel: 'icon',
        url: '/favicons/android-chrome-192x192.png',
      },
      {
        rel: 'icon',
        url: '/favicons/android-chrome-512x512.png',
      },
    ],
  },
}

export const viewport: Viewport = {
  themeColor: '#2a2220',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${instrumentSans.variable} ${instrumentSerif.variable}`} suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: "document.documentElement.classList.add('dark');",
          }}
        />
      </head>
      <body className="font-sans antialiased">
        <CorlThemeProvider>
          <PWAInstallProvider>
            {children}
            <Analytics />
          </PWAInstallProvider>
        </CorlThemeProvider>
      </body>
    </html>
  )
}
