import { NextResponse } from "next/server"
import { createHash, randomBytes } from "crypto"

const PKCE_COOKIE_MAX_AGE = 600 // 10 min

function generateVerifier(): string {
  const chars = "ABCDEFGHIJKLMOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
  let out = ""
  const bytes = randomBytes(56)
  for (let i = 0; i < 56; i++) {
    out += chars[bytes[i]! % chars.length]
  }
  return out
}

async function computeChallenge(verifier: string): Promise<string> {
  const hash = createHash("sha256").update(verifier, "utf8").digest()
  return hash.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
}

export async function GET(request: Request) {
  const { origin } = new URL(request.url)
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const redirectTo = `${origin}/auth/callback`

  const verifier = generateVerifier()
  const challenge = await computeChallenge(verifier)

  const authUrl = new URL("/auth/v1/authorize", supabaseUrl)
  authUrl.searchParams.set("provider", "google")
  authUrl.searchParams.set("redirect_to", redirectTo)
  authUrl.searchParams.set("code_challenge", challenge)
  authUrl.searchParams.set("code_challenge_method", "S256")

  const response = NextResponse.redirect(authUrl.toString())
  response.cookies.set("sb-pkce-verifier", verifier, {
    path: "/",
    maxAge: PKCE_COOKIE_MAX_AGE,
    secure: true,
    sameSite: "none",
    httpOnly: true,
  })
  return response
}
