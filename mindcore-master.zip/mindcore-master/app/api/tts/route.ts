import OpenAI from "openai"
import { NextResponse } from "next/server"

const MODEL = "tts-1"
const VALID_VOICES = ["alloy", "nova", "shimmer"] as const
const MAX_INPUT_CHARS = 4096

/**
 * POST /api/tts
 * Body: { text: string, voice?: string }
 * Returns audio/mpeg (mp3) using OpenAI TTS. Uses minimal input length when possible.
 */
export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: "OPENAI_API_KEY not configured" }, { status: 500 })
  }

  let body: { text?: string; voice?: string; speed?: number }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }

  const text = typeof body.text === "string" ? body.text.trim() : ""
  if (!text) {
    return NextResponse.json({ error: "text required" }, { status: 400 })
  }

  const voice = VALID_VOICES.includes((body.voice ?? "alloy") as (typeof VALID_VOICES)[number])
    ? (body.voice as (typeof VALID_VOICES)[number])
    : "alloy"

  const speed = typeof body.speed === "number" && body.speed >= 0.25 && body.speed <= 4 ? body.speed : 1.2

  const input = text.slice(0, MAX_INPUT_CHARS)
  const openai = new OpenAI({ apiKey })

  try {
    const response = await openai.audio.speech.create({
      model: MODEL,
      voice,
      input,
      response_format: "mp3",
      speed,
    })
    const buffer = Buffer.from(await response.arrayBuffer())
    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "audio/mpeg",
        "Cache-Control": "private, max-age=3600",
      },
    })
  } catch (err) {
    console.error("TTS failed:", err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "TTS failed" },
      { status: 500 }
    )
  }
}
