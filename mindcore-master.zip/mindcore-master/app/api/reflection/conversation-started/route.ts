import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

/**
 * POST /api/reflection/conversation-started
 * Body: { weekStart: string } (YYYY-MM-DD)
 * Sets conversation_started_at for that week's reflection so the user cannot start a second time.
 */
export async function POST(request: Request) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  let body: { weekStart?: string }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }
  const weekStart = body.weekStart?.trim()
  if (!weekStart || !/^\d{4}-\d{2}-\d{2}$/.test(weekStart)) {
    return NextResponse.json(
      { error: "weekStart (YYYY-MM-DD) required" },
      { status: 400 }
    )
  }

  const { error } = await supabase
    .from("weekly_reflections")
    .update({ conversation_started_at: new Date().toISOString() })
    .eq("user_id", user.id)
    .eq("week_start", weekStart)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
  return NextResponse.json({ ok: true })
}
