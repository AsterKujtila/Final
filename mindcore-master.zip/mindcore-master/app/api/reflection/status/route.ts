import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

function getWeekBounds(date: Date) {
  const d = new Date(date)
  d.setHours(0, 0, 0, 0)
  const day = d.getDay() // 0 = Sunday
  const start = new Date(d)
  start.setDate(d.getDate() - day)
  const end = new Date(start)
  end.setDate(start.getDate() + 6)
  const toIsoDate = (x: Date) => x.toISOString().slice(0, 10)
  return {
    weekStart: toIsoDate(start),
    weekEnd: toIsoDate(end),
  }
}

export async function GET() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const today = new Date()
  const { weekStart: currentWeekStart, weekEnd: currentWeekEnd } = getWeekBounds(today)
  const { weekStart: lastWeekStart, weekEnd: lastWeekEnd } = getWeekBounds(
    new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
  )

  const { data: currentWeekSessions } = await supabase
    .from("chat_sessions")
    .select("session_date")
    .eq("user_id", user.id)
    .gte("session_date", currentWeekStart)
    .lte("session_date", currentWeekEnd)

  const { data: lastWeekSessions } = await supabase
    .from("chat_sessions")
    .select("session_date")
    .eq("user_id", user.id)
    .gte("session_date", lastWeekStart)
    .lte("session_date", lastWeekEnd)

  const currentWeekChatDays = new Set<string>()
  for (const s of currentWeekSessions ?? []) {
    if (s.session_date != null) currentWeekChatDays.add(String(s.session_date))
  }

  const lastWeekChatDays = new Set<string>()
  for (const s of lastWeekSessions ?? []) {
    if (s.session_date != null) lastWeekChatDays.add(String(s.session_date))
  }

  const hasAnyChatCurrentWeek = currentWeekChatDays.size > 0
  const hasAnyChatLastWeek = lastWeekChatDays.size > 0

  const dayIndex = today.getDay() // 0–6
  const daysElapsed = Math.min(6, dayIndex)
  const currentWeekProgress = (daysElapsed + 1) / 7

  const nowDateStr = today.toISOString().slice(0, 10)
  const lastWeekCompleted = nowDateStr > lastWeekEnd

  const { data: lastWeekReflection } = await supabase
    .from("weekly_reflections")
    .select("week_start, week_end, reflection")
    .eq("user_id", user.id)
    .eq("week_start", lastWeekStart)
    .maybeSingle()

  const lastWeekHasReflection = !!lastWeekReflection?.reflection

  return NextResponse.json({
    currentWeek: {
      weekStart: currentWeekStart,
      weekEnd: currentWeekEnd,
      progress: currentWeekProgress,
      hasAnyChat: hasAnyChatCurrentWeek,
      totalDays: 7,
    },
    lastWeek: {
      weekStart: lastWeekStart,
      weekEnd: lastWeekEnd,
      hasAnyChat: hasAnyChatLastWeek,
      hasReflection: lastWeekHasReflection,
      cycleCompleted: lastWeekCompleted && hasAnyChatLastWeek,
    },
  })
}

