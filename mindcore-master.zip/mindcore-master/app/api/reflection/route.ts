import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(request: Request) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const weekStart = searchParams.get("weekStart")?.trim()
  if (!weekStart || !/^\d{4}-\d{2}-\d{2}$/.test(weekStart)) {
    return NextResponse.json(
      { error: "weekStart (YYYY-MM-DD) required" },
      { status: 400 }
    )
  }

  const { data, error } = await supabase
    .from("weekly_reflections")
    .select("week_start, week_end, reflection, summary, what_has_been_going_on, letter_reflection, something_good, what_next, what_we_noticed, how_things_going, where_to_start, conversation_started_at")
    .eq("user_id", user.id)
    .eq("week_start", weekStart)
    .maybeSingle()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  if (!data?.reflection) {
    return NextResponse.json({ error: "Reflection not found for this week" }, { status: 404 })
  }

  const { data: feedbackRow } = await supabase
    .from("reflection_feedback")
    .select("helpful")
    .eq("user_id", user.id)
    .eq("week_start", weekStart)
    .maybeSingle()

  return NextResponse.json({
    weekStart: data.week_start,
    weekEnd: data.week_end,
    reflection: data.reflection,
    summary: data.summary ?? undefined,
    whatHasBeenGoingOn: data.what_has_been_going_on ?? undefined,
    letterReflection: data.letter_reflection ?? undefined,
    somethingGood: data.something_good ?? undefined,
    whatNext: data.what_next ?? undefined,
    whatWeNoticed: data.what_we_noticed ?? undefined,
    howThingsAreGoing: data.how_things_going ?? undefined,
    whereToStart: data.where_to_start ?? undefined,
    feedbackHelpful: feedbackRow?.helpful ?? undefined,
    conversationStarted: !!data.conversation_started_at,
  })
}
