import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

type Helpful = "yes" | "somehow" | "no"

export async function POST(request: Request) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  let body: { weekStart?: string; helpful?: string }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }

  const weekStart = typeof body.weekStart === "string" ? body.weekStart.trim() : undefined
  const helpful = body.helpful as Helpful | undefined
  if (!weekStart || !/^\d{4}-\d{2}-\d{2}$/.test(weekStart) || !helpful || !["yes", "somehow", "no"].includes(helpful)) {
    return NextResponse.json(
      { error: "weekStart (YYYY-MM-DD) and helpful (yes | somehow | no) required" },
      { status: 400 }
    )
  }

  const { error } = await supabase.from("reflection_feedback").upsert(
    {
      user_id: user.id,
      week_start: weekStart,
      helpful,
    },
    { onConflict: "user_id,week_start" }
  )

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}
