import OpenAI from "openai"
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { getEmbedding, queryMemory } from "@/lib/vector-memory"

function getWeekBounds(date: Date) {
  const d = new Date(date)
  d.setHours(0, 0, 0, 0)
  const day = d.getDay() // 0 = Sunday
  const start = new Date(d)
  start.setDate(d.getDate() - day)
  const end = new Date(start)
  end.setDate(start.getDate() + 6)
  const toIsoDate = (x: Date) => x.toISOString().slice(0, 10)
  return {
    weekStart: toIsoDate(start),
    weekEnd: toIsoDate(end),
  }
}

const MODEL = "gpt-3.5-turbo"
const MAX_TOKENS = 1200
const TEMPERATURE = 0.5

type ReflectionSections = {
  summary: string
  whatHasBeenGoingOn: string
  letterReflection: string
  somethingGood: string
  whatNext: string
}

const SYSTEM = `You are writing a weekly reflection for a person based on their therapy-style chat logs from the past week.
Respond with a single JSON object (no markdown, no code fence) with exactly these keys:

- "summary": One short sentence (or two) that captures the week and can serve as a title or tagline. Warm and direct to "you". Example: "When things look away, try to take a look—it's there."
- "whatHasBeenGoingOn": Exactly 2 paragraphs. Summarize what has been going on: main themes, patterns, and feelings. Speak directly to "you", warm and grounded. No clinical language, no specific weekdays or dates.
- "letterReflection": For a small share card: start with the person's first name if you know it (e.g. "Alex,") or "You,". Then write exactly 3–3.5 punchy, concise sentences. Personal and warm. No bullet points or headings. This is the only text on the card, so keep it short and impactful.
- "somethingGood": 1–2 paragraphs. Find and name something good in the person—a strength, a small shift, a way they showed up, or something they're already doing that helps. Be specific to what appeared in the conversations.
- "whatNext": 1–2 paragraphs. What the user could try or lean into in the coming days. Soft invitations only, 1–3 concrete ideas. Direct and warm.`

export async function POST() {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: "OPENAI_API_KEY not configured" }, { status: 500 })
  }

  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const today = new Date()
  const { weekStart, weekEnd } = getWeekBounds(new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000))

  const { data: existing } = await supabase
    .from("weekly_reflections")
    .select("week_start, week_end, reflection, summary, what_has_been_going_on, letter_reflection, something_good, what_next, what_we_noticed, how_things_going, where_to_start")
    .eq("user_id", user.id)
    .eq("week_start", weekStart)
    .maybeSingle()

  if (existing?.reflection) {
    const { data: feedbackRow } = await supabase
      .from("reflection_feedback")
      .select("helpful")
      .eq("user_id", user.id)
      .eq("week_start", weekStart)
      .maybeSingle()

    return NextResponse.json({
      weekStart: existing.week_start ?? weekStart,
      weekEnd: existing.week_end ?? weekEnd,
      reflection: existing.reflection,
      summary: existing.summary ?? undefined,
      whatHasBeenGoingOn: existing.what_has_been_going_on ?? undefined,
      letterReflection: existing.letter_reflection ?? undefined,
      somethingGood: existing.something_good ?? undefined,
      whatNext: existing.what_next ?? undefined,
      whatWeNoticed: existing.what_we_noticed ?? undefined,
      howThingsAreGoing: existing.how_things_going ?? undefined,
      whereToStart: existing.where_to_start ?? undefined,
      feedbackHelpful: feedbackRow?.helpful ?? undefined,
      fromCache: true,
    })
  }

  const { data: sessions } = await supabase
    .from("chat_sessions")
    .select("id, session_date")
    .eq("user_id", user.id)
    .gte("session_date", weekStart)
    .lte("session_date", weekEnd)
    .order("session_date", { ascending: true })

  if (!sessions?.length) {
    return NextResponse.json(
      { error: "No conversations to reflect on for last week." },
      { status: 400 }
    )
  }

  const sessionIds = sessions.map((s) => s.id)
  const { data: messages } = await supabase
    .from("chat_messages")
    .select("role, content, created_at, session_id")
    .in("session_id", sessionIds)
    .order("created_at", { ascending: true })

  if (!messages?.length) {
    return NextResponse.json(
      { error: "No messages found for last week." },
      { status: 400 }
    )
  }

  const log = messages
    .map((m) => `${m.role}: ${m.content}`)
    .join("\n")
    .slice(0, 12000)

  const { data: profile } = await supabase
    .from("profiles")
    .select("name")
    .eq("id", user.id)
    .maybeSingle()
  const firstName = profile?.name?.trim()?.split(/\s+/)[0] ?? ""

  // Optional: retrieve long-term user memory from the vector DB to enrich this week's reflection.
  let memoryBlock: string | undefined
  try {
    const queryEmbedding = await getEmbedding(log.slice(0, 2000))
    const matches = await queryMemory(user.id, queryEmbedding, 5)
    if (matches.length > 0) {
      memoryBlock = matches.map((m) => m.text).join("\n\n")
    }
  } catch (err) {
    console.error("Weekly reflection memory retrieval failed:", err)
  }

  const openai = new OpenAI({ apiKey })

  try {
    const memorySection = memoryBlock
      ? `\n\nHere are some stable themes and facts about this person from previous conversations. Use them only if they clearly fit with this week's conversations; otherwise ignore them.\n\n${memoryBlock}`
      : ""

    const userPrompt = firstName
      ? `The person's first name is ${firstName}. Use it at the start of "letterReflection" (e.g. "${firstName},").\n\nHere are this week's conversations:\n\n${log}${memorySection}`
      : `Here are this week's conversations:\n\n${log}${memorySection}`

    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [
        { role: "system", content: SYSTEM },
        { role: "user", content: userPrompt },
      ],
      temperature: TEMPERATURE,
      max_tokens: MAX_TOKENS,
    })

    const raw =
      completion.choices[0]?.message?.content?.trim() ?? "{}"
    let sections: ReflectionSections
    try {
      const parsed = JSON.parse(raw) as Partial<ReflectionSections>
      sections = {
        summary: typeof parsed.summary === "string" ? parsed.summary : "",
        whatHasBeenGoingOn: typeof parsed.whatHasBeenGoingOn === "string" ? parsed.whatHasBeenGoingOn : "",
        letterReflection: typeof parsed.letterReflection === "string" ? parsed.letterReflection : "",
        somethingGood: typeof parsed.somethingGood === "string" ? parsed.somethingGood : "",
        whatNext: typeof parsed.whatNext === "string" ? parsed.whatNext : "",
      }
    } catch {
      sections = {
        summary: "A week of reflection.",
        whatHasBeenGoingOn: "This week had its share of reflection.",
        letterReflection: "Things are moving. Keep noticing how they feel from the inside out.",
        somethingGood: "You showed up. That matters.",
        whatNext: "Start with one small step that feels doable.",
      }
    }
    const reflection = [sections.summary, sections.whatHasBeenGoingOn, sections.letterReflection, sections.somethingGood, sections.whatNext]
      .filter(Boolean)
      .join("\n\n")

    const nowIso = new Date().toISOString()

    const { data: upserted, error: upsertError } = await supabase
      .from("weekly_reflections")
      .upsert(
        {
          user_id: user.id,
          week_start: weekStart,
          week_end: weekEnd,
          reflection,
          summary: sections.summary,
          what_has_been_going_on: sections.whatHasBeenGoingOn,
          letter_reflection: sections.letterReflection,
          something_good: sections.somethingGood,
          what_next: sections.whatNext,
          updated_at: nowIso,
        },
        { onConflict: "user_id,week_start" }
      )
      .select("week_start, week_end, reflection, summary, what_has_been_going_on, letter_reflection, something_good, what_next")
      .maybeSingle()

    if (upsertError) {
      return NextResponse.json(
        { error: upsertError.message },
        { status: 500 }
      )
    }

    return NextResponse.json({
      weekStart: upserted?.week_start ?? weekStart,
      weekEnd: upserted?.week_end ?? weekEnd,
      reflection: upserted?.reflection ?? reflection,
      summary: upserted?.summary ?? sections.summary,
      whatHasBeenGoingOn: upserted?.what_has_been_going_on ?? sections.whatHasBeenGoingOn,
      letterReflection: upserted?.letter_reflection ?? sections.letterReflection,
      somethingGood: upserted?.something_good ?? sections.somethingGood,
      whatNext: upserted?.what_next ?? sections.whatNext,
      fromCache: false,
    })
  } catch (err) {
    console.error("Weekly reflection generation failed:", err)
    return NextResponse.json(
      {
        error:
          err instanceof Error ? err.message : "Weekly reflection generation failed",
      },
      { status: 500 }
    )
  }
}

