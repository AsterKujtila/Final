import OpenAI from "openai"
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

const MODEL = "gpt-3.5-turbo"
const MAX_TOKENS = 300
const TEMPERATURE = 0.4
const STUB_TITLE = "Today's conversation"

const SYSTEM = `You are helping summarize a user's reflection/therapy chat for history.
Using ONLY the conversation below, output exactly two lines:
Line 1: A very short title (few words, e.g. "Work stress and sleep" or "Feeling stuck at job"). No quotes.
Line 2: A brief summary in 2–3 sentences of what was discussed and any themes or feelings. Be factual and concise.`

function getTodayUtc(): string {
  const d = new Date()
  const y = d.getUTCFullYear()
  const m = String(d.getUTCMonth() + 1).padStart(2, "0")
  const day = String(d.getUTCDate()).padStart(2, "0")
  return `${y}-${m}-${day}`
}

/**
 * POST /api/session-summaries/backfill
 * Triggered once per user per day at relogin. Finds all past-day chat_sessions that have
 * messages but no real title/summary (null or stub), generates title and summary from
 * context only via LLM, and updates the session.
 */
export async function POST() {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: "OPENAI_API_KEY not configured" }, { status: 500 })
  }

  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const today = getTodayUtc()

  const { data: existingRun } = await supabase
    .from("session_summary_backfill_runs")
    .select("user_id")
    .eq("user_id", user.id)
    .eq("run_date", today)
    .maybeSingle()
  if (existingRun) {
    return NextResponse.json({ ok: true, processed: 0 })
  }

  const { data: allPast } = await supabase
    .from("chat_sessions")
    .select("id, session_date, title")
    .eq("user_id", user.id)
    .lt("session_date", today)
    .order("session_date", { ascending: true })

  const sessions = (allPast ?? []).filter(
    (s) => s.title == null || s.title.trim() === "" || s.title === STUB_TITLE
  )

  if (!sessions.length) {
    await supabase.from("session_summary_backfill_runs").insert({ user_id: user.id, run_date: today })
    return NextResponse.json({ ok: true, processed: 0 })
  }

  const openai = new OpenAI({ apiKey })
  let processed = 0

  for (const session of sessions) {
    const { data: messages } = await supabase
      .from("chat_messages")
      .select("role, content")
      .eq("session_id", session.id)
      .order("created_at", { ascending: true })

    if (!messages?.length) continue

    const context = messages.map((m) => `${m.role}: ${m.content}`).join("\n")
    const truncated = context.slice(0, 6000)

    try {
      const completion = await openai.chat.completions.create({
        model: MODEL,
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: `Conversation:\n\n${truncated}` },
        ],
        temperature: TEMPERATURE,
        max_tokens: MAX_TOKENS,
      })
      const text = (completion.choices[0]?.message?.content?.trim() ?? "").trim()
      const lines = text.split("\n").map((l) => l.trim()).filter(Boolean)
      const title = (lines[0] ?? STUB_TITLE).slice(0, 500)
      const summary = (lines.slice(1).join(" ") || "A reflection on what you shared that day.").slice(0, 2000)

      const { error: updateError } = await supabase
        .from("chat_sessions")
        .update({
          title,
          summary,
          updated_at: new Date().toISOString(),
        })
        .eq("id", session.id)
        .eq("user_id", user.id)

      if (!updateError) processed++
    } catch (err) {
      console.error("Session summary backfill failed for session", session.id, err)
    }
  }

  await supabase.from("session_summary_backfill_runs").insert({ user_id: user.id, run_date: today })
  return NextResponse.json({ ok: true, processed })
}
