import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

const ALLOWED_REASONS = ["bug", "suggestion", "other"] as const

/**
 * POST /api/feedback
 * Body: { reason: "bug" | "suggestion" | "other", message: string }
 */
export async function POST(req: Request) {
  const supabase = await createClient()
  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser()
  if (userError || !user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  let body: { reason?: string; message?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }

  const reason =
    typeof body.reason === "string" && ALLOWED_REASONS.includes(body.reason as (typeof ALLOWED_REASONS)[number])
      ? body.reason
      : null
  const message = typeof body.message === "string" ? body.message.trim() : ""

  if (!reason || !message) {
    return NextResponse.json(
      { error: "reason and message are required" },
      { status: 400 }
    )
  }

  const { error } = await supabase.from("feedback").insert({
    user_id: user.id,
    reason,
    message,
  })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
  return NextResponse.json({ ok: true })
}
