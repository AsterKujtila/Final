import OpenAI from "openai"
import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

const MODEL = "gpt-3.5-turbo"
const MAX_TOKENS = 350
const TEMPERATURE = 0.4

const SYSTEM = `You are helping create reflection prompts from a user's therapy chat log.
From the conversation, find 1 or 2 conversation starters or themes the user might want to revisit.

You must follow one of these two options:
1) If there ARE useful, concrete topics for the user to reflect on from this chat:
   - Output 1 or 2 cards.
   - For each card, output exactly three lines (no extra lines, no markdown, no bullets):
     Line 1 (title): A short title for the topic, as a question or prompt (e.g. "When you said you feel stuck at work..."). Keep it under 12 words.
     Line 2 (description): One short sentence (under 18 words) describing the situation or theme.
     Line 3 (question): One short question (under 18 words) to get the conversation going.
   - Separate cards with a single blank line.

2) If there are NOT any good, concrete topics for reflection (for example, the chat is too short, off-topic, or purely meta):
   - Output exactly the single token NO_CARDS and nothing else.

Never output filler or placeholder text such as "---", "No further conversation available.", "No relevant chat log provided.", or generic summaries.
Be concise and closely tied to what the user actually talked about.`

/** Server today (UTC) YYYY-MM-DD for "once per day" and "today's session" checks. */
function getTodayUtc(): string {
  const d = new Date()
  const y = d.getUTCFullYear()
  const m = String(d.getUTCMonth() + 1).padStart(2, "0")
  const day = String(d.getUTCDate()).padStart(2, "0")
  return `${y}-${m}-${day}`
}

/**
 * POST /api/insights/generate
 * Triggered once per user per day at relogin. If today already has 2 non-discussed cards, skips.
 * For each day with conversations and fewer than 2 cards, generates 1–2 cards via GPT-3.5.
 */
export async function POST() {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: "OPENAI_API_KEY not configured" }, { status: 500 })
  }

  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const today = getTodayUtc()

  // Already ran for this user today → no-op
  const { data: existingRun } = await supabase
    .from("insight_generation_runs")
    .select("user_id")
    .eq("user_id", user.id)
    .eq("run_date", today)
    .maybeSingle()
  if (existingRun) {
    return NextResponse.json({ generated: 0 })
  }

  // Today's session(s): if any already has 2 non-discussed cards, skip generation for the day
  const { data: todaysSessions } = await supabase
    .from("chat_sessions")
    .select("id")
    .eq("user_id", user.id)
    .eq("session_date", today)
  const todaysSessionIds = (todaysSessions ?? []).map((s) => s.id)
  if (todaysSessionIds.length > 0) {
    const { data: nonDiscussed } = await supabase
      .from("insight_cards")
      .select("session_id")
      .eq("user_id", user.id)
      .eq("discussed", false)
      .in("session_id", todaysSessionIds)
    const countBySession = new Map<string, number>()
    for (const r of nonDiscussed ?? []) {
      countBySession.set(r.session_id, (countBySession.get(r.session_id) ?? 0) + 1)
    }
    const todayHasTwoCards = todaysSessionIds.some((id) => (countBySession.get(id) ?? 0) >= 2)
    if (todayHasTwoCards) {
      await supabase.from("insight_generation_runs").insert({ user_id: user.id, run_date: today })
      return NextResponse.json({ generated: 0 })
    }
  }

  const { data: sessions } = await supabase
    .from("chat_sessions")
    .select("id, session_date")
    .eq("user_id", user.id)
    .order("session_date", { ascending: false })
    .limit(30)

  if (!sessions?.length) {
    return NextResponse.json({ generated: 0 })
  }

  const { data: discussedCounts } = await supabase
    .from("insight_cards")
    .select("session_id")
    .eq("user_id", user.id)
    .eq("discussed", false)

  const nonDiscussedBySession = new Map<string, number>()
  for (const r of discussedCounts ?? []) {
    nonDiscussedBySession.set(r.session_id, (nonDiscussedBySession.get(r.session_id) ?? 0) + 1)
  }

  const openai = new OpenAI({ apiKey })
  let generated = 0

  for (const session of sessions) {
    const count = nonDiscussedBySession.get(session.id) ?? 0
    if (count >= 2) continue

    const { data: messages } = await supabase
      .from("chat_messages")
      .select("role, content")
      .eq("session_id", session.id)
      .order("created_at", { ascending: true })

    if (!messages?.length) continue

    const log = messages.map((m) => `${m.role}: ${m.content}`).join("\n")
    const truncated = log.slice(0, 6000)

    try {
      const completion = await openai.chat.completions.create({
        model: MODEL,
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: `Chat log for this day:\n\n${truncated}` },
        ],
        temperature: TEMPERATURE,
        max_tokens: MAX_TOKENS,
      })
      const text = completion.choices[0]?.message?.content?.trim() ?? ""
      const cards = parseCards(text)
      const toCreate = cards.slice(0, 2 - count)
      for (const card of toCreate) {
        await supabase.from("insight_cards").insert({
          user_id: user.id,
          session_id: session.id,
          title: card.title,
          description: card.description,
          question: card.question,
        })
        generated++
        nonDiscussedBySession.set(session.id, (nonDiscussedBySession.get(session.id) ?? 0) + 1)
      }
    } catch (err) {
      console.error("Insight generate failed for session", session.id, err)
    }
  }

  await supabase.from("insight_generation_runs").insert({ user_id: user.id, run_date: today })
  return NextResponse.json({ generated })
}

function parseCards(text: string): { title: string; description: string; question: string }[] {
  const trimmed = text.trim()
  if (!trimmed) return []

  // If the model decides there isn't enough to work with, it will return this sentinel.
  if (trimmed === "NO_CARDS") {
    return []
  }

  const blocks = text.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean)
  const cards: { title: string; description: string; question: string }[] = []
  for (const block of blocks) {
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean)
    const title = lines[0] ?? ""
    const description = lines[1] ?? ""
    const question = lines[2] ?? ""
    // Minimal sanity check: require at least a non-empty title and description.
    if (!title || !description) continue
    cards.push({ title, description, question })
  }
  return cards
}
