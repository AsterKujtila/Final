import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

/**
 * POST /api/insights/use-card
 * Body: { cardId: string, markDiscussedOnly?: boolean }
 * - markDiscussedOnly: true → only mark card as discussed, return { ok: true }. Used when pasting into current chat.
 * - default → insert into that card's session: (1) user message with title and source=insight, (2) ai message.
 *   Marks the card as discussed. Returns sessionId and sessionDate for client to open chat.
 */
export async function POST(request: Request) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  let body: { cardId?: string; markDiscussedOnly?: boolean }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }
  const cardId = body.cardId
  if (!cardId || typeof cardId !== "string") {
    return NextResponse.json({ error: "cardId required" }, { status: 400 })
  }

  const { data: card, error: cardError } = await supabase
    .from("insight_cards")
    .select("id, user_id, session_id, title, description, question, discussed")
    .eq("id", cardId)
    .single()

  if (cardError || !card || card.user_id !== user.id) {
    return NextResponse.json({ error: "Card not found" }, { status: 404 })
  }
  if (card.discussed) {
    return NextResponse.json({ error: "Card already used" }, { status: 400 })
  }

  if (body.markDiscussedOnly === true) {
    await supabase.from("insight_cards").update({ discussed: true }).eq("id", cardId)
    return NextResponse.json({ ok: true })
  }

  const aiContent = [card.description, card.question].filter(Boolean).join("\n\n")

  const { data: userMsg, error: userMsgErr } = await supabase
    .from("chat_messages")
    .insert({
      session_id: card.session_id,
      role: "user",
      content: card.title,
      source: "insight",
    })
    .select("id")
    .single()

  if (userMsgErr) {
    return NextResponse.json({ error: "Failed to insert message" }, { status: 500 })
  }

  await supabase.from("chat_messages").insert({
    session_id: card.session_id,
    role: "ai",
    content: aiContent,
  })

  await supabase.from("insight_cards").update({ discussed: true }).eq("id", cardId)

  const { data: session } = await supabase
    .from("chat_sessions")
    .select("id, session_date")
    .eq("id", card.session_id)
    .single()

  return NextResponse.json({
    sessionId: card.session_id,
    sessionDate: session?.session_date ?? null,
  })
}
