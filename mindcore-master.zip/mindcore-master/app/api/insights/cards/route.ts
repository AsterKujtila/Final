import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

/**
 * GET /api/insights/cards
 * Returns non-discussed insight cards for the current user, with session_id and session_date for navigation.
 */
export async function GET() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { data: cards, error: cardsError } = await supabase
    .from("insight_cards")
    .select("id, session_id, title, description, question, created_at")
    .eq("user_id", user.id)
    .eq("discussed", false)
    .order("created_at", { ascending: false })

  if (cardsError) {
    return NextResponse.json({ error: cardsError.message }, { status: 500 })
  }

  if (!cards?.length) {
    return NextResponse.json({ cards: [] })
  }

  const sessionIds = [...new Set(cards.map((c) => c.session_id))]
  const { data: sessions } = await supabase
    .from("chat_sessions")
    .select("id, session_date")
    .in("id", sessionIds)
  const sessionDateById = new Map<string, string>()
  for (const s of sessions ?? []) {
    sessionDateById.set(s.id, String(s.session_date))
  }

  const result = (cards ?? []).map((c) => ({
    id: c.id,
    sessionId: c.session_id,
    sessionDate: sessionDateById.get(c.session_id) ?? null,
    title: c.title,
    body: [c.description, c.question].filter(Boolean).join(" "),
    question: c.question ?? null,
    badge: "REFLECTION FOR YOU",
  }))

  return NextResponse.json({ cards: result })
}
