import { NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { commitUncommittedBufferToPinecone } from "@/lib/commit-memory-buffer"

/**
 * GET/POST /api/cron/commit-memory
 * Optional: call via an external scheduler (e.g. cron-job.org) if you want to commit uncommitted
 * memory_buffer rows for all users on a schedule. Not required—the chat route commits new memories
 * immediately, and post-process commits backlog for the active user when the client calls it.
 * Secure with CRON_SECRET: send Authorization: Bearer <CRON_SECRET> or x-cron-secret header.
 */
export async function GET(request: Request) {
  return runCommit(request)
}

export async function POST(request: Request) {
  return runCommit(request)
}

async function runCommit(request: Request): Promise<NextResponse> {
  const secret = process.env.CRON_SECRET
  const isVercelCron = request.headers.get("x-vercel-cron") === "1"
  if (!isVercelCron && secret) {
    const authHeader = request.headers.get("authorization")
    const bearer = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null
    const headerSecret = request.headers.get("x-cron-secret")
    if (bearer !== secret && headerSecret !== secret) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
  }

  try {
    const admin = createAdminClient()
    const { processed, errors } = await commitUncommittedBufferToPinecone(admin)
    return NextResponse.json({ ok: true, processed, errors })
  } catch (err) {
    console.error("Cron commit-memory failed:", err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Commit failed" },
      { status: 500 }
    )
  }
}
