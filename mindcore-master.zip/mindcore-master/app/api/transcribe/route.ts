import OpenAI from "openai"
import { NextResponse } from "next/server"

const MODEL = "whisper-1"
const MAX_FILE_MB = 25

/**
 * POST /api/transcribe
 * Body: multipart/form-data with "file" (audio blob) or raw body as audio
 * Returns { text: string } from OpenAI Whisper.
 */
export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: "OPENAI_API_KEY not configured" }, { status: 500 })
  }

  let buffer: ArrayBuffer
  let contentType = "audio/webm"

  const contentTypeHeader = request.headers.get("content-type") ?? ""
  if (contentTypeHeader.includes("multipart/form-data")) {
    const formData = await request.formData()
    const file = formData.get("file")
    if (!file || !(file instanceof Blob)) {
      return NextResponse.json({ error: "Missing or invalid file in form" }, { status: 400 })
    }
    buffer = await file.arrayBuffer()
    contentType = file.type || "audio/webm"
  } else {
    buffer = await request.arrayBuffer()
    contentType = request.headers.get("content-type") || "audio/webm"
  }

  if (buffer.byteLength === 0) {
    return NextResponse.json({ error: "Empty audio" }, { status: 400 })
  }
  if (buffer.byteLength > MAX_FILE_MB * 1024 * 1024) {
    return NextResponse.json({ error: "Audio too large" }, { status: 400 })
  }

  const openai = new OpenAI({ apiKey })
  const extension = contentType.includes("mp3") ? "mp3" : contentType.includes("wav") ? "wav" : "webm"
  const file = new File([buffer], `audio.${extension}`, { type: contentType })

  try {
    const transcription = await openai.audio.transcriptions.create({
      file,
      model: MODEL,
    })
    const text = (transcription as { text?: string }).text?.trim() ?? ""
    return NextResponse.json({ text })
  } catch (err) {
    console.error("Transcribe failed:", err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Transcription failed" },
      { status: 500 }
    )
  }
}
