import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"
import { commitUncommittedBufferToPinecone } from "@/lib/commit-memory-buffer"

/**
 * POST: Commit trigger (build_plan).
 * Sends uncommitted memory_buffer rows for this user to Pinecone, then sets committed = true.
 * New memories are committed immediately in the chat route; this catches any backlog when the client calls post-process (e.g. every N messages or on idle). No cron required.
 */
export async function POST(request: Request) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  let body: { sessionId?: string }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }

  const sessionId = body.sessionId
  if (!sessionId || typeof sessionId !== "string") {
    return NextResponse.json({ error: "sessionId required" }, { status: 400 })
  }

  const { data: session, error: sessionError } = await supabase
    .from("chat_sessions")
    .select("id, user_id, last_message_at, session_date")
    .eq("id", sessionId)
    .single()

  if (sessionError || !session || session.user_id !== user.id) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 })
  }

  await commitUncommittedBufferToPinecone(supabase, { userId: user.id })

  // --- Session metadata (title/summary/reflection) ---
  const { data: messages } = await supabase
    .from("chat_messages")
    .select("role, content")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: true })

  const context = (messages ?? []).map((m) => `${m.role}: ${m.content}`).join("\n")
  const title = generateStubTitle(context)
  const summary = generateStubSummary(context)
  const reflection = generateStubReflection(context)

  const { error: updateError } = await supabase
    .from("chat_sessions")
    .update({
      title,
      summary,
      reflection,
      updated_at: new Date().toISOString(),
    })
    .eq("id", sessionId)

  if (updateError) {
    return NextResponse.json({ error: "Failed to update session" }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}

function generateStubTitle(_context: string): string {
  return "Today's conversation"
}

function generateStubSummary(_context: string): string {
  return "A reflection on what you shared today. Keep exploring at your own pace."
}

function generateStubReflection(_context: string): string {
  return "Your reflection is forming. The more you share over time, the more meaningful it becomes. Check back after more conversations."
}
