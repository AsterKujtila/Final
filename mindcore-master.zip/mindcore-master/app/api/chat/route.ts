import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { getChatReply } from "@/lib/chat-completion"
import { getEmbedding, queryMemory, upsertMemory } from "@/lib/vector-memory"
import { generateTurnMemory } from "@/lib/turn-memory"

const STRENGTH_THRESHOLD = 0.5

export async function POST(request: Request) {
  let body: {
    messages?: { role: string; content: string }[]
    userId?: string
    sessionId?: string
    reflectionContext?: string
  }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }

  const messages = body.messages
  if (!Array.isArray(messages) || messages.length === 0) {
    return NextResponse.json({ error: "messages array required" }, { status: 400 })
  }

  const lastUserMessage = [...messages].reverse().find((m) => m.role === "user" && m.content?.trim())
  const lastUserText = lastUserMessage?.content?.trim() ?? ""
  const userId = typeof body.userId === "string" ? body.userId : undefined
  const sessionId = typeof body.sessionId === "string" ? body.sessionId : undefined
  const reflectionContext = typeof body.reflectionContext === "string" ? body.reflectionContext.trim() : undefined

  let content: string
  let route: "CBT" | "Crisis"
  let confidence: number
  try {
    const result = await getChatReply({
      messages,
      reflectionContext,
      userId,
      sessionId,
    })
    content = result.content
    route = result.route
    confidence = 0.8
  } catch (err) {
    console.error("OpenAI chat error:", err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Chat completion failed" },
      { status: 500 }
    )
  }

  // Turn memory: decide if worth saving long-term; if yes, buffer + Pinecone (CBT only)
  if (userId && sessionId && lastUserText && content) {
    try {
      const turnMemory = await generateTurnMemory(lastUserText, content)
      const sentence = turnMemory.memory_candidate?.trim()
      const worthSaving =
        sentence &&
        turnMemory.strength_score >= STRENGTH_THRESHOLD &&
        route !== "Crisis"
      if (worthSaving) {
        const supabase = await createClient()
        const sessionDate = new Date().toISOString().slice(0, 10)
        const { data: row, error: insertErr } = await supabase
          .from("memory_buffer")
          .insert({
            user_id: userId,
            session_id: sessionId,
            turn_summary: turnMemory.turn_summary || null,
            memory_candidate: sentence,
            strength_score: turnMemory.strength_score,
            is_crisis: false,
            committed: false,
          })
          .select("id")
          .single()
        if (!insertErr && row?.id) {
          await upsertMemory(userId, row.id, sentence, {
            session_date: sessionDate,
            session_id: sessionId,
            summary: sentence.slice(0, 1000),
          })
          await supabase
            .from("memory_buffer")
            .update({ committed: true })
            .eq("id", row.id)
        }
      }
    } catch (err) {
      console.error("Turn memory / buffer / Pinecone failed:", err)
    }
  }

  return NextResponse.json({ content, route, confidence })
}
