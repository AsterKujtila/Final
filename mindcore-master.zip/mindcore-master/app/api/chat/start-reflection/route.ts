import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { getChatReply } from "@/lib/chat-completion"
import { getSessionDayInfo } from "@/lib/chat-session-utils"

/**
 * POST /api/chat/start-reflection
 * Body: { weekStart: string, title: string, summary: string, reflectionContext: string }
 * Creates the reflection card message and first AI reply in today's session, sets conversation_started_at, returns sessionId.
 * Client redirects to /chat?sessionId=<id>.
 */
export async function POST(request: Request) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  let body: { weekStart?: string; title?: string; summary?: string; reflectionContext?: string }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }
  const weekStart = body.weekStart?.trim()
  const title = (body.title?.trim() || "Weekly Reflection").slice(0, 2000)
  const summary = (body.summary?.trim() || "").slice(0, 5000)
  const reflectionContext = body.reflectionContext?.trim()?.slice(0, 15000)

  if (!weekStart || !/^\d{4}-\d{2}-\d{2}$/.test(weekStart)) {
    return NextResponse.json({ error: "weekStart (YYYY-MM-DD) required" }, { status: 400 })
  }

  const { sessionDate, dayOfWeek, timeOfDay } = getSessionDayInfo(new Date())
  const now = new Date().toISOString()

  let { data: session } = await supabase
    .from("chat_sessions")
    .select("id")
    .eq("user_id", user.id)
    .eq("session_date", sessionDate)
    .maybeSingle()

  if (!session) {
    const { data: newSession, error: insertErr } = await supabase
      .from("chat_sessions")
      .insert({
        user_id: user.id,
        session_date: sessionDate,
        day_of_week: dayOfWeek,
        time_of_day: timeOfDay,
        started_at: now,
        last_message_at: now,
      })
      .select("id")
      .single()
    if (insertErr || !newSession) {
      return NextResponse.json({ error: "Failed to create session" }, { status: 500 })
    }
    session = newSession
  }

  const displayContent = [title, summary].filter(Boolean).join("\n\n") || title

  const { error: userMsgErr } = await supabase.from("chat_messages").insert({
    session_id: session.id,
    role: "user",
    content: displayContent,
    source: "insight",
  })

  if (userMsgErr) {
    return NextResponse.json({ error: "Failed to insert message" }, { status: 500 })
  }

  const apiKey = process.env.OPENAI_API_KEY
  let content: string
  let route: "CBT" | "Crisis"
  if (!apiKey) {
    content = "I'm here. What would you like to explore?"
    route = "CBT"
  } else {
    try {
      const result = await getChatReply({
        messages: [{ role: "user", content: displayContent }],
        reflectionContext: reflectionContext || undefined,
        userId: user.id,
        sessionId: session.id,
      })
      content = result.content
      route = result.route
    } catch (err) {
      console.error("start-reflection getChatReply error:", err)
      content = "I'm here. What would you like to explore?"
      route = "CBT"
    }
  }

  await supabase.from("chat_messages").insert({
    session_id: session.id,
    role: "ai",
    content,
  })

  if (route === "Crisis") {
    await supabase
      .from("chat_messages")
      .insert({ session_id: session.id, role: "ai", content: "", source: "crisis_card" })
  }

  await supabase
    .from("chat_sessions")
    .update({ last_message_at: new Date().toISOString() })
    .eq("id", session.id)

  await supabase
    .from("weekly_reflections")
    .update({ conversation_started_at: new Date().toISOString() })
    .eq("user_id", user.id)
    .eq("week_start", weekStart)

  return NextResponse.json({ sessionId: session.id })
}
