import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { getChatReply } from "@/lib/chat-completion"
import { getSessionDayInfo } from "@/lib/chat-session-utils"

/**
 * POST /api/chat/start-insight
 * Body: { cardId: string }
 * Creates the insight card message and first AI reply in the card's session, marks card discussed, returns sessionId.
 * Client redirects to /chat?sessionId=<id> so chat loads with messages already in DB.
 */
export async function POST(request: Request) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  let body: { cardId?: string }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }
  const cardId = body.cardId?.trim()
  if (!cardId) {
    return NextResponse.json({ error: "cardId required" }, { status: 400 })
  }

  const { data: card, error: cardError } = await supabase
    .from("insight_cards")
    .select("id, user_id, session_id, title, description, question, discussed")
    .eq("id", cardId)
    .single()

  if (cardError || !card || card.user_id !== user.id) {
    return NextResponse.json({ error: "Card not found" }, { status: 404 })
  }
  if (card.discussed) {
    return NextResponse.json({ error: "Card already used" }, { status: 400 })
  }

  const displayContent = [card.title, [card.description, card.question].filter(Boolean).join(" ")]
    .filter(Boolean)
    .join("\n\n")
  const promptForModel = (card.question && card.question.trim()) || card.title || displayContent

  // Use today's logical session (same behavior as main chat / reflection),
  // so that re-opening /chat without a sessionId still shows this conversation.
  const { sessionDate, dayOfWeek, timeOfDay } = getSessionDayInfo(new Date())
  const now = new Date().toISOString()

  let { data: session } = await supabase
    .from("chat_sessions")
    .select("id")
    .eq("user_id", user.id)
    .eq("session_date", sessionDate)
    .maybeSingle()

  if (!session) {
    const { data: newSession, error: insertErr } = await supabase
      .from("chat_sessions")
      .insert({
        user_id: user.id,
        session_date: sessionDate,
        day_of_week: dayOfWeek,
        time_of_day: timeOfDay,
        started_at: now,
        last_message_at: now,
      })
      .select("id")
      .single()
    if (insertErr || !newSession) {
      return NextResponse.json({ error: "Failed to create session" }, { status: 500 })
    }
    session = newSession
  }

  const { error: userMsgErr } = await supabase.from("chat_messages").insert({
    session_id: session.id,
    role: "user",
    content: displayContent,
    source: "insight",
  })

  if (userMsgErr) {
    return NextResponse.json({ error: "Failed to insert message" }, { status: 500 })
  }

  const apiKey = process.env.OPENAI_API_KEY
  let content: string
  let route: "CBT" | "Crisis"
  if (!apiKey) {
    content = "I'm here. What would you like to explore?"
    route = "CBT"
  } else {
    try {
      const result = await getChatReply({
        messages: [{ role: "user", content: promptForModel }],
        userId: user.id,
        sessionId: session.id,
      })
      content = result.content
      route = result.route
    } catch (err) {
      console.error("start-insight getChatReply error:", err)
      content = "I'm here. What would you like to explore?"
      route = "CBT"
    }
  }

  await supabase.from("chat_messages").insert({ session_id: session.id, role: "ai", content })

  if (route === "Crisis") {
    await supabase
      .from("chat_messages")
      .insert({ session_id: session.id, role: "ai", content: "", source: "crisis_card" })
  }

  await supabase.from("insight_cards").update({ discussed: true }).eq("id", cardId)
  await supabase
    .from("chat_sessions")
    .update({ last_message_at: new Date().toISOString() })
    .eq("id", session.id)

  return NextResponse.json({ sessionId: session.id })
}
