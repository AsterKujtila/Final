"use client"

import { createClient } from "@/lib/supabase/client"
import { useRouter, useSearchParams } from "next/navigation"
import { Suspense, useEffect, useState } from "react"

// OAuth is started by /api/auth/google (server sets PKCE verifier in HttpOnly cookie, then callback exchanges code on server).

function LoginContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [pressing, setPressing] = useState(false)

  useEffect(() => {
    const supabase = createClient()
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        router.replace("/")
        router.refresh()
      }
    })
    return () => subscription.unsubscribe()
  }, [router])

  const handleGoogleSignIn = () => {
    window.location.href = "/api/auth/google"
  }

  return (
    <div className="min-h-dvh relative overflow-hidden">
      <div className="absolute inset-0 onboarding-gradient noise-overlay" />
      <div className="relative z-10 min-h-dvh flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-8">
          <h1 className="text-6xl font-serif text-foreground text-center leading-tight mb-4">
            Get Started
          </h1>
          <p className="text-sm font-sans font-semibold text-foreground/80 text-center">
            Get Started with MindCore
          </p>
          {searchParams.get("error") === "auth" && (
            <p className="mt-4 text-sm font-sans text-red-600 dark:text-red-400 text-center max-w-sm">
              Sign-in failed. {searchParams.get("message") ? decodeURIComponent(searchParams.get("message")!) : "Please try again."}
            </p>
          )}
        </div>
        <div className="px-8 pb-10">
          <button
            onClick={handleGoogleSignIn}
            onPointerDown={() => setPressing(true)}
            onPointerUp={() => setPressing(false)}
            onPointerLeave={() => setPressing(false)}
            className="btn-continue w-full py-4 rounded-full font-sans font-semibold text-base flex items-center justify-center gap-3 transition-all duration-150"
            style={{
              background: pressing ? "#e8e0d8" : "#ffffff",
              color: "#1a1412",
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
            </svg>
            Continue with Google
          </button>
          <p className="text-xs font-sans text-foreground/60 text-center mt-4 leading-relaxed">
            {"By signing up for MindCore you agree to our "}
            <span className="font-bold text-foreground/80 underline">Terms of Service</span>
          </p>
        </div>
      </div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-dvh relative overflow-hidden">
        <div className="absolute inset-0 onboarding-gradient noise-overlay" />
        <div className="relative z-10 min-h-dvh flex flex-col items-center justify-center">
          <p className="text-sm font-sans text-foreground/80">Loading…</p>
        </div>
      </div>
    }>
      <LoginContent />
    </Suspense>
  )
}
