import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"
import { cookies } from "next/headers"

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPABASE_ANON_KEY =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

/**
 * OAuth callback. Reads PKCE verifier from cookie, exchanges code via Supabase
 * token endpoint, then persists session with setSession (no client storage lookup).
 */
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get("code")
  const cookieStore = await cookies()
  const verifier = cookieStore.get("sb-pkce-verifier")?.value

  if (!code || !verifier) {
    const msg = encodeURIComponent(
      "Missing code or verifier. Try signing in again."
    )
    return NextResponse.redirect(`${origin}/login?error=auth&message=${msg}`)
  }

  const tokenRes = await fetch(
    `${SUPABASE_URL}/auth/v1/token?grant_type=pkce`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ auth_code: code, code_verifier: verifier }),
    }
  )

  const tokenData = await tokenRes.json()
  if (!tokenRes.ok || tokenData.error) {
    const msg = encodeURIComponent(
      tokenData?.error_description || tokenData?.message || "Token exchange failed"
    )
    return NextResponse.redirect(`${origin}/login?error=auth&message=${msg}`)
  }

  const access_token = tokenData.access_token
  const refresh_token = tokenData.refresh_token
  if (!access_token || !refresh_token) {
    const msg = encodeURIComponent("Invalid token response")
    return NextResponse.redirect(`${origin}/login?error=auth&message=${msg}`)
  }

  const supabase = await createClient()
  const { error: sessionError } = await supabase.auth.setSession({
    access_token,
    refresh_token,
  })
  if (sessionError) {
    const msg = encodeURIComponent(sessionError.message)
    return NextResponse.redirect(`${origin}/login?error=auth&message=${msg}`)
  }

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.redirect(`${origin}/login`)
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("id")
    .eq("id", user.id)
    .single()

  const redirectUrl = profile ? `${origin}/chat` : `${origin}/onboardingpage`
  const response = NextResponse.redirect(redirectUrl)
  response.cookies.set("sb-pkce-verifier", "", {
    path: "/",
    maxAge: 0,
    httpOnly: true,
    secure: true,
    sameSite: "none",
  })
  return response
}
