## MindCore

MindCore is an experimental AI platform that analyzes cognitive patterns and produces structured reasoning outputs to help users think through complex problems more clearly. It was originally developed for the Genius Olympiad as a prototype for AI-supported decision-making, learning, and problem solving.

### What it does

- **Cognitive pattern analysis**: Takes free-form user input and identifies relationships between concepts.
- **Structured reasoning engine**: Turns raw input into step-by-step reasoning traces and conclusions.
- **Decision support**: Suggests next steps, alternatives, and tradeoffs rather than a single “answer”.
- **Modular architecture**: Designed so different AI models and reasoning strategies can be swapped in over time.

### How it works (high level)

1. **Input processing**: User messages are cleaned and normalized into a structured format.
2. **Routing and safety**: A small OpenAI-powered router model classifies messages (e.g. normal CBT-style reflection vs. possible crisis language) to select the right behavior while avoiding over-triggering.
3. **Reasoning + memory**: The main chat pipeline uses OpenAI models plus a Pinecone vector index to pull in user-specific context and past distilled summaries, building a richer system prompt for each reply.
4. **Output generation**: The app returns short, focused reasoning-style responses in a Next.js UI optimized for reflection and clarity.

### Technical stack

- **Frontend / App**: Next.js (App Router) with React, Tailwind-based styling, Radix UI components, and PWA support.
- **Backend**: Next.js API routes deployed on Vercel.
- **Authentication & data**: Supabase (hosted Postgres + auth) for user accounts, sessions, and core relational data.
- **AI models**: OpenAI chat and embedding models (configured via environment variables; no keys are stored in this repo).
- **Vector memory**: Pinecone (`text-embedding-3-small`) for per-user “distilled knowledge” that is queried at runtime.
- **Analytics & misc**: Vercel Analytics, TypeScript, and a small internal routing layer for CBT vs. crisis-style behavior.

### Environment and deployment (overview)

- All secrets (OpenAI, Supabase, Pinecone, cron secrets) are loaded from environment variables (see `.env.example`).
- Local and production environments should configure env vars directly (e.g. Vercel project settings); `.env.local` must never be committed.
- The repository is structured to be deployed to Vercel out of the box once environment variables and Supabase/Pinecone are configured.

### License

All rights reserved.
