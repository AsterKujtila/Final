const CACHE_NAME = 'mindcore-pwa-v2'

const PRECACHE_URLS = [
  '/',
  '/chat',
  '/history',
  '/youpage',
  '/insights',
  '/reflection',
  '/onboardingpage',
  '/favicons/favicon-16x16.png',
  '/favicons/favicon-32x32.png',
  '/favicons/android-chrome-192x192.png',
  '/favicons/android-chrome-512x512.png',
  '/favicons/apple-touch-icon.png',
  '/favicons/manifest.json',
]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .catch(() => {})
  )
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.map((key) => {
            if (key !== CACHE_NAME) {
              return caches.delete(key)
            }
          })
        )
      )
      .then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', (event) => {
  const { request } = event

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy))
          return response
        })
        .catch(async () => {
          const cache = await caches.open(CACHE_NAME)
          const cached = (await cache.match(request)) || (await cache.match('/'))
          if (cached) return cached

          return new Response(
            '<!doctype html><html><head><meta charset="utf-8"><title>MindCore</title></head><body><main style="font-family:sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center;background:#0b090a;color:#f8f9fa;padding:1.5rem;text-align:center;"><div><h1 style="font-size:1.5rem;margin-bottom:0.75rem;">You are offline</h1><p style="max-width:22rem;margin:0 auto 0.5rem;opacity:0.9;">MindCore is installed on this device. Any conversations and reflections you\'ve already opened will be available again once you\'re back online.</p></div></main></body></html>',
            {
              headers: {
                'Content-Type': 'text/html; charset=utf-8',
              },
            }
          )
        })
    )
    return
  }

  if (
    request.method === 'GET' &&
    request.url.startsWith(self.location.origin) &&
    ['script', 'style', 'image', 'font'].includes(request.destination)
  ) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached
        return fetch(request)
          .then((response) => {
            const copy = response.clone()
            caches.open(CACHE_NAME).then((cache) => cache.put(request, copy))
            return response
          })
          .catch(() => caches.match('/favicons/android-chrome-192x192.png'))
      })
    )
    return
  }

  event.respondWith(fetch(request))
})
