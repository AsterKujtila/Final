"use client"

import { useRef, useEffect, useState, useCallback } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { MenuIcon } from "./menu-icon"
import { AudioWaveIcon } from "./audio-wave-icon"

interface InsightsPageProps {
  onBack: () => void
  onMenu: () => void
}

interface InsightCard {
  id: string
  sessionId: string
  sessionDate: string | null
  badge: string
  title: string
  body: string
  question: string | null
}

export function InsightsPage({ onBack, onMenu }: InsightsPageProps) {
  const router = useRouter()
  const scrollRef = useRef<HTMLDivElement>(null)
  const [cards, setCards] = useState<InsightCard[]>([])
  const [loading, setLoading] = useState(true)
  const [usingCardId, setUsingCardId] = useState<string | null>(null)
  const [activeIndex, setActiveIndex] = useState(0)
  const cardRefs = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    let cancelled = false
    async function run() {
      setLoading(true)
      const res = await fetch("/api/insights/cards")
      if (cancelled) return
      const data = await res.json()
      setCards(data.cards ?? [])
      setLoading(false)
    }
    run()
    return () => { cancelled = true }
  }, [])

  const handleScroll = useCallback(() => {
    if (!scrollRef.current) return
    const container = scrollRef.current
    const containerRect = container.getBoundingClientRect()
    const centerY = containerRect.top + containerRect.height / 2

    let closestIdx = 0
    let closestDist = Infinity

    cardRefs.current.forEach((card, idx) => {
      if (!card) return
      const cardRect = card.getBoundingClientRect()
      const cardCenter = cardRect.top + cardRect.height / 2
      const dist = Math.abs(cardCenter - centerY)
      if (dist < closestDist) {
        closestDist = dist
        closestIdx = idx
      }
    })

    setActiveIndex(closestIdx)
  }, [])

  useEffect(() => {
    const container = scrollRef.current
    if (!container) return
    container.addEventListener("scroll", handleScroll, { passive: true })
    return () => container.removeEventListener("scroll", handleScroll)
  }, [handleScroll, cards.length])

  const handleStartConversation = useCallback(
    async (card: InsightCard) => {
      if (usingCardId) return
      setUsingCardId(card.id)
      try {
        const res = await fetch("/api/chat/start-insight", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ cardId: card.id }),
        })
        const data = await res.json().catch(() => ({}))
        if (!res.ok) {
          console.error(data.error ?? "Failed to start conversation")
          return
        }
        const sid = data.sessionId
        setCards((prev) => prev.filter((c) => c.id !== card.id))
        if (sid) {
          router.push(`/chat?sessionId=${encodeURIComponent(sid)}`)
        } else {
          router.push("/chat")
        }
      } catch (e) {
        console.error(e)
      } finally {
        setUsingCardId(null)
      }
    },
    [usingCardId, router]
  )

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <header className="flex items-center justify-between px-5 pt-4 pb-2 shrink-0">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full glass flex items-center justify-center"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
        <h1 className="text-xs font-sans font-semibold tracking-[0.2em] text-foreground/90 uppercase">
          Insights
        </h1>
        <button
          onClick={onMenu}
          className="w-10 h-10 rounded-full glass flex items-center justify-center"
          aria-label="Open menu"
        >
          <MenuIcon />
        </button>
      </header>

      {/* Snap-scroll card area */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto snap-container no-scrollbar px-5 py-6"
      >
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <p className="text-sm font-sans text-foreground/60">Loading insights...</p>
          </div>
        ) : cards.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3">
            <p className="text-sm font-sans text-foreground/60 text-center">
              No insights yet. Keep chatting and we’ll suggest reflections from your conversations.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-5">
            {cards.map((card, idx) => {
              const isActive = idx === activeIndex
              const isUsing = usingCardId === card.id
              return (
                <div
                  key={card.id}
                  ref={(el) => { cardRefs.current[idx] = el }}
                  className="snap-card transition-all duration-300 ease-out"
                  style={{
                    transform: isActive ? "scale(1)" : "scale(0.92)",
                    opacity: isActive ? 1 : 0.6,
                  }}
                >
                  <div
                    className="rounded-3xl p-6 bg-[#AF9D8E] text-[#1A1412] transition-all duration-300"
                    style={{ minHeight: "380px" }}
                  >
                    {/* Badge */}
                    <div className="flex justify-center mb-5">
                      <span className="text-[10px] font-sans font-semibold tracking-[0.15em] text-foreground/70 uppercase bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10">
                        {card.badge}
                      </span>
                    </div>

                    {/* Title */}
                    <h2 className="text-2xl font-serif leading-tight mb-4 text-balance">
                      {card.title}
                    </h2>

                    {/* Body */}
                    <p className="text-sm font-sans text-black/75 leading-relaxed mb-6">
                      {card.body}
                    </p>

                    {/* Input - tap to open in daily chat */}
                    {isActive && (
                      <button
                        type="button"
                        onClick={() => handleStartConversation(card)}
                        disabled={isUsing}
                        className="w-full glass rounded-full flex items-center px-5 py-3 gap-3 mt-auto disabled:opacity-60"
                      >
                        <span className="flex-1 text-sm font-sans text-foreground/40 text-left">
                          {isUsing ? "Opening conversation…" : "Start a conversation"}
                        </span>
                        <div className="w-9 h-9 rounded-full glass-strong flex items-center justify-center shrink-0">
                          <AudioWaveIcon />
                        </div>
                      </button>
                    )}
                  </div>
                </div>
              )
            })}
            {/* Bottom spacer for scroll */}
            <div className="h-32" aria-hidden="true" />
          </div>
        )}
      </div>
    </div>
  )
}
