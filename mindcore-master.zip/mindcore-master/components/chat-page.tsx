"use client"

import { useState, useRef, useEffect, useCallback, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { AudioWaveIcon } from "./audio-wave-icon"
import { ArrowUp, ArrowLeft, ArrowDown, Mic, MicOff, Keyboard, Volume2, Copy as CopyIcon, Flag, Heart } from "lucide-react"
import { Drawer, DrawerContent, DrawerTrigger, DrawerHeader, DrawerDescription, DrawerFooter, DrawerClose } from "@/components/ui/drawer"
import { Button } from "@/components/ui/button"
import { ReflectionStatusIcon } from "./reflection-status"
import { createClient } from "@/lib/supabase/client"
import { getSessionDayInfo } from "@/lib/chat-session-utils"
import { cn } from "@/lib/utils"
import { CrisisCard } from "@/components/crisis-card"

function getCurrentDate(): string {
  const now = new Date()
  const days = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"]
  const months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
  return `${days[now.getDay()]} ${now.getDate()} ${months[now.getMonth()]}`
}

// Idle threshold before post-process (reflection/title/summary) runs. 3 min for testing; use 2 * 60 * 60 * 1000 for production.
const IDLE_POSTPROCESS_MS = 3 * 60 * 1000
// Vector memory is saved every N user messages (post-process runs on 10th, 20th, ...).
const USER_MESSAGES_PER_VECTOR_CYCLE = 10

const CHAT_PLACEHOLDERS = [
  "You can start mid-sentence.",
  "Messy thoughts are welcome.",
  "Say it badly.",
  "No rush. You arrived.",
]
const PLACEHOLDER_ROTATE_MS = 4500

interface Message {
  id: string
  text: string
  sender: "user" | "ai"
  source?: string | null
}

const FALLBACK_AI_MESSAGE = "I'm here. Could you say a bit more?"

interface WeeklyReflectionStatus {
  currentWeek: {
    weekStart: string
    weekEnd: string
    progress: number
    hasAnyChat: boolean
    totalDays: number
  }
  lastWeek: {
    weekStart: string
    weekEnd: string
    hasAnyChat: boolean
    hasReflection: boolean
    cycleCompleted: boolean
  }
}

const REFLECTION_CONTEXT_KEY = "mindcore_reflection_context"
const REFLECTION_TITLE_KEY = "mindcore_reflection_title"
const REFLECTION_SUMMARY_KEY = "mindcore_reflection_summary"
const REFLECTION_WEEK_KEY = "mindcore_reflection_week"
const INSIGHT_TITLE_KEY = "mindcore_insight_title"
const INSIGHT_SUMMARY_KEY = "mindcore_insight_summary"
const INSIGHT_CARD_ID_KEY = "mindcore_insight_card_id"
const INSIGHT_QUESTION_KEY = "mindcore_insight_question"

export type Route = "CBT" | "Crisis"

async function fetchAiReply(
  messages: Message[],
  userContent: string,
  sessionId: string | null,
  reflectionContext?: string | null
): Promise<{ content: string; route: Route }> {
  const apiMessages = [
    ...messages.map((m) => ({
      role: m.sender === "ai" ? "assistant" : "user",
      content: m.text,
    })),
    { role: "user" as const, content: userContent },
  ]
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const body: { messages: typeof apiMessages; userId?: string; sessionId?: string; reflectionContext?: string } = {
    messages: apiMessages,
  }
  if (user?.id) body.userId = user.id
  if (sessionId) body.sessionId = sessionId
  if (reflectionContext) body.reflectionContext = reflectionContext
  const res = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  })
  if (!res.ok) {
    const data = await res.json().catch(() => ({}))
    throw new Error(data.error ?? `Request failed: ${res.status}`)
  }
  const data = await res.json()
  const content = typeof data.content === "string" ? data.content.trim() : FALLBACK_AI_MESSAGE
  const route: Route = data.route === "Crisis" ? "Crisis" : "CBT"
  return { content, route }
}

type VoiceState = "idle" | "preparing" | "listening" | "mic_off" | "transcribing" | "thinking" | "answering"

interface ChatPageProps {
  onBack: () => void
  onActiveChange?: (active: boolean) => void
}

function ChatPageInner({ onBack, onActiveChange }: ChatPageProps) {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isThinking, setIsThinking] = useState(false)
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [sessionLoading, setSessionLoading] = useState(true)
  const lastMessageAtRef = useRef<number | null>(null)
  const [voiceState, setVoiceState] = useState<VoiceState>("idle")
  const [voiceAnswer, setVoiceAnswer] = useState("")
  const [voiceDisplayLength, setVoiceDisplayLength] = useState(0)
  const [voiceStatusLabel, setVoiceStatusLabel] = useState("")
  const [voiceAudioLevel, setVoiceAudioLevel] = useState(0)
  const [showScrollToBottom, setShowScrollToBottom] = useState(false)
  const voiceModeActiveRef = useRef(true)
  const voiceStreamRef = useRef<MediaStream | null>(null)
  const voiceRecorderRef = useRef<MediaRecorder | null>(null)
  const voiceChunksRef = useRef<Blob[]>([])
  const voiceSilenceTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const voicePostBufferTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const voiceAnalyserRef = useRef<AnalyserNode | null>(null)
  const voiceLevelAnimationRef = useRef<number | null>(null)
  const voiceStateRef = useRef<VoiceState>("idle")
  const voiceAnswerAudioRef = useRef<HTMLAudioElement | null>(null)
  const startVoiceModeRef = useRef<(() => Promise<void>) | null>(null)
  const userRequestedMicOffRef = useRef(false)
  voiceStateRef.current = voiceState
  const [placeholderIndex, setPlaceholderIndex] = useState(0)
  const [contextMenu, setContextMenu] = useState<{
    open: boolean
    x: number
    y: number
    message: Message | null
  }>({
    open: false,
    x: 0,
    y: 0,
    message: null,
  })
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const messagesContainerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const [textareaHeight, setTextareaHeight] = useState(24)
  const messagesRef = useRef<Message[]>(messages)
  messagesRef.current = messages
  const focusInputAfterOpenRef = useRef(false)
  const longPressTimeoutRef = useRef<number | null>(null)
  const longPressStartRef = useRef<{ x: number; y: number } | null>(null)
  const [reportDrawerOpen, setReportDrawerOpen] = useState(false)
  const [reportedMessageIds, setReportedMessageIds] = useState<Set<string>>(new Set())
  const [greeting, setGreeting] = useState<string | null>(null)
  const readOnly = searchParams.get("mode") === "readonly"
  const [reflectionStatus, setReflectionStatus] = useState<WeeklyReflectionStatus | null>(null)
  const [reflectionStatusLoading, setReflectionStatusLoading] = useState(false)

  const hasMessages = messages.length > 0
  const hasText = inputValue.trim().length > 0
  const inVoiceMode = voiceState !== "idle"
  const isActive = hasMessages || inVoiceMode

  // Load session and messages: from ?sessionId= (e.g. from insights) or current day
  useEffect(() => {
    const supabase = createClient()
    const sessionIdFromUrl = searchParams.get("sessionId")
    const run = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        setSessionLoading(false)
        return
      }
      if (sessionIdFromUrl) {
        const { data: session, error } = await supabase
          .from("chat_sessions")
          .select("id, last_message_at")
          .eq("id", sessionIdFromUrl)
          .eq("user_id", user.id)
          .maybeSingle()
        if (session && !error) {
          setSessionId(session.id)
          lastMessageAtRef.current = session.last_message_at
            ? new Date(session.last_message_at).getTime()
            : null
          const { data: rows } = await supabase
            .from("chat_messages")
            .select("id, role, content, source")
            .eq("session_id", session.id)
            .order("created_at", { ascending: true })
          setMessages(
            (rows ?? []).map((r) => ({
              id: r.id,
              text: r.content,
              sender: r.role as "user" | "ai",
              source: r.source ?? undefined,
            }))
          )
        }
      } else {
        const { sessionDate } = getSessionDayInfo()
        const { data: session } = await supabase
          .from("chat_sessions")
          .select("id, last_message_at")
          .eq("user_id", user.id)
          .eq("session_date", sessionDate)
          .maybeSingle()
        if (session) {
          setSessionId(session.id)
          lastMessageAtRef.current = session.last_message_at
            ? new Date(session.last_message_at).getTime()
            : null
          const { data: rows } = await supabase
            .from("chat_messages")
            .select("id, role, content, source")
            .eq("session_id", session.id)
            .order("created_at", { ascending: true })
          if (rows?.length) {
            setMessages(
              rows.map((r) => ({
                id: r.id,
                text: r.content,
                sender: r.role as "user" | "ai",
                source: r.source ?? undefined,
              }))
            )
          }
        }
      }
      setSessionLoading(false)
    }
    run()
  }, [searchParams])

  const refreshReflectionStatus = useCallback(async () => {
    try {
      setReflectionStatusLoading(true)
      const res = await fetch("/api/reflection/status")
      if (!res.ok) return
      const data = (await res.json()) as WeeklyReflectionStatus
      setReflectionStatus(data)
    } finally {
      setReflectionStatusLoading(false)
    }
  }, [])

  useEffect(() => {
    refreshReflectionStatus().catch(() => {})
  }, [refreshReflectionStatus])

  // Compute time-based greeting with optional user name and daily-rotating variants
  useEffect(() => {
    const supabase = createClient()
    const run = async () => {
      let displayName: string | null = null
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (user) {
          const { data: profile } = await supabase
            .from("profiles")
            .select("name")
            .eq("id", user.id)
            .maybeSingle()
          if (profile?.name && typeof profile.name === "string") {
            const trimmed = profile.name.trim()
            displayName = trimmed.length ? trimmed : null
          }
        }
      } catch {
        // Best-effort only; fall back to generic greeting.
      }

      const { sessionDate, timeOfDay } = getSessionDayInfo()

      if (timeOfDay === "morning") {
        setGreeting(`Morning${displayName ? ` ${displayName}` : ""}`)
        return
      }

      if (timeOfDay === "evening") {
        setGreeting(`Evening${displayName ? ` ${displayName}` : ""}`)
        return
      }

      const options = [
        "Whats on your mind today?",
        "Messy thoughts are welcomed",
        "You can start from there",
      ] as const

      // Deterministic hash from session date → one variant per calendar day
      const hash = Array.from(sessionDate).reduce((acc, ch) => acc + ch.charCodeAt(0), 0)
      const variant = options[hash % options.length]
      setGreeting(variant)
    }

    run()
  }, [])

  // Load which messages the user has already reported (so we can show "Reported")
  useEffect(() => {
    if (!sessionId || messages.length === 0) return
    const supabase = createClient()
    const run = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const ids = messages.map((m) => m.id)
      const { data: rows } = await supabase
        .from("message_reports")
        .select("message_id")
        .eq("user_id", user.id)
        .in("message_id", ids)
      setReportedMessageIds(new Set((rows ?? []).map((r) => r.message_id)))
    }
    run()
  }, [sessionId, messages.length])

  // Notify parent of active state changes
  useEffect(() => {
    onActiveChange?.(isActive)
  }, [isActive, onActiveChange])

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [])

  const handleScroll = useCallback(() => {
    // Cancel any pending long-press when the user scrolls (prevents accidental menu on scroll)
    if (longPressTimeoutRef.current !== null) {
      window.clearTimeout(longPressTimeoutRef.current)
      longPressTimeoutRef.current = null
    }

    const container = messagesContainerRef.current
    if (!container) return
    const threshold = 40
    const isAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight < threshold
    setShowScrollToBottom(!isAtBottom)
  }, [])

  const closeContextMenu = useCallback(() => {
    setContextMenu((prev) => ({
      ...prev,
      open: false,
      message: null,
    }))
  }, [])

  const handleMessageContextMenu = useCallback(
    (e: React.MouseEvent, msg: Message) => {
      e.preventDefault()
      const margin = 12
      const estimatedWidth = 260
      const estimatedHeight = 48
      const vw = window.innerWidth
      const vh = window.innerHeight

      let x = e.clientX
      let y = e.clientY

      if (x + estimatedWidth + margin > vw) {
        x = vw - estimatedWidth - margin
      }
      if (x < margin) x = margin
      if (y + estimatedHeight + margin > vh) {
        y = vh - estimatedHeight - margin
      }
      if (y < margin) y = margin

      setContextMenu({
        open: true,
        x,
        y,
        message: msg,
      })
    },
    []
  )

  const handleMessageTouchStart = useCallback(
    (e: React.TouchEvent, msg: Message) => {
      if (longPressTimeoutRef.current !== null) {
        window.clearTimeout(longPressTimeoutRef.current)
      }
      const touch = e.touches[0]
      const x = touch?.clientX ?? 0
      const y = touch?.clientY ?? 0
      longPressStartRef.current = { x, y }
      longPressTimeoutRef.current = window.setTimeout(() => {
        const margin = 12
        const estimatedWidth = 260
        const estimatedHeight = 48
        const vw = window.innerWidth
        const vh = window.innerHeight

        let menuX = x
        let menuY = y

        if (menuX + estimatedWidth + margin > vw) {
          menuX = vw - estimatedWidth - margin
        }
        if (menuX < margin) menuX = margin
        if (menuY + estimatedHeight + margin > vh) {
          menuY = vh - estimatedHeight - margin
        }
        if (menuY < margin) menuY = margin

        setContextMenu({
          open: true,
          x: menuX,
          y: menuY,
          message: msg,
        })
      }, 500)
    },
    []
  )

  const handleMessageTouchMove = useCallback((e: React.TouchEvent) => {
    if (!longPressStartRef.current || longPressTimeoutRef.current === null) return
    const touch = e.touches[0]
    if (!touch) return
    const dx = touch.clientX - longPressStartRef.current.x
    const dy = touch.clientY - longPressStartRef.current.y
    const distanceSq = dx * dx + dy * dy
    const threshold = 10 // px
    if (distanceSq > threshold * threshold) {
      window.clearTimeout(longPressTimeoutRef.current)
      longPressTimeoutRef.current = null
      longPressStartRef.current = null
    }
  }, [])

  const handleMessageTouchEnd = useCallback(() => {
    if (longPressTimeoutRef.current !== null) {
      window.clearTimeout(longPressTimeoutRef.current)
      longPressTimeoutRef.current = null
    }
    longPressStartRef.current = null
  }, [])

  const handleCopyText = useCallback(async (text: string) => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text)
      } else {
        const textarea = document.createElement("textarea")
        textarea.value = text
        textarea.style.position = "fixed"
        textarea.style.left = "-9999px"
        document.body.appendChild(textarea)
        textarea.select()
        document.execCommand("copy")
        document.body.removeChild(textarea)
      }
    } catch (error) {
      console.error("Failed to copy text", error)
    }
  }, [])

  const handleReadAloud = useCallback(async (text: string) => {
    if (!text.trim()) return
    try {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      let voice = "alloy"
      if (user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("preferred_voice")
          .eq("id", user.id)
          .single()
        if (profile?.preferred_voice) voice = profile.preferred_voice
      }
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.trim(), voice }),
      })
      if (!res.ok) return
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const audio = new Audio(url)
      audio.onended = () => URL.revokeObjectURL(url)
      await audio.play()
    } catch {
      // ignore
    }
  }, [])

  useEffect(() => {
    scrollToBottom()
    setShowScrollToBottom(false)
  }, [messages, isThinking, scrollToBottom])

  const sendMessage = useCallback(async () => {
    const text = inputValue.trim()
    if (!text || isThinking) return

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { sessionDate, dayOfWeek, timeOfDay } = getSessionDayInfo()
    const now = new Date().toISOString()
    const nowMs = Date.now()
    const shouldPostProcess =
      sessionId != null &&
      lastMessageAtRef.current != null &&
      nowMs - lastMessageAtRef.current > IDLE_POSTPROCESS_MS

    let currentSessionId = sessionId
    if (!currentSessionId) {
      const { data: newSession, error: insertErr } = await supabase
        .from("chat_sessions")
        .insert({
          user_id: user.id,
          session_date: sessionDate,
          day_of_week: dayOfWeek,
          time_of_day: timeOfDay,
          started_at: now,
          last_message_at: now,
        })
        .select("id")
        .single()
      if (insertErr) {
        console.error("Failed to create session", insertErr)
        return
      }
      currentSessionId = newSession!.id
      setSessionId(currentSessionId)
    }

    const { data: userRow, error: userMsgErr } = await supabase
      .from("chat_messages")
      .insert({ session_id: currentSessionId, role: "user", content: text })
      .select("id")
      .single()
    if (userMsgErr) {
      console.error("Failed to save user message", userMsgErr)
      return
    }

    await supabase
      .from("chat_sessions")
      .update({ last_message_at: now })
      .eq("id", currentSessionId)

    lastMessageAtRef.current = nowMs

    const userMsg: Message = {
      id: userRow!.id,
      text,
      sender: "user",
    }
    setMessages((prev) => [...prev, userMsg])
    setInputValue("")
    setTextareaHeight(MIN_TEXTAREA_HEIGHT)
    setIsThinking(true)

    const isFirstMessage = messages.filter((m) => m.sender === "user").length === 0
    let reflectionContext: string | null = null
    if (isFirstMessage && typeof window !== "undefined") {
      reflectionContext = sessionStorage.getItem(REFLECTION_CONTEXT_KEY)
      if (reflectionContext) sessionStorage.removeItem(REFLECTION_CONTEXT_KEY)
    }

    let aiText: string
    let route: Route = "CBT"
    try {
      const result = await fetchAiReply(messages, text, currentSessionId, reflectionContext)
      aiText = result.content
      route = result.route
    } catch {
      aiText = FALLBACK_AI_MESSAGE
    }

    const { data: aiRow, error: aiMsgErr } = await supabase
      .from("chat_messages")
      .insert({ session_id: currentSessionId!, role: "ai", content: aiText })
      .select("id")
      .single()
    let crisisCardMsg: Message | null = null
    if (route === "Crisis" && currentSessionId) {
      const { data: crisisRow } = await supabase
        .from("chat_messages")
        .insert({ session_id: currentSessionId, role: "ai", content: "", source: "crisis_card" })
        .select("id")
        .single()
      if (crisisRow?.id) {
        crisisCardMsg = { id: crisisRow.id, text: "", sender: "ai", source: "crisis_card" }
      }
    }
    const aiMsg: Message = {
      id: aiRow?.id ?? `ai-${Date.now()}`,
      text: aiText,
      sender: "ai",
    }
    setMessages((prev) => [...prev, aiMsg, ...(crisisCardMsg ? [crisisCardMsg] : [])])
    setIsThinking(false)
    await supabase
      .from("chat_sessions")
      .update({ last_message_at: new Date().toISOString() })
      .eq("id", currentSessionId!)

    const newUserMessageCount = messages.filter((m) => m.sender === "user").length + 1
    const shouldRunVectorCycle =
      newUserMessageCount >= USER_MESSAGES_PER_VECTOR_CYCLE &&
      newUserMessageCount % USER_MESSAGES_PER_VECTOR_CYCLE === 0

    async function sendPostProcess() {
      const res = await fetch("/api/chat/post-process", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: currentSessionId }),
      })
      if (!res.ok) throw new Error("Post-process failed")
    }

    if (shouldRunVectorCycle) {
      try {
        await sendPostProcess()
      } catch {
        try {
          await sendPostProcess()
        } catch (err) {
          console.error("Post-process (vector) failed after retry:", err)
        }
      }
    } else if (shouldPostProcess) {
      sendPostProcess().catch(() => {})
    }

    refreshReflectionStatus().catch(() => {})
  }, [inputValue, isThinking, sessionId, messages, refreshReflectionStatus])

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        const target = e.target as HTMLElement
        if (target.tagName === "TEXTAREA") return
        e.preventDefault()
        sendMessage()
      }
    },
    [sendMessage]
  )

  const MIN_TEXTAREA_HEIGHT = 24
  const MAX_TEXTAREA_HEIGHT = 72
  const resizeTextarea = useCallback(() => {
    const ta = textareaRef.current
    if (!ta) return
    ta.style.height = "auto"
    const sh = ta.value.trim() ? ta.scrollHeight : MIN_TEXTAREA_HEIGHT
    setTextareaHeight(Math.min(MAX_TEXTAREA_HEIGHT, Math.max(MIN_TEXTAREA_HEIGHT, sh)))
  }, [])
  useEffect(() => {
    resizeTextarea()
  }, [inputValue, resizeTextarea])

  const PREPARING_MS = 600
  // VAD: treat as speech when level above this (reset silence timer)
  const SPEECH_ENERGY_THRESHOLD = 0.012
  const SILENCE_MS = 1100
  const MIN_SPEECH_MS = 350
  const VAD_CHECK_INTERVAL_MS = 80
  const POST_BUFFER_MS = 400
  // Ball scale: min and max size (px) when listening (big = loud, small = quiet)
  const BALL_SIZE_MIN = 48
  const BALL_SIZE_MAX = 100

  const getPreferredVoice = useCallback(async (): Promise<string> => {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return "alloy"
    const { data: profile } = await supabase.from("profiles").select("preferred_voice").eq("id", user.id).single()
    return profile?.preferred_voice && ["alloy", "nova", "shimmer"].includes(profile.preferred_voice)
      ? profile.preferred_voice
      : "alloy"
  }, [])

  const stopVoiceRecording = useCallback(() => {
    if (voiceSilenceTimeoutRef.current) {
      clearTimeout(voiceSilenceTimeoutRef.current)
      voiceSilenceTimeoutRef.current = null
    }
    if (voicePostBufferTimeoutRef.current) {
      clearTimeout(voicePostBufferTimeoutRef.current)
      voicePostBufferTimeoutRef.current = null
    }
    voiceRecorderRef.current?.state !== "inactive" && voiceRecorderRef.current?.stop()
    voiceRecorderRef.current = null
    voiceStreamRef.current?.getTracks().forEach((t) => t.stop())
    voiceStreamRef.current = null
    voiceAnalyserRef.current = null
    if (voiceLevelAnimationRef.current != null) {
      cancelAnimationFrame(voiceLevelAnimationRef.current)
      voiceLevelAnimationRef.current = null
    }
    setVoiceAudioLevel(0)
  }, [])

  const runVoiceFlowFromTranscript = useCallback(
    async (userText: string) => {
      if (!userText.trim()) return
      if (!voiceModeActiveRef.current) return
      setVoiceState("thinking")
      setVoiceStatusLabel("Thinking…")

      const isFirstMessage = messagesRef.current.filter((m) => m.sender === "user").length === 0
      let reflectionContext: string | null = null
      if (isFirstMessage && typeof window !== "undefined") {
        reflectionContext = sessionStorage.getItem(REFLECTION_CONTEXT_KEY)
        if (reflectionContext) sessionStorage.removeItem(REFLECTION_CONTEXT_KEY)
      }

      let answer: string
      let route: Route = "CBT"
      try {
        const result = await fetchAiReply(messagesRef.current, userText.trim(), sessionId, reflectionContext)
        answer = result.content
        route = result.route
      } catch {
        answer = FALLBACK_AI_MESSAGE
      }

      const userMsg: Message = {
        id: `user-${Date.now()}`,
        text: userText.trim(),
        sender: "user",
      }
      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        text: answer,
        sender: "ai",
      }
      const crisisCardMsg: Message | null =
        route === "Crisis"
          ? { id: `crisis-${Date.now()}`, text: "", sender: "ai", source: "crisis_card" }
          : null
      setMessages((prev) => [...prev, userMsg, aiMsg, ...(crisisCardMsg ? [crisisCardMsg] : [])])

      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const { sessionDate, dayOfWeek, timeOfDay } = getSessionDayInfo()
      let currentSessionId = sessionId
      if (!currentSessionId) {
        const { data: session } = await supabase.from("chat_sessions").select("id").eq("user_id", user.id).eq("session_date", sessionDate).maybeSingle()
        currentSessionId = session?.id ?? null
      }
      if (!currentSessionId) {
        const now = new Date().toISOString()
        const { data: newSession, error: insertErr } = await supabase
          .from("chat_sessions")
          .insert({
            user_id: user.id,
            session_date: sessionDate,
            day_of_week: dayOfWeek,
            time_of_day: timeOfDay,
            started_at: now,
            last_message_at: now,
          })
          .select("id")
          .single()
        if (!insertErr && newSession) {
          currentSessionId = newSession.id
          setSessionId(currentSessionId)
        }
      }
      if (currentSessionId) {
        await supabase.from("chat_messages").insert({ session_id: currentSessionId, role: "user", content: userText.trim() })
        await supabase.from("chat_messages").insert({ session_id: currentSessionId, role: "ai", content: answer })
        if (route === "Crisis") {
          await supabase
            .from("chat_messages")
            .insert({ session_id: currentSessionId, role: "ai", content: "", source: "crisis_card" })
        }
        await supabase.from("chat_sessions").update({ last_message_at: new Date().toISOString() }).eq("id", currentSessionId)
      }

      if (!voiceModeActiveRef.current) return
      stopVoiceRecording()
      setVoiceAnswer(answer)
      setVoiceDisplayLength(0)
      setVoiceState("answering")
      setVoiceStatusLabel("")

      const voice = await getPreferredVoice()

      const chunkMaxChars = 100
      const chunks: string[] = []
      const parts = answer.split(/(?<=[.!?])\s+/)
      for (const p of parts) {
        const trimmed = p.trim()
        if (!trimmed) continue
        if (trimmed.length <= chunkMaxChars) {
          chunks.push(trimmed)
        } else {
          for (let i = 0; i < trimmed.length; i += chunkMaxChars) {
            chunks.push(trimmed.slice(i, i + chunkMaxChars))
          }
        }
      }
      if (chunks.length === 0) chunks.push(answer)

      const fetchTts = (text: string): Promise<Blob> =>
        fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text, voice, speed: 1.2 }),
        }).then((r) => (r.ok ? r.blob() : Promise.reject(new Error("TTS failed"))))

      try {
        let nextBlobPromise: Promise<Blob> | null = fetchTts(chunks[0])

        const playNext = async (index: number) => {
          if (!voiceModeActiveRef.current) return
          if (index >= chunks.length) {
            startVoiceModeRef.current?.()
            return
          }
          const blob = await nextBlobPromise
          nextBlobPromise = index + 1 < chunks.length ? fetchTts(chunks[index + 1]) : null
          if (!voiceModeActiveRef.current) return
          const url = URL.createObjectURL(blob)
          const audio = new Audio(url)
          voiceAnswerAudioRef.current = audio
          audio.onended = () => {
            voiceAnswerAudioRef.current = null
            URL.revokeObjectURL(url)
            playNext(index + 1)
          }
          await audio.play()
        }

        await playNext(0)
      } catch {
        if (voiceModeActiveRef.current) {
          startVoiceModeRef.current?.()
        }
      }

      refreshReflectionStatus().catch(() => {})
    },
    [sessionId, getPreferredVoice, stopVoiceRecording, refreshReflectionStatus]
  )

  const startVoiceMode = useCallback(async () => {
    voiceModeActiveRef.current = true
    setVoiceAnswer("")
    setVoiceDisplayLength(0)
    setVoiceState("preparing")
    setVoiceStatusLabel("Preparing Microphone")

    await new Promise((r) => setTimeout(r, PREPARING_MS))
    if (!voiceModeActiveRef.current) return

    let stream: MediaStream
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch {
      if (voiceModeActiveRef.current) {
        setVoiceStatusLabel("Microphone unavailable")
        setVoiceState("idle")
      }
      return
    }
    if (!voiceModeActiveRef.current) {
      stream.getTracks().forEach((t) => t.stop())
      return
    }

    voiceStreamRef.current = stream
    const audioContext = new AudioContext()
    if (audioContext.state === "suspended") {
      await audioContext.resume()
    }
    const source = audioContext.createMediaStreamSource(stream)
    const analyser = audioContext.createAnalyser()
    analyser.fftSize = 256
    analyser.smoothingTimeConstant = 0.3
    analyser.minDecibels = -60
    analyser.maxDecibels = -10
    source.connect(analyser)
    voiceAnalyserRef.current = analyser

    setVoiceState("listening")
    setVoiceStatusLabel("Listening")
    voiceStateRef.current = "listening"

    voiceChunksRef.current = []
    const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm"
    const recorder = new MediaRecorder(stream)
    voiceRecorderRef.current = recorder
    recorder.ondataavailable = (e) => {
      if (e.data.size) voiceChunksRef.current.push(e.data)
    }

    const recordingStartTime = Date.now()
    const MAX_RECORDING_MS = 2 * 60 * 1000
    let lastSpeechAt = Date.now()
    let firstSpeechAt: number | null = null
    let speechStarted = false

    const runLevelLoop = () => {
      if (voiceStateRef.current !== "listening" || !voiceAnalyserRef.current) return
      const anal = voiceAnalyserRef.current
      const data = new Uint8Array(anal.frequencyBinCount)
      anal.getByteFrequencyData(data)
      const sum = data.reduce((a, b) => a + b, 0)
      const avg = sum / (data.length * 255)
      setVoiceAudioLevel((prev) => Math.min(1, Math.max(0, prev * 0.2 + avg * 0.8)))
      voiceLevelAnimationRef.current = requestAnimationFrame(runLevelLoop)
    }
    runLevelLoop()

    const checkVad = () => {
      if (!voiceModeActiveRef.current || voiceStateRef.current !== "listening") return
      const anal = voiceAnalyserRef.current
      if (anal) {
        const data = new Uint8Array(anal.frequencyBinCount)
        anal.getByteFrequencyData(data)
        const sum = data.reduce((a, b) => a + b, 0)
        const avg = sum / (data.length * 255)
        if (avg > SPEECH_ENERGY_THRESHOLD) {
          lastSpeechAt = Date.now()
          if (!speechStarted) {
            speechStarted = true
            firstSpeechAt = Date.now()
          }
        }
      }
      const silenceDuration = Date.now() - lastSpeechAt
      const hasRecorded = voiceChunksRef.current.length > 0
      const maxTimeReached = Date.now() - recordingStartTime >= MAX_RECORDING_MS
      const speechLongEnough = firstSpeechAt != null && Date.now() - firstSpeechAt >= MIN_SPEECH_MS
      const shouldStop =
        hasRecorded &&
        !voicePostBufferTimeoutRef.current &&
        (maxTimeReached || (speechStarted && speechLongEnough && silenceDuration >= SILENCE_MS))
      if (shouldStop) {
        voicePostBufferTimeoutRef.current = setTimeout(() => {
          voicePostBufferTimeoutRef.current = null
          if (voiceSilenceTimeoutRef.current) clearTimeout(voiceSilenceTimeoutRef.current)
          voiceSilenceTimeoutRef.current = null
          const rec = voiceRecorderRef.current
          if (rec?.state === "recording") rec.stop()
        }, POST_BUFFER_MS)
      } else if (silenceDuration < SILENCE_MS && voicePostBufferTimeoutRef.current) {
        clearTimeout(voicePostBufferTimeoutRef.current)
        voicePostBufferTimeoutRef.current = null
      }
      voiceSilenceTimeoutRef.current = setTimeout(checkVad, VAD_CHECK_INTERVAL_MS)
    }

    recorder.onstop = async () => {
      const userTurnedMicOff = userRequestedMicOffRef.current
      userRequestedMicOffRef.current = false
      stopVoiceRecording()
      const chunks = voiceChunksRef.current
      voiceChunksRef.current = []
      if (userTurnedMicOff) {
        if (voiceModeActiveRef.current) setVoiceState("mic_off")
        return
      }
      if (!voiceModeActiveRef.current || chunks.length === 0) {
        if (voiceModeActiveRef.current && voiceStateRef.current === "listening") setVoiceState("mic_off")
        return
      }
      if (voiceModeActiveRef.current) {
        setVoiceState("transcribing")
        setVoiceStatusLabel("Transcribing…")
      }
      const blob = new Blob(chunks, { type: mime })
      try {
        const form = new FormData()
        form.append("file", blob, "audio.webm")
        const res = await fetch("/api/transcribe", { method: "POST", body: form })
        if (!res.ok) throw new Error("Transcribe failed")
        const { text } = await res.json()
        const transcript = (text ?? "").trim()
        if (!transcript) {
          if (voiceModeActiveRef.current) setVoiceState("mic_off")
          return
        }
        await runVoiceFlowFromTranscript(transcript)
      } catch {
        if (voiceModeActiveRef.current) {
          setVoiceState("mic_off")
          setVoiceStatusLabel("")
        }
      }
    }

    recorder.start(200)
    checkVad()
  }, [runVoiceFlowFromTranscript, stopVoiceRecording])

  startVoiceModeRef.current = startVoiceMode

  const turnMicOff = useCallback(() => {
    userRequestedMicOffRef.current = true
    if (voiceRecorderRef.current?.state === "recording") {
      voiceRecorderRef.current.stop()
    } else {
      stopVoiceRecording()
      setVoiceState("mic_off")
    }
  }, [stopVoiceRecording])

  const exitVoiceMode = useCallback(() => {
    voiceModeActiveRef.current = false
    stopVoiceRecording()
    if (voiceAnswerAudioRef.current) {
      voiceAnswerAudioRef.current.pause()
      voiceAnswerAudioRef.current = null
    }
    setVoiceState("idle")
    setVoiceAnswer("")
    setVoiceDisplayLength(0)
    setVoiceStatusLabel("")
  }, [stopVoiceRecording])

  const handleBack = useCallback(() => {
    if (inVoiceMode) {
      exitVoiceMode()
      return
    }
    // When viewing a past conversation (readonly), go back to today's chat with input visible
    if (readOnly) {
      router.replace("/chat")
      return
    }
    setMessages([])
    setInputValue("")
    setSessionId(null)
    lastMessageAtRef.current = null
    onBack()
  }, [inVoiceMode, exitVoiceMode, readOnly, router, onBack])

  // When on landing: tap input or voice opens today's convo if it exists (so user goes straight to chat). Returns true if convo was opened.
  const openCurrentDayChatIfAny = useCallback(async (): Promise<boolean> => {
    if (hasMessages || sessionId) return false
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return false
    const { sessionDate } = getSessionDayInfo()
    const { data: session } = await supabase
      .from("chat_sessions")
      .select("id, last_message_at")
      .eq("user_id", user.id)
      .eq("session_date", sessionDate)
      .maybeSingle()
    if (!session) return false
    const { data: rows } = await supabase
      .from("chat_messages")
      .select("id, role, content, source")
      .eq("session_id", session.id)
      .order("created_at", { ascending: true })
    if (!rows?.length) return false
    focusInputAfterOpenRef.current = true
    setSessionId(session.id)
    lastMessageAtRef.current = session.last_message_at
      ? new Date(session.last_message_at).getTime()
      : null
    setMessages(
      rows.map((r) => ({
        id: r.id,
        text: r.content,
        sender: r.role as "user" | "ai",
        source: r.source ?? undefined,
      }))
    )
    return true
  }, [hasMessages, sessionId])

  // Focus chat input after opening today's convo from landing
  useEffect(() => {
    if (!focusInputAfterOpenRef.current) return
    focusInputAfterOpenRef.current = false
    if (hasMessages && textareaRef.current) {
      textareaRef.current.focus()
    } else if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [hasMessages])

  // Rotate placeholder text
  useEffect(() => {
    const id = setInterval(() => {
      setPlaceholderIndex((i) => (i + 1) % CHAT_PLACEHOLDERS.length)
    }, PLACEHOLDER_ROTATE_MS)
    return () => clearInterval(id)
  }, [])

  // ===================== VOICE MODE =====================
  if (inVoiceMode) {
    const progress = reflectionStatus?.currentWeek.progress ?? 0.3
    const hasAnyChatCurrentWeek = reflectionStatus?.currentWeek.hasAnyChat ?? false
    const lastWeekHasReflection = reflectionStatus?.lastWeek.hasReflection ?? false
    const lastWeekCycleCompleted = reflectionStatus?.lastWeek.cycleCompleted ?? false
    const showStartChatMessage = !hasAnyChatCurrentWeek
    const canViewReflectionFromDrawer = lastWeekHasReflection || lastWeekCycleCompleted

    return (
      <div className="flex flex-col flex-1 h-full">
        {/* Back button + reflection icon */}
        <header className="flex items-center justify-between px-5 pt-4 pb-2">
          <button
            onClick={handleBack}
            className="w-10 h-10 rounded-full glass flex items-center justify-center"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <Drawer>
            <DrawerTrigger asChild>
              <button
                className="w-10 h-10 rounded-full glass flex items-center justify-center"
                aria-label="Open reflection status"
              >
                <ReflectionStatusIcon size="sm" progress={progress} />
              </button>
            </DrawerTrigger>
            <DrawerContent className="border-t bg-background rounded-t-3xl flex flex-col">
              <DrawerHeader className="flex flex-col items-center gap-4 pt-6">
                <ReflectionStatusIcon size="lg" progress={progress} />
                <div className="space-y-2 text-center px-6">
                  <p className="text-xs font-sans font-semibold tracking-[0.2em] uppercase text-foreground/70">
                    {showStartChatMessage
                      ? "Start chatting, reflection will form."
                      : canViewReflectionFromDrawer
                      ? "Weekly reflection ready."
                      : "Keep talking, reflection is forming."}
                  </p>
                  <DrawerDescription className="text-sm text-foreground/75">
                    {showStartChatMessage
                      ? "Once you start chatting this week, we’ll begin forming your weekly reflection in the background."
                      : canViewReflectionFromDrawer
                      ? "You can view your latest weekly reflection in the You tab. It will stay there so you can revisit it anytime."
                      : "Every message adds more detail to your reflection. We’re holding the thread so you can step away and come back without losing your flow."}
                  </DrawerDescription>
                </div>
              </DrawerHeader>
              <DrawerFooter>
                {canViewReflectionFromDrawer ? (
                  <Button
                    className="w-full"
                    size="lg"
                    onClick={() => {
                      router.push("/youpage")
                    }}
                  >
                    View reflection
                  </Button>
                ) : (
                  <DrawerClose asChild>
                    <Button className="w-full" size="lg">
                      Resume Conversation
                    </Button>
                  </DrawerClose>
                )}
              </DrawerFooter>
            </DrawerContent>
          </Drawer>
        </header>

        {/* Clear convo state: Listening / Mic off / Transcribing → Thinking → Answer */}
        <div className="shrink-0 pt-3 pb-1">
          <p className="text-xs font-sans font-semibold tracking-[0.2em] uppercase text-foreground/70 text-center">
            {voiceState === "preparing" && "Preparing…"}
            {voiceState === "listening" && "Listening"}
            {voiceState === "mic_off" && "Mic off"}
            {voiceState === "transcribing" && "Transcribing…"}
            {voiceState === "thinking" && "Thinking…"}
            {voiceState === "answering" && "Answer"}
          </p>
        </div>

        {/* Center content: ball scales with voice level when listening (big = loud, small = quiet) */}
        <div className="flex-1 flex flex-col items-center justify-center px-8">
          <div
            className="rounded-full bg-foreground voice-ball-transition flex-shrink-0"
            style={{
              width: voiceState === "preparing" || voiceState === "thinking" || voiceState === "transcribing" || voiceState === "mic_off" ? 56 : voiceState === "listening" ? BALL_SIZE_MIN + voiceAudioLevel * (BALL_SIZE_MAX - BALL_SIZE_MIN) : 56,
              height: voiceState === "preparing" || voiceState === "thinking" || voiceState === "transcribing" || voiceState === "mic_off" ? 56 : voiceState === "listening" ? BALL_SIZE_MIN + voiceAudioLevel * (BALL_SIZE_MAX - BALL_SIZE_MIN) : 56,
            }}
          />
          {voiceState === "answering" && (
            <p className="voice-answer-text text-lg font-serif text-foreground text-center leading-relaxed mt-8 max-w-md text-balance">
              {voiceAnswer}
            </p>
          )}
        </div>

        {/* Bottom controls: mic = access only (on/off), not send */}
        <div className="flex items-center justify-center gap-3 px-5 pb-10">
          {voiceState === "listening" ? (
            <button
              onClick={turnMicOff}
              className="w-12 h-12 rounded-full bg-background border border-foreground/20 flex items-center justify-center shrink-0 shadow-sm text-foreground"
              aria-label="Turn mic off"
            >
              <MicOff className="w-5 h-5 text-foreground" />
            </button>
          ) : (
            <button
              onClick={startVoiceMode}
              className="w-12 h-12 rounded-full bg-background border border-foreground/20 flex items-center justify-center shrink-0 shadow-sm text-foreground"
              aria-label="Turn mic on"
            >
              <Mic className="w-5 h-5 text-foreground" />
            </button>
          )}
          <button
            onClick={exitVoiceMode}
            className="glass-strong flex items-center justify-center gap-2 px-6 py-3"
            style={{ borderRadius: "50px" }}
            aria-label="Switch to keyboard"
          >
            <Keyboard className="w-4 h-4 text-foreground/70" />
            <span className="text-sm font-sans text-foreground/70">Switch to Keyboard</span>
          </button>
        </div>
      </div>
    )
  }

  // ===================== LOADING =====================
  if (sessionLoading) {
    return (
      <div className="flex flex-col items-center justify-center flex-1 px-5">
        <p className="text-sm font-sans text-foreground/60">Loading...</p>
      </div>
    )
  }

  // ===================== LANDING STATE =====================
  if (!hasMessages) {
    return (
      <div className="flex flex-col items-center flex-1 px-5 pb-6">
        <div className="flex-1 min-h-0" />

        <div className="w-full flex flex-col items-center gap-8">
          <div className="flex flex-col items-center gap-3">
            <h2 className="text-4xl font-serif text-foreground text-center leading-tight text-balance">
              {greeting ?? "Whats on your mind?"}
            </h2>
            <p className="text-xs font-sans font-semibold tracking-[0.15em] text-foreground/60 uppercase">
              {getCurrentDate()}
            </p>
          </div>

          {!readOnly && (
            <div className="w-full">
              <form className="glass rounded-full flex items-center px-5 py-3 gap-3" autoComplete="off" onSubmit={(e) => e.preventDefault()}>
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onFocus={openCurrentDayChatIfAny}
                  onKeyDown={handleKeyDown}
                  placeholder={CHAT_PLACEHOLDERS[placeholderIndex]}
                  className="flex-1 bg-transparent text-sm font-sans text-foreground/70 placeholder:text-foreground/40 focus:outline-none"
                  aria-label="Start a conversation"
                  autoComplete="false"
                  autoCorrect="on"
                  autoCapitalize="sentences"
                  inputMode="text"
                  name="message"
                  data-1p-ignore
                  data-lpignore="true"
                  data-form-type="other"
                />
                {hasText ? (
                  <button
                    type="button"
                    onClick={sendMessage}
                    className="w-10 h-10 rounded-full bg-foreground/90 flex items-center justify-center shrink-0 transition-all duration-200"
                    aria-label="Send message"
                  >
                    <ArrowUp className="w-5 h-5 text-background" strokeWidth={2.5} />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={async () => {
                      const opened = await openCurrentDayChatIfAny()
                      if (!opened) startVoiceMode()
                    }}
                    className="w-10 h-10 rounded-full bg-background border border-foreground/20 flex items-center justify-center shrink-0 shadow-sm text-foreground"
                    aria-label="Voice input"
                  >
                    <AudioWaveIcon className="w-5 h-5 text-foreground" />
                  </button>
                )}
              </form>
            </div>
          )}
        </div>

        <div className="flex-[0.6] min-h-0" />
      </div>
    )
  }

  // ===================== CHAT STATE =====================
  return (
    <div className="relative flex flex-col flex-1 h-full overflow-hidden bg-background">
      {/*
        Reflection status for current and last week, used in the drawer below.
      */}
      {/*
        Fallbacks are handled inline so the UI stays stable even if the status
        request fails or is still loading.
      */}
      {(() => {
        return null
      })()}
      {/* Back button + reflection icon */}
      <header className="flex items-center justify-between px-5 pt-4 pb-2 shrink-0">
        <button
          onClick={handleBack}
          className="w-10 h-10 rounded-full glass flex items-center justify-center"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
        <Drawer>
          <DrawerTrigger asChild>
            <button
              className="w-10 h-10 rounded-full glass flex items-center justify-center"
              aria-label="Open reflection status"
            >
              <ReflectionStatusIcon
                size="sm"
                progress={reflectionStatus?.currentWeek.progress ?? 0.3}
              />
            </button>
          </DrawerTrigger>
          <DrawerContent className="border-t bg-background rounded-t-3xl flex flex-col">
            <DrawerHeader className="flex flex-col items-center gap-4 pt-6">
              <ReflectionStatusIcon
                size="lg"
                progress={reflectionStatus?.currentWeek.progress ?? 0.3}
              />
              <div className="space-y-2 text-center px-6">
                <p className="text-xs font-sans font-semibold tracking-[0.2em] uppercase text-foreground/70">
                  {!reflectionStatus?.currentWeek.hasAnyChat
                    ? "Start chatting, reflection will form."
                    : reflectionStatus?.lastWeek.hasReflection ||
                      reflectionStatus?.lastWeek.cycleCompleted
                    ? "Weekly reflection ready."
                    : "Keep talking, reflection is forming."}
                </p>
                <DrawerDescription className="text-sm text-foreground/75">
                  {!reflectionStatus?.currentWeek.hasAnyChat
                    ? "Once you start chatting this week, we’ll begin forming your weekly reflection in the background."
                    : reflectionStatus?.lastWeek.hasReflection ||
                      reflectionStatus?.lastWeek.cycleCompleted
                    ? "You can view your latest weekly reflection in the You tab. It will stay there so you can revisit it anytime."
                    : "The more you share, the richer your reflection becomes. We’re keeping track so you can step away and come back without losing your flow."}
                </DrawerDescription>
              </div>
            </DrawerHeader>
            <DrawerFooter>
              {reflectionStatus?.lastWeek.hasReflection ||
              reflectionStatus?.lastWeek.cycleCompleted ? (
                <Button
                  className="w-full"
                  size="lg"
                  onClick={() => {
                    router.push("/youpage")
                  }}
                >
                  View reflection
                </Button>
              ) : (
                <DrawerClose asChild>
                  <Button className="w-full" size="lg">
                    Resume Conversation
                  </Button>
                </DrawerClose>
              )}
            </DrawerFooter>
          </DrawerContent>
        </Drawer>

        <Drawer open={reportDrawerOpen} onOpenChange={setReportDrawerOpen}>
          <DrawerContent className="border-t bg-background rounded-t-3xl flex flex-col">
            <DrawerHeader className="flex flex-col items-center gap-4 pt-6">
              <div className="w-14 h-14 rounded-full bg-foreground/10 flex items-center justify-center">
                <Heart className="w-7 h-7 text-foreground" fill="currentColor" />
              </div>
              <div className="space-y-2 text-center px-6">
                <p className="text-xs font-sans font-semibold tracking-[0.2em] uppercase text-foreground/70">
                  Thanks for reporting
                </p>
                <DrawerDescription className="text-sm text-foreground/75">
                  Your report helps us keep the app safe and supportive for everyone. We review reports to improve responses and prevent harmful content. We never use reports to identify you in conversations.
                </DrawerDescription>
              </div>
            </DrawerHeader>
            <DrawerFooter>
              <DrawerClose asChild>
                <Button className="w-full" size="lg">
                  Resume Conversation
                </Button>
              </DrawerClose>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      </header>

      {/* Messages area - scrollable with native touch momentum */}
      <div
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto no-scrollbar touch-scroll px-5 pt-2 pb-4"
        onScroll={handleScroll}
      >
        <div className="flex flex-col gap-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === "user" && msg.source !== "insight" ? "justify-end" : "justify-start"}`}
              onContextMenu={(e) => handleMessageContextMenu(e, msg)}
              onTouchStart={(e) => handleMessageTouchStart(e, msg)}
              onTouchMove={handleMessageTouchMove}
              onTouchEnd={handleMessageTouchEnd}
              onTouchCancel={handleMessageTouchEnd}
            >
              {msg.sender === "user" && msg.source === "insight" ? (
                <div className="w-full px-0">
                  <div className="w-full rounded-[10px] border border-foreground/25 bg-transparent px-4 py-4">
                    {(() => {
                      const parts = msg.text.split(/\n\n+/)
                      const title = parts[0]?.trim() ?? ""
                      const body = parts.slice(1).join("\n\n").trim()
                      return (
                        <>
                          <p className="text-[10px] font-sans font-medium tracking-[0.2em] text-foreground/70 uppercase mb-2">
                            From your reflection
                          </p>
                          {title ? (
                            <p className="text-base font-serif font-semibold text-foreground/90 leading-snug mb-2">
                              {title}
                            </p>
                          ) : null}
                          {body ? (
                            <p className="text-sm font-sans text-foreground/80 leading-relaxed">
                              {body}
                            </p>
                          ) : null}
                        </>
                      )
                    })()}
                  </div>
                </div>
              ) : msg.sender === "ai" && msg.source === "crisis_card" ? (
                <div className="w-full px-0">
                  <CrisisCard />
                </div>
              ) : msg.sender === "user" ? (
                <div
                  className={`max-w-[80%] px-4 py-3 text-base font-sans font-semibold leading-relaxed bg-foreground/15 text-foreground rounded-2xl rounded-br-md transition-colors ${
                    contextMenu.open && contextMenu.message?.id === msg.id ? "bg-foreground/25" : ""
                  }`}
                >
                  {msg.text}
                </div>
              ) : (
                <div
                  className={`max-w-[85%] text-base font-sans font-semibold leading-relaxed text-foreground/80 rounded-2xl px-4 py-3 transition-colors ${
                    contextMenu.open && contextMenu.message?.id === msg.id ? "bg-foreground/10" : "bg-transparent"
                  }`}
                >
                  {msg.text}
                </div>
              )}
            </div>
          ))}

          {/* Thinking indicator */}
          {isThinking && (
            <div className="flex justify-start">
              <div className="flex items-center gap-1 px-1 py-2">
                <span className="w-2 h-2 rounded-full bg-foreground/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 rounded-full bg-foreground/40 animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 rounded-full bg-foreground/40 animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {showScrollToBottom && (
        <button
          className="absolute bottom-24 right-5 z-20 w-9 h-9 rounded-full bg-background/90 backdrop-blur border border-foreground/10 shadow-sm flex items-center justify-center"
          onClick={() => {
            scrollToBottom()
            setShowScrollToBottom(false)
          }}
          aria-label="Scroll to latest message"
        >
          <ArrowDown className="w-4 h-4 text-foreground" />
        </button>
      )}

      {/* Fixed input at bottom */}
      {!readOnly && (
        <div className="px-5 pb-6 pt-2 shrink-0">
          <form className="glass rounded-full flex items-end px-5 py-3 gap-3" autoComplete="off" onSubmit={(e) => e.preventDefault()}>
            <textarea
              ref={textareaRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={CHAT_PLACEHOLDERS[placeholderIndex]}
              className={cn(
                "flex-1 min-h-6 max-h-[4.5rem] resize-none bg-transparent text-base font-sans font-semibold text-foreground/70 placeholder:text-foreground/40 focus:outline-none py-2 transition-[height] duration-200 ease-out",
                textareaHeight >= MAX_TEXTAREA_HEIGHT ? "overflow-y-auto" : "overflow-hidden"
              )}
              style={{ height: textareaHeight }}
              rows={1}
              aria-label="Type a message"
              autoComplete="off"
              data-1p-ignore
              data-lpignore="true"
              data-form-type="other"
            />
            {hasText ? (
              <button
                type="button"
                onClick={sendMessage}
                className="w-10 h-10 rounded-full bg-foreground/90 flex items-center justify-center shrink-0 transition-all duration-200"
                aria-label="Send message"
              >
                <ArrowUp className="w-5 h-5 text-background" strokeWidth={2.5} />
              </button>
            ) : (
              <button
                onClick={startVoiceMode}
                className="w-10 h-10 rounded-full bg-background border border-foreground/20 flex items-center justify-center shrink-0 shadow-sm text-foreground"
                aria-label="Voice input"
              >
                <AudioWaveIcon className="w-5 h-5 text-foreground" />
              </button>
            )}
          </form>
        </div>
      )}

      {contextMenu.open && contextMenu.message && (
        <div
          className="fixed inset-0 z-40"
          onClick={closeContextMenu}
        >
          <div
            className="absolute z-50 rounded-2xl bg-background/95 backdrop-blur border border-foreground/10 shadow-lg px-2 py-2 flex items-center gap-1 select-none"
            style={{ top: contextMenu.y, left: contextMenu.x }}
            onClick={(e) => e.stopPropagation()}
          >
            {contextMenu.message.sender === "ai" && !readOnly && (
              <button
                className="px-3 py-1.5 rounded-full text-xs font-sans bg-foreground/10 text-foreground hover:bg-foreground/15 transition-colors inline-flex items-center gap-1"
                onClick={() => {
                  handleReadAloud(contextMenu.message!.text)
                  closeContextMenu()
                }}
              >
                <span className="select-none">Read aloud</span>
                <Volume2 className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            )}
            <button
              className="px-3 py-1.5 rounded-full text-xs font-sans bg-foreground/10 text-foreground hover:bg-foreground/15 transition-colors inline-flex items-center gap-1"
              onClick={async () => {
                await handleCopyText(contextMenu.message!.text)
                closeContextMenu()
              }}
            >
              <span className="select-none">Copy</span>
              <CopyIcon className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
            {contextMenu.message.sender === "ai" && !readOnly && (
              <button
                className={cn(
                  "px-3 py-1.5 rounded-full text-xs font-sans inline-flex items-center gap-1",
                  reportedMessageIds.has(contextMenu.message.id)
                    ? "bg-foreground/10 text-foreground/50 cursor-default"
                    : "bg-foreground/10 text-red-500 hover:bg-red-500/10 transition-colors"
                )}
                onClick={async () => {
                  if (reportedMessageIds.has(contextMenu.message!.id)) return
                  const msgId = contextMenu.message!.id
                  const supabase = createClient()
                  const { data: { user } } = await supabase.auth.getUser()
                  if (!user) return
                  const { error } = await supabase.from("message_reports").insert({
                    user_id: user.id,
                    message_id: msgId,
                  })
                  setReportedMessageIds((prev) => new Set([...prev, msgId]))
                  closeContextMenu()
                  setReportDrawerOpen(true)
                }}
                disabled={reportedMessageIds.has(contextMenu.message.id)}
              >
                <span className="select-none">
                  {reportedMessageIds.has(contextMenu.message.id) ? "Reported" : "Report"}
                </span>
                <Flag className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export function ChatPage(props: ChatPageProps) {
  return (
    <Suspense
      fallback={
        <div className="flex flex-col items-center justify-center flex-1 px-5">
          <p className="text-sm font-sans text-foreground/60">Loading...</p>
        </div>
      }
    >
      <ChatPageInner {...props} />
    </Suspense>
  )
}
