export function MenuIcon({ className = "" }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center gap-[5px] w-5 h-5 ${className}`}>
      <span className="block w-5 h-[1.5px] rounded-full bg-foreground" />
      <span className="block w-3.5 h-[1.5px] rounded-full bg-foreground" />
      <span className="block w-2.5 h-[1.5px] rounded-full bg-foreground" />
    </div>
  )
}
