"use client"

import { createClient } from "@/lib/supabase/client"
import { usePathname, useRouter } from "next/navigation"
import { useEffect, useRef } from "react"

/**
 * Runs inside (main) layout. Redirects to onboarding if user has no profile.
 * Records a session in sessions_log when user enters the app.
 * Triggers insight card generation once per day at relogin (API no-ops if already run or if today has 2 cards).
 * Triggers session title/summary backfill for past-day convos once per day at relogin.
 */
export function AuthGuard({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const didCheck = useRef(false)
  const didLogSession = useRef(false)
  const didTriggerInsightGen = useRef(false)
  const didTriggerSummaryBackfill = useRef(false)

  useEffect(() => {
    if (didCheck.current) return
    didCheck.current = true

    const supabase = createClient()

    const run = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      const isOnboarding = pathname === "/onboardingpage"
      if (!isOnboarding) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("id")
          .eq("id", user.id)
          .single()
        if (!profile) {
          router.replace("/onboardingpage")
          return
        }
      }

      if (!didLogSession.current) {
        didLogSession.current = true
        await supabase.from("sessions_log").insert({ user_id: user.id })
      }

      if (!didTriggerInsightGen.current) {
        didTriggerInsightGen.current = true
        fetch("/api/insights/generate", { method: "POST" }).catch(() => {})
      }

      if (!didTriggerSummaryBackfill.current) {
        didTriggerSummaryBackfill.current = true
        fetch("/api/session-summaries/backfill", { method: "POST" }).catch(() => {})
      }
    }

    run()
  }, [pathname, router])

  return <>{children}</>
}
