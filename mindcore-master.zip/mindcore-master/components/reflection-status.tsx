import { Star } from "lucide-react"
import { cn } from "@/lib/utils"

interface ReflectionStatusIconProps {
  size?: "sm" | "lg"
  className?: string
  progress?: number
}

export function ReflectionStatusIcon({ size = "sm", className, progress }: ReflectionStatusIconProps) {
  const dimension = size === "sm" ? 32 : 64
  const innerInset = size === "sm" ? 5 : 9
  const pct = Math.max(0, Math.min(1, typeof progress === "number" ? progress : 0.3))
  const arcDegrees = Math.round(360 * pct)

  return (
    <div
      className={cn(
        "relative flex items-center justify-center rounded-full bg-background/90 border border-foreground/20 shadow-sm",
        className
      )}
      style={{ width: dimension, height: dimension }}
    >
      {/* 30% progress arc */}
      <div
        className="absolute inset-[3px] rounded-full opacity-80"
        style={{
          background:
            `conic-gradient(var(--foreground) 0deg, var(--foreground) ${arcDegrees}deg, transparent ${arcDegrees}deg, transparent 360deg)`,
        }}
      />

      {/* Inner solid circle to keep the star crisp */}
      <div
        className="absolute rounded-full bg-background/95"
        style={{ inset: innerInset }}
      />

      {/* Star icon */}
      <Star
        className={cn(
          "relative text-foreground",
          size === "sm" ? "w-3.5 h-3.5" : "w-7 h-7"
        )}
        strokeWidth={1.8}
      />
    </div>
  )
}

