"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import { ArrowLeft } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import { ScrollArea } from "@/components/ui/scroll-area"

type OnboardingStep = "welcome" | "name" | "location" | "age" | "completed"

interface CountryRow {
  id: string
  name: string
  flag: string
}

interface OnboardingPageProps {
  onComplete: () => void
  onBack: () => void
}

// Why modal - reuses the same bottom sheet pattern as settings menu
function WhyModal({
  isOpen,
  onClose,
  title,
  paragraphs,
}: {
  isOpen: boolean
  onClose: () => void
  title: string
  paragraphs: string[]
}) {
  const [visible, setVisible] = useState(false)
  const [sheetY, setSheetY] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const isDragging = useRef(false)
  const startYRef = useRef(0)
  const lastYRef = useRef(0)
  const velocityRef = useRef(0)
  const lastTimeRef = useRef(0)

  useEffect(() => {
    if (isOpen) {
      setVisible(true)
      setSheetY(window.innerHeight)
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setIsAnimating(true)
          setSheetY(0)
        })
      })
    } else if (visible) {
      setIsAnimating(true)
      setSheetY(window.innerHeight)
      const timer = setTimeout(() => {
        setVisible(false)
        setIsAnimating(false)
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [isOpen])

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    isDragging.current = true
    startYRef.current = e.touches[0].clientY
    lastYRef.current = e.touches[0].clientY
    lastTimeRef.current = Date.now()
    velocityRef.current = 0
    setIsAnimating(false)
  }, [])

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging.current) return
    const currentTouch = e.touches[0].clientY
    const diff = currentTouch - startYRef.current
    const now = Date.now()
    const dt = now - lastTimeRef.current
    if (dt > 0) velocityRef.current = (currentTouch - lastYRef.current) / dt
    lastYRef.current = currentTouch
    lastTimeRef.current = now
    if (diff > 0) setSheetY(diff)
  }, [])

  const handleTouchEnd = useCallback(() => {
    isDragging.current = false
    if (sheetY > 120 || velocityRef.current > 0.5) {
      setIsAnimating(true)
      setSheetY(window.innerHeight)
      setTimeout(() => onClose(), 450)
    } else {
      setIsAnimating(true)
      setSheetY(0)
    }
  }, [sheetY, onClose])

  if (!visible) return null

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true">
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity duration-500"
        style={{ opacity: isOpen && sheetY < 100 ? 1 : 0 }}
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="absolute inset-x-0 bottom-0 top-16 rounded-t-3xl flex flex-col touch-none"
        style={{
          background: "linear-gradient(180deg, #8a7a6e 0%, #a89078 50%, #9a7e68 100%)",
          transform: `translateY(${sheetY}px)`,
          transition: isAnimating ? "transform 500ms cubic-bezier(0.32, 0.72, 0, 1)" : "none",
          willChange: "transform",
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="flex justify-center pt-3 pb-6 cursor-grab active:cursor-grabbing">
          <div className="w-10 h-1 rounded-full bg-foreground/40" />
        </div>
        <div className="flex-1 overflow-y-auto px-8 pb-10 no-scrollbar">
          <h2 className="text-3xl font-serif text-foreground leading-snug mb-6">{title}</h2>
          {paragraphs.map((p, i) => (
            <p key={i} className="text-sm font-sans text-foreground/80 leading-relaxed mb-4">
              {p}
            </p>
          ))}
        </div>
      </div>
    </div>
  )
}

const whyTexts: Record<string, { title: string; paragraphs: string[] }> = {
  name: {
    title: "Why we need to know your name?",
    paragraphs: [
      "Your name helps us personalize your experience and create a more meaningful connection during conversations.",
      "We use end-to-end encryption and strict data policies to ensure your personal information remains completely confidential.",
    ],
  },
  location: {
    title: "Why we need to know your location?",
    paragraphs: [
      "Advanced language models trained on therapeutic methodologies to provide personalized mental health support based on your cultural context.",
      "End-to-end encryption and strict data policies ensure your conversations remain completely confidential.",
    ],
  },
  age: {
    title: "Why we need to know your age?",
    paragraphs: [
      "Advanced language models trained on therapeutic methodologies to provide personalized mental health support.",
      "End-to-end encryption and strict data policies ensure your conversations remain completely confidential.",
    ],
  },
}

const AGE_MIN = 13
const AGE_MAX = 105

export function OnboardingPage({ onComplete, onBack }: OnboardingPageProps) {
  // Start at name step when user already signed in (e.g. from Google); skip welcome so they don't press "Continue" again
  const [step, setStep] = useState<OnboardingStep>("name")
  const [direction, setDirection] = useState<"forward" | "back">("forward")
  const [animKey, setAnimKey] = useState(0)

  // Form state
  const [name, setName] = useState("")
  const [countries, setCountries] = useState<CountryRow[]>([])
  const [countriesLoading, setCountriesLoading] = useState(true)
  const [selectedCountry, setSelectedCountry] = useState<CountryRow | null>(null)
  const [age, setAge] = useState("")
  const [ageError, setAgeError] = useState("")
  const [locationSheetOpen, setLocationSheetOpen] = useState(false)
  const [saving, setSaving] = useState(false)

  // Why modal state
  const [whyOpen, setWhyOpen] = useState(false)
  const [whyField, setWhyField] = useState<"name" | "location" | "age">("name")

  const [pressing, setPressing] = useState(false)

  useEffect(() => {
    const supabase = createClient()
    supabase
      .from("countries")
      .select("id, name, flag")
      .order("name")
      .then(({ data, error }) => {
        setCountriesLoading(false)
        if (!error && data?.length) {
          setCountries(data as CountryRow[])
          setSelectedCountry((prev) => prev ?? (data[0] as CountryRow))
        }
      })
  }, [])

  const steps: OnboardingStep[] = ["welcome", "name", "location", "age", "completed"]

  const goNext = useCallback(() => {
    const idx = steps.indexOf(step)
    if (idx < steps.length - 1) {
      setDirection("forward")
      setAnimKey((k) => k + 1)
      setStep(steps[idx + 1])
    }
  }, [step])

  const goBack = useCallback(() => {
    const idx = steps.indexOf(step)
    if (idx === 0) {
      onBack()
      return
    }
    setDirection("back")
    setAnimKey((k) => k + 1)
    setStep(steps[idx - 1])
  }, [step, onBack])

  const openWhy = useCallback((field: "name" | "location" | "age") => {
    setWhyField(field)
    setWhyOpen(true)
  }, [])

  const ageNum = useCallback(() => {
    const n = parseInt(age.trim(), 10)
    return Number.isNaN(n) ? null : n
  }, [age])

  const canContinue = useCallback(() => {
    if (step === "name") return name.trim().length > 0
    if (step === "location") return !!selectedCountry
    if (step === "age") {
      const n = ageNum()
      if (n === null) return false
      return n >= AGE_MIN && n <= AGE_MAX
    }
    return true
  }, [step, name, selectedCountry, age, ageNum])

  const handleComplete = useCallback(async () => {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const n = ageNum()
    if (n === null || n < AGE_MIN || n > AGE_MAX) return
    setSaving(true)
    const { error } = await supabase.from("profiles").upsert(
      {
        id: user.id,
        name: name.trim(),
        country_id: selectedCountry?.id ?? null,
        age: n,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "id" }
    )
    setSaving(false)
    if (!error) onComplete()
  }, [name, selectedCountry, ageNum, onComplete])

  const animClass =
    direction === "forward" ? "onboard-slide-enter" : "onboard-slide-back-enter"

  // Welcome / Get Started screen
  if (step === "welcome") {
    return (
      <div className="h-dvh relative overflow-hidden">
        {/* Background gradient + noise */}
        <div className="absolute inset-0 onboarding-gradient noise-overlay" />

        <div className="relative z-10 h-full flex flex-col">
          {/* Back button */}
          <header className="px-5 pt-4 pb-2">
            <button
              onClick={onBack}
              className="w-10 h-10 rounded-full glass flex items-center justify-center"
              aria-label="Go back"
            >
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </button>
          </header>

          <div className="flex-1 flex flex-col items-center justify-center px-8">
            <h1 className="text-6xl font-serif text-foreground text-center leading-tight mb-4">
              Get Started
            </h1>
            <p className="text-sm font-sans font-semibold text-foreground/80 text-center">
              Get Started with MindCore
            </p>
          </div>

          {/* Bottom area */}
          <div className="px-8 pb-10">
            <button
              onClick={goNext}
              onPointerDown={() => setPressing(true)}
              onPointerUp={() => setPressing(false)}
              onPointerLeave={() => setPressing(false)}
              className="btn-continue w-full py-4 rounded-full font-sans font-semibold text-base flex items-center justify-center gap-3 transition-all duration-150"
              style={{
                background: pressing ? "#e8e0d8" : "#ffffff",
                color: "#1a1412",
              }}
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Completed screen
  if (step === "completed") {
    return (
      <div key={animKey} className={`h-dvh relative overflow-hidden ${animClass}`}>
        <div className="absolute inset-0 corl-gradient" />
        <div className="relative z-10 h-full flex flex-col">
          <div className="flex-1 flex flex-col items-center justify-center px-8">
            <h1 className="text-6xl font-serif text-foreground text-center leading-tight mb-4">
              {"Completed!"}
            </h1>
            <p className="text-sm font-sans text-foreground/70 text-center">
              {"Welcome to MindCore, start using the app"}
            </p>
          </div>

          <div className="px-8 pb-10">
            <button
              onClick={handleComplete}
              disabled={saving}
              onPointerDown={() => !saving && setPressing(true)}
              onPointerUp={() => setPressing(false)}
              onPointerLeave={() => setPressing(false)}
              className="btn-continue w-full py-4 rounded-full font-sans font-semibold text-base transition-all duration-150"
              style={{
                background: pressing && !saving ? "#e8e0d8" : "#ffffff",
                color: "#1a1412",
              }}
            >
              {saving ? "Saving…" : "Go to Chat"}
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Form steps (name, location, age)
  return (
    <div className="h-dvh relative overflow-hidden">
      {/* Solid warm background matching the images */}
      <div className="absolute inset-0" style={{ background: "#a08a78" }} />

      <div className="relative z-10 h-full flex flex-col">
        {/* Back button */}
        <header className="px-5 pt-4 pb-2">
          <button
            onClick={goBack}
            className="w-10 h-10 rounded-full glass flex items-center justify-center"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
        </header>

        {/* Content with transition */}
        <div key={animKey} className={`flex-1 flex flex-col px-8 ${animClass}`}>
          {/* Spacer */}
          <div className="flex-1" />

          {/* Question */}
          <h1 className="text-4xl font-serif text-foreground leading-snug mb-4">
            {step === "name" && "How we should call you?"}
            {step === "location" && "Where do you live"}
            {step === "age" && "Whats your age?"}
          </h1>

          {/* Input */}
          {step === "name" && (
            <div className="glass rounded-2xl px-5 py-4 mb-3">
              <input
                type="text"
                placeholder="User input"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-transparent text-sm font-sans text-foreground placeholder:text-foreground/50 focus:outline-none"
                autoFocus
                aria-label="Your name"
              />
            </div>
          )}

          {step === "location" && (
            <div className="mb-3">
              <button
                onClick={() => setLocationSheetOpen(true)}
                disabled={countriesLoading}
                className="w-full glass rounded-2xl px-5 py-4 flex items-center gap-3 text-left"
              >
                {selectedCountry ? (
                  <>
                    <span className="text-lg">{selectedCountry.flag}</span>
                    <span className="text-sm font-sans text-foreground">{selectedCountry.name}</span>
                  </>
                ) : (
                  <span className="text-sm font-sans text-foreground/70">
                    {countriesLoading ? "Loading…" : "Select country"}
                  </span>
                )}
              </button>
              <Sheet open={locationSheetOpen} onOpenChange={setLocationSheetOpen}>
                <SheetContent side="bottom" className="h-[70dvh] flex flex-col rounded-t-3xl">
                  <SheetHeader>
                    <SheetTitle className="text-foreground">Select country</SheetTitle>
                  </SheetHeader>
                  <ScrollArea className="flex-1 -mx-4 px-4">
                    <div className="flex flex-col gap-0 pb-4">
                      {countries.map((c) => (
                        <button
                          key={c.id}
                          onClick={() => {
                            setSelectedCountry(c)
                            setLocationSheetOpen(false)
                          }}
                          className="flex items-center gap-3 px-4 py-3 rounded-xl text-left hover:bg-white/10 transition-colors"
                        >
                          <span className="text-lg">{c.flag}</span>
                          <span className="text-sm font-sans text-foreground/90">{c.name}</span>
                        </button>
                      ))}
                    </div>
                  </ScrollArea>
                </SheetContent>
              </Sheet>
            </div>
          )}

          {step === "age" && (
            <div className="mb-3">
              <div className="glass rounded-2xl px-5 py-4">
                <input
                  type="number"
                  placeholder={`Between ${AGE_MIN} and ${AGE_MAX}`}
                  value={age}
                  onChange={(e) => {
                    setAge(e.target.value)
                    setAgeError("")
                  }}
                  onBlur={() => {
                    const n = parseInt(age.trim(), 10)
                    if (age.trim() && (Number.isNaN(n) || n < AGE_MIN || n > AGE_MAX)) {
                      setAgeError(`Age must be between ${AGE_MIN} and ${AGE_MAX}`)
                    } else {
                      setAgeError("")
                    }
                  }}
                  className="w-full bg-transparent text-sm font-sans text-foreground placeholder:text-foreground/50 focus:outline-none"
                  autoFocus
                  min={AGE_MIN}
                  max={AGE_MAX}
                  aria-label="Your age"
                  aria-invalid={!!ageError}
                />
              </div>
              {ageError && (
                <p className="mt-2 text-sm font-sans text-red-600 dark:text-red-400" role="alert">
                  {ageError}
                </p>
              )}
            </div>
          )}

          {/* See why link */}
          <p className="text-sm font-sans text-foreground/80 mb-6">
            {"See why we need to know "}
            <button
              onClick={() => openWhy(step as "name" | "location" | "age")}
              className="font-bold text-foreground underline underline-offset-2"
            >
              here
            </button>
          </p>

          {/* Spacer to push button down */}
          <div className="flex-[1.5]" />
        </div>

        {/* Continue button */}
        <div className="px-8 pb-10">
          <button
            onClick={canContinue() ? goNext : undefined}
            onPointerDown={() => canContinue() && setPressing(true)}
            onPointerUp={() => setPressing(false)}
            onPointerLeave={() => setPressing(false)}
            className="btn-continue w-full py-4 rounded-full font-sans font-semibold text-base transition-all duration-150"
            style={{
              background: pressing && canContinue() ? "#e8e0d8" : canContinue() ? "#ffffff" : "rgba(255,255,255,0.5)",
              color: canContinue() ? "#1a1412" : "rgba(26,20,18,0.5)",
              cursor: canContinue() ? "pointer" : "default",
            }}
            disabled={!canContinue()}
          >
            Continue
          </button>
        </div>
      </div>

      {/* Why modal */}
      <WhyModal
        isOpen={whyOpen}
        onClose={() => setWhyOpen(false)}
        title={whyTexts[whyField]?.title || ""}
        paragraphs={whyTexts[whyField]?.paragraphs || []}
      />
    </div>
  )
}
