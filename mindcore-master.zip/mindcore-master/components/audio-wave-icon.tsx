"use client"

export function AudioWaveIcon({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-[3px] ${className}`} aria-hidden="true">
      {[12, 18, 24, 18, 12].map((h, i) => (
        <div
          key={i}
          className="w-[3px] rounded-full bg-foreground/70"
          style={{ height: `${h}px` }}
        />
      ))}
    </div>
  )
}
