"use client"

import Image from "next/image"
import { cn } from "@/lib/utils"
import { useCorlTheme } from "@/components/corl-theme-provider"

/** 1:1 app logo; dark theme = white (inverted), light theme = dark asset */
export function AppLogo({ className }: { className?: string }) {
  const { theme } = useCorlTheme()
  const isDark = theme === "dark"
  return (
    <Image
      src="/logo-mind-dark.png"
      alt="MindCore"
      width={40}
      height={40}
      className={cn("shrink-0", isDark && "brightness-0 invert", className)}
      unoptimized
      priority
    />
  )
}
