"use client"

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from "react"
import { createClient } from "@/lib/supabase/client"

interface CorlThemeContextValue {
  /** true = dark (default), false = light */
  preferDark: boolean
  setPreferDark: (value: boolean) => Promise<void>
  /** Resolved theme for UI (e.g. logo): "dark" | "light" */
  theme: "dark" | "light"
}

const CorlThemeContext = createContext<CorlThemeContextValue | null>(null)

function applyThemeToDocument(preferDark: boolean) {
  const html = document.documentElement
  if (preferDark) {
    html.classList.remove("light")
    html.classList.add("dark")
  } else {
    html.classList.remove("dark")
    html.classList.add("light")
  }
}

export function CorlThemeProvider({ children }: { children: ReactNode }) {
  const [preferDark, setPreferDarkState] = useState<boolean>(true)
  const [hydrated, setHydrated] = useState(false)

  const setPreferDark = useCallback(async (value: boolean) => {
    setPreferDarkState(value)
    applyThemeToDocument(value)
    const supabase = createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (user) {
      await supabase
        .from("profiles")
        .update({ prefer_dark: value, updated_at: new Date().toISOString() })
        .eq("id", user.id)
    }
  }, [])

  useEffect(() => {
    applyThemeToDocument(preferDark)
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    const supabase = createClient()
    const loadPreference = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return
      const { data: profile } = await supabase
        .from("profiles")
        .select("prefer_dark")
        .eq("id", user.id)
        .single()
      if (profile?.prefer_dark === false) {
        setPreferDarkState(false)
        applyThemeToDocument(false)
      }
    }
    loadPreference()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(() => {
      loadPreference()
    })
    return () => subscription.unsubscribe()
  }, [hydrated])

  const value: CorlThemeContextValue = {
    preferDark,
    setPreferDark,
    theme: preferDark ? "dark" : "light",
  }

  return (
    <CorlThemeContext.Provider value={value}>
      {children}
    </CorlThemeContext.Provider>
  )
}

export function useCorlTheme() {
  const ctx = useContext(CorlThemeContext)
  if (!ctx) throw new Error("useCorlTheme must be used within CorlThemeProvider")
  return ctx
}
