"use client"

import { useState, useCallback, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, ChevronRight, MessageSquare, ChevronLeft } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"

interface Conversation {
  id: string
  title: string
  day: string
  date: string
  summary: string
}

interface Week {
  label: string
  dateRange: string
  weekStart: string
  conversations: Conversation[]
  insightReady: boolean
  hasWeeklyReflection?: boolean
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

function getWeekKey(sessionDate: string): string {
  const [y, m, d] = sessionDate.split("-").map(Number)
  const date = new Date(y, m - 1, d)
  const day = date.getDay()
  const start = new Date(date)
  start.setDate(date.getDate() - day)
  return start.toISOString().slice(0, 10)
}

function formatDateRange(weekKey: string): string {
  const start = new Date(weekKey + "T12:00:00")
  const end = new Date(start)
  end.setDate(end.getDate() + 6)
  const d1 = start.getDate()
  const d2 = end.getDate()
  const m1 = MONTHS[start.getMonth()]
  const m2 = MONTHS[end.getMonth()]
  const y = start.getFullYear()
  if (m1 === m2) return `${d1}-${d2} ${m1} ${y}`
  return `${d1} ${m1} - ${d2} ${m2} ${y}`
}

function formatSessionDate(sessionDate: string, dayOfWeek: string): string {
  const [y, m, d] = sessionDate.split("-").map(Number)
  const month = MONTHS[m - 1]
  return `${dayOfWeek} ${d} ${month}`
}

function groupSessionsIntoWeeks(
  sessions: { id: string; session_date: string; day_of_week: string; title: string | null; summary: string | null }[],
  weeklyReflections: { week_start: string }[]
): Week[] {
  const byWeek = new Map<string, typeof sessions>()
  for (const s of sessions) {
    const key = getWeekKey(s.session_date)
    if (!byWeek.has(key)) byWeek.set(key, [])
    byWeek.get(key)!.push(s)
  }
  const reflectionWeeks = new Set(weeklyReflections.map((w) => String(w.week_start)))
  const allWeekStarts = new Set<string>([...byWeek.keys(), ...reflectionWeeks])
  const sortedKeys = Array.from(allWeekStarts).sort().reverse()

  return sortedKeys.map((key) => {
    const list = (byWeek.get(key) ?? []).sort(
      (a, b) => a.session_date.localeCompare(b.session_date)
    )
    return {
      label: `Week ${key}`,
      dateRange: formatDateRange(key),
      weekStart: key,
      conversations: list.map((s) => ({
        id: s.id,
        title: s.title?.trim() || "View Conversation",
        day: s.day_of_week,
        date: formatSessionDate(s.session_date, s.day_of_week),
        summary: s.summary?.trim() || "No summary yet.",
      })),
      insightReady: true,
      hasWeeklyReflection: reflectionWeeks.has(key),
    }
  })
}

// ---------------------
// Sub-view: Week overview
// ---------------------
const CARD_COLOR_CURRENT = "#AF9D8E"
const CARD_COLOR_PAST = "#8f8276"

function WeekView({
  week,
  onConversationClick,
  onViewReflection,
}: {
  week: Week
  onConversationClick: (conv: Conversation) => void
  onViewReflection: (weekStart: string) => void
}) {
  const isPastReflection = !!week.hasWeeklyReflection
  const cardColor = isPastReflection ? CARD_COLOR_PAST : CARD_COLOR_CURRENT

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-28 pt-4">
      {/* Weekly Reflection Card: muted when past */}
      <div
        className="rounded-2xl p-6 flex flex-col items-center gap-2 mb-8 text-[#1A1412]"
        style={{ backgroundColor: cardColor }}
      >
        <h3 className="text-2xl font-serif text-center text-balance">
          Weekly Reflection
        </h3>
        <p className="text-sm font-sans text-center text-black/70">
          {week.hasWeeklyReflection
            ? "Your reflection for this week is ready."
            : "Getting your reflection ready"}
        </p>
        <button
          type="button"
          onClick={() => week.hasWeeklyReflection && onViewReflection(week.weekStart)}
          disabled={!week.hasWeeklyReflection}
          className="mt-3 text-xs font-sans font-semibold tracking-[0.15em] text-black/70 uppercase disabled:opacity-60"
        >
          {week.hasWeeklyReflection ? "VIEW PAST REFLECTION" : "VIEW REFLECTION"}
        </button>
      </div>

      {/* Conversations */}
      <h4 className="text-base font-sans font-medium text-foreground/90 mb-4">
        Conversations
      </h4>
      <div className="flex flex-col gap-3">
        {week.conversations.length === 0 ? (
          <p className="text-sm font-sans text-foreground/50">
            No conversations this week.
          </p>
        ) : week.conversations.map((conv) => (
          <button
            key={conv.id}
            onClick={() => onConversationClick(conv)}
            className="glass rounded-2xl p-4 flex items-center justify-between text-left w-full transition-transform active:scale-[0.98]"
          >
            <div className="flex flex-col gap-1">
              <span className="text-base font-sans font-medium text-foreground">
                {conv.title}
              </span>
              <span className="text-sm font-sans text-foreground/50">
                {conv.day}
              </span>
            </div>
            <ChevronRight className="w-5 h-5 text-foreground/40 shrink-0" />
          </button>
        ))}
      </div>
    </div>
  )
}

// ---------------------
// Sub-view: Conversation detail
// ---------------------
function ConversationDetail({ conversation }: { conversation: Conversation }) {
  const router = useRouter()

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-28 pt-4">
      {/* Conversation button at top */}
      <Button
        type="button"
        size="lg"
        className="w-full mb-6 flex items-center justify-center gap-2"
        onClick={() =>
          router.push(
            `/chat?sessionId=${encodeURIComponent(conversation.id)}&mode=readonly`
          )
        }
      >
        <MessageSquare className="w-5 h-5" />
        <span>View Conversation</span>
      </Button>

      {/* Summary */}
      <h3 className="text-xl font-sans font-bold text-foreground mb-3">
        {conversation.title}
      </h3>
      <p className="text-sm font-sans text-foreground/70 leading-relaxed">
        {conversation.summary}
      </p>

      <div className="mt-6" />
    </div>
  )
}

// ---------------------
// Main HistoryPage
// ---------------------
export function HistoryPage() {
  const [weeks, setWeeks] = useState<Week[]>([])
  const [loading, setLoading] = useState(true)
  const [weekIndex, setWeekIndex] = useState(0)
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)

  const [slideDirection, setSlideDirection] = useState<"left" | "right" | null>(null)
  const [isAnimating, setIsAnimating] = useState(false)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const supabase = createClient()
    const run = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        setLoading(false)
        return
      }
      const { data: sessions } = await supabase
        .from("chat_sessions")
        .select("id, session_date, day_of_week, title, summary")
        .eq("user_id", user.id)
        .order("session_date", { ascending: false })

      const { data: weeklyReflections } = await supabase
        .from("weekly_reflections")
        .select("week_start")
        .eq("user_id", user.id)

      const grouped = groupSessionsIntoWeeks(sessions ?? [], weeklyReflections ?? [])
      setWeeks(grouped)
      setWeekIndex(0)
      setLoading(false)
    }
    run()
  }, [])

  const currentWeek = weeks[weekIndex] ?? { label: "", dateRange: "", conversations: [], insightReady: false }

  const canGoBack = selectedConversation !== null || weekIndex > 0
  const canGoForward = !selectedConversation && weekIndex < weeks.length - 1

  // Slide animation helper
  const animateSlide = useCallback(
    (direction: "left" | "right", callback: () => void) => {
      setSlideDirection(direction)
      setIsAnimating(true)

      // After exit animation
      const exitTimer = setTimeout(() => {
        callback()
        // Flip direction for enter
        setSlideDirection(direction === "left" ? "right" : "left")

        // After enter animation
        const enterTimer = setTimeout(() => {
          setSlideDirection(null)
          setIsAnimating(false)
        }, 30)

        return () => clearTimeout(enterTimer)
      }, 280)

      return () => clearTimeout(exitTimer)
    },
    []
  )

  const goBack = useCallback(() => {
    if (isAnimating) return
    if (selectedConversation) {
      animateSlide("right", () => setSelectedConversation(null))
    } else if (weekIndex > 0) {
      animateSlide("right", () => setWeekIndex((i) => i - 1))
    }
  }, [isAnimating, selectedConversation, weekIndex, animateSlide])

  const goForward = useCallback(() => {
    if (isAnimating || selectedConversation) return
    if (weekIndex < weeks.length - 1) {
      animateSlide("left", () => setWeekIndex((i) => i + 1))
    }
  }, [isAnimating, selectedConversation, weekIndex, weeks.length, animateSlide])

  const openConversation = useCallback(
    (conv: Conversation) => {
      if (isAnimating) return
      animateSlide("left", () => setSelectedConversation(conv))
    },
    [isAnimating, animateSlide]
  )

  // Touch swipe support
  const touchStartX = useRef(0)
  const touchStartY = useRef(0)

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX
    touchStartY.current = e.touches[0].clientY
  }, [])

  const handleTouchEnd = useCallback(
    (e: React.TouchEvent) => {
      const dx = e.changedTouches[0].clientX - touchStartX.current
      const dy = e.changedTouches[0].clientY - touchStartY.current

      // Only trigger if horizontal swipe is dominant
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) {
        if (dx > 0 && canGoBack) {
          goBack()
        } else if (dx < 0 && canGoForward) {
          goForward()
        }
      }
    },
    [canGoBack, canGoForward, goBack, goForward]
  )

  const headerText = selectedConversation
    ? selectedConversation.date
    : currentWeek.dateRange || "History"

  // Compute slide class
  let slideClass = "translate-x-0 opacity-100"
  if (isAnimating && slideDirection === "left") {
    slideClass = "-translate-x-8 opacity-0"
  } else if (isAnimating && slideDirection === "right") {
    slideClass = "translate-x-8 opacity-0"
  }

  return (
    <div
      className="flex flex-col flex-1 overflow-hidden"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Header */}
      <header className="flex items-center justify-between px-5 pt-4 pb-2 shrink-0">
        <button
          onClick={goBack}
          disabled={!canGoBack}
          className="w-10 h-10 rounded-full glass flex items-center justify-center transition-opacity disabled:opacity-30"
          aria-label="Go back"
        >
          <ChevronLeft className="w-5 h-5 text-foreground" />
        </button>

        <span className="text-sm font-sans font-semibold tracking-wide text-foreground text-center">
          {headerText}
        </span>

        {!selectedConversation ? (
          <button
            onClick={goForward}
            disabled={!canGoForward}
            className="w-10 h-10 rounded-full glass flex items-center justify-center transition-opacity disabled:opacity-30"
            aria-label="Go forward"
          >
            <ChevronRight className="w-5 h-5 text-foreground" />
          </button>
        ) : (
          <div className="w-10 h-10" />
        )}
      </header>

      {/* Content with slide animation */}
      <div
        ref={contentRef}
        className={`flex flex-col flex-1 overflow-hidden transition-all duration-280 ease-out ${slideClass}`}
        style={{ transitionDuration: "280ms" }}
      >
        {loading ? (
          <div className="flex flex-1 items-center justify-center px-5">
            <p className="text-sm font-sans text-foreground/60">Loading...</p>
          </div>
        ) : selectedConversation ? (
          <ConversationDetail conversation={selectedConversation} />
        ) : weeks.length === 0 ? (
          <div className="flex flex-1 items-center justify-center px-5">
            <p className="text-sm font-sans text-foreground/60 text-center">
              No conversations yet. Start chatting to see your history here.
            </p>
          </div>
        ) : (
          <WeekView
            week={currentWeek}
            onConversationClick={openConversation}
            onViewReflection={(weekStart) => router.push(`/reflection?weekStart=${encodeURIComponent(weekStart)}`)}
          />
        )}
      </div>
    </div>
  )
}
