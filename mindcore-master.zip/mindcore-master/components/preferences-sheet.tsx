"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { ArrowLeft } from "lucide-react"
import { useCorlTheme } from "@/components/corl-theme-provider"
import { Switch } from "@/components/ui/switch"
import { createClient } from "@/lib/supabase/client"

interface PreferencesSheetProps {
  isOpen: boolean
  onClose: () => void
}

export function PreferencesSheet({ isOpen, onClose }: PreferencesSheetProps) {
  const [visible, setVisible] = useState(false)
  const [sheetY, setSheetY] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const [experimentalEnabled, setExperimentalEnabled] = useState(false)
  const [loadingExperimental, setLoadingExperimental] = useState(true)
  const isDragging = useRef(false)
  const startYRef = useRef(0)
  const lastYRef = useRef(0)
  const velocityRef = useRef(0)
  const lastTimeRef = useRef(0)
  const { preferDark, setPreferDark } = useCorlTheme()
  const supabase = createClient()

  useEffect(() => {
    if (isOpen) {
      setVisible(true)
      setSheetY(window.innerHeight)
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setIsAnimating(true)
          setSheetY(0)
        })
      })
    } else if (visible) {
      setIsAnimating(true)
      setSheetY(window.innerHeight)
      const t = setTimeout(() => {
        setVisible(false)
        setIsAnimating(false)
      }, 500)
      return () => clearTimeout(t)
    }
  }, [isOpen, visible])

  useEffect(() => {
    const loadExperimentalPreference = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        setLoadingExperimental(false)
        return
      }
      const { data } = await supabase
        .from("profiles")
        .select("experimental_features_enabled")
        .eq("id", user.id)
        .single()
      if (data && typeof data.experimental_features_enabled === "boolean") {
        setExperimentalEnabled(data.experimental_features_enabled)
      }
      setLoadingExperimental(false)
    }
    if (isOpen) {
      loadExperimentalPreference()
    }
  }, [isOpen, supabase])

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    isDragging.current = true
    startYRef.current = e.touches[0].clientY
    lastYRef.current = e.touches[0].clientY
    lastTimeRef.current = Date.now()
    velocityRef.current = 0
    setIsAnimating(false)
  }, [])

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging.current) return
    const currentTouch = e.touches[0].clientY
    const diff = currentTouch - startYRef.current
    const now = Date.now()
    const dt = now - lastTimeRef.current
    if (dt > 0) velocityRef.current = (currentTouch - lastYRef.current) / dt
    lastYRef.current = currentTouch
    lastTimeRef.current = now
    if (diff > 0) setSheetY(diff)
  }, [])

  const handleTouchEnd = useCallback(() => {
    isDragging.current = false
    if (sheetY > 120 || velocityRef.current > 0.5) {
      setIsAnimating(true)
      setSheetY(window.innerHeight)
      setTimeout(onClose, 450)
    } else {
      setIsAnimating(true)
      setSheetY(0)
    }
  }, [sheetY, onClose])

  const handleToggle = useCallback(
    (checked: boolean) => {
      setPreferDark(checked)
    },
    [setPreferDark]
  )

  const handleExperimentalToggle = useCallback(
    async (checked: boolean) => {
      setExperimentalEnabled(checked)
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return
      await supabase
        .from("profiles")
        .update({ experimental_features_enabled: checked })
        .eq("id", user.id)
    },
    [supabase]
  )

  if (!visible) return null

  return (
    <div className="fixed inset-0 z-[60]" role="dialog" aria-modal="true" aria-label="Preferences">
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity duration-500"
        style={{ opacity: isOpen && sheetY < 100 ? 1 : 0 }}
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="absolute inset-x-0 bottom-0 top-8 corl-gradient rounded-t-3xl flex flex-col touch-none"
        style={{
          transform: `translateY(${sheetY}px)`,
          transition: isAnimating ? "transform 500ms cubic-bezier(0.32, 0.72, 0, 1)" : "none",
          willChange: "transform",
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="flex justify-center pt-3 pb-6 cursor-grab active:cursor-grabbing">
          <div className="w-10 h-1 rounded-full bg-foreground/40" />
        </div>
        <div className="px-5 pb-2 flex items-center gap-3">
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full glass flex items-center justify-center"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h2 className="text-lg font-sans font-semibold text-foreground">Preferences</h2>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-10 no-scrollbar">
          <div className="space-y-4">
            <div className="glass rounded-2xl p-5">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-sans font-medium text-foreground">Dark mode</p>
                  <p className="text-xs font-sans text-muted-foreground mt-0.5">
                    Use dark theme (off for light theme)
                  </p>
                </div>
                <Switch checked={preferDark} onCheckedChange={handleToggle} />
              </div>
            </div>
            <div className="glass rounded-2xl p-5">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-sans font-medium text-foreground">Try experimental features</p>
                  <p className="text-xs font-sans text-muted-foreground mt-0.5">
                    Turn this on to try early features before they&apos;re fully released.
                  </p>
                </div>
                <Switch
                  checked={experimentalEnabled}
                  disabled={loadingExperimental}
                  onCheckedChange={handleExperimentalToggle}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
