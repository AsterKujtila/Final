"use client"

import Image from "next/image"
import { useCorlTheme } from "@/components/corl-theme-provider"

const HELPLINE_URL = "https://findahelpline.com"

export function CrisisCard() {
  const { theme } = useCorlTheme()
  const isDark = theme === "dark"
  const iconSrc = isDark ? "/darkmodeuse.png" : "/lightmodeuse.png"

  return (
    <div className="w-full px-0">
      <div
        className="w-full rounded-[10px] border border-foreground/20 bg-card px-4 py-4 flex flex-col gap-3"
        role="region"
        aria-label="Reach out to someone"
      >
        <div className="flex items-start gap-3">
          <div className="shrink-0 w-8 h-8 relative">
            <Image
              src={iconSrc}
              alt=""
              width={32}
              height={32}
              className="object-contain"
            />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-serif font-semibold text-foreground leading-snug">
              Reach out to someone
            </h3>
            <p className="text-sm font-sans text-foreground/90 leading-relaxed mt-1">
              MindCore is not designed for these situations, but we can redirect you to people who are there to help you through. Below you can find a local helpline.
            </p>
          </div>
        </div>
        <a
          href={HELPLINE_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full rounded-[10px] py-3 px-4 text-center text-sm font-sans font-semibold bg-[#B39A7F] text-[#1a1412] hover:opacity-90 transition-opacity no-underline"
        >
          Find a helpline
        </a>
      </div>
    </div>
  )
}
