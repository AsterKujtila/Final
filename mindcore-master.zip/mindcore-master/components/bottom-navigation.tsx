"use client"

import { cn } from "@/lib/utils"
import { MessageCircle, Flower2, Clock } from "lucide-react"

interface BottomNavigationProps {
  activeTab: "chat" | "you" | "history"
  onTabChange: (tab: "chat" | "you" | "history") => void
}

const iconSize = 22
const iconStroke = 1.75

const tabs = [
  { id: "chat" as const, label: "Chat", Icon: MessageCircle },
  { id: "you" as const, label: "You", Icon: Flower2 },
  { id: "history" as const, label: "History", Icon: Clock },
]

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40">
      <div className="glass-strong mx-4 mb-4 flex items-center justify-around rounded-full px-4 py-3 min-h-[56px] max-w-[280px] mx-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id
          const Icon = tab.Icon
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={cn(
                "flex flex-1 flex-col items-center justify-center gap-1 min-w-0 max-w-[88px] py-1 rounded-xl transition-colors duration-200",
                isActive ? "text-foreground" : "text-foreground/55"
              )}
              aria-label={tab.label}
              aria-current={isActive ? "page" : undefined}
            >
              <Icon
                size={iconSize}
                strokeWidth={isActive ? 2.25 : iconStroke}
                className={cn("shrink-0", isActive && "text-foreground")}
              />
              <span
                className={cn(
                  "text-[11px] font-sans leading-tight truncate w-full text-center transition-colors duration-200",
                  isActive ? "font-semibold text-foreground/95" : "font-medium text-foreground/55"
                )}
              >
                {tab.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
