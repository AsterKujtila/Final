"use client"

import { useState, useEffect, useCallback } from "react"
import { ChevronRight } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerDescription,
  DrawerFooter,
  DrawerClose,
} from "@/components/ui/drawer"
import { Button } from "@/components/ui/button"
import { ReflectionStatusIcon } from "@/components/reflection-status"

interface YouPageProps {
  onNavigateInsights: () => void
  onNavigateReflection?: () => void
}

interface WeeklyReflectionStatus {
  currentWeek: {
    weekStart: string
    weekEnd: string
    progress: number
    hasAnyChat: boolean
    totalDays: number
  }
  lastWeek: {
    weekStart: string
    weekEnd: string
    hasAnyChat: boolean
    hasReflection: boolean
    cycleCompleted: boolean
  }
}

export function YouPage({ onNavigateInsights, onNavigateReflection }: YouPageProps) {
  const [status, setStatus] = useState<WeeklyReflectionStatus | null>(null)
  const [statusLoading, setStatusLoading] = useState(true)
  const [sheetOpen, setSheetOpen] = useState(false)

  useEffect(() => {
    const run = async () => {
      try {
        setStatusLoading(true)
        const res = await fetch("/api/reflection/status")
        if (!res.ok) return
        const data = (await res.json()) as WeeklyReflectionStatus
        setStatus(data)
      } finally {
        setStatusLoading(false)
      }
    }
    run().catch(() => {})
  }, [])

  const hasReadyReflection =
    !!status?.lastWeek.hasReflection || !!status?.lastWeek.cycleCompleted

  const handleReflectionClick = useCallback(() => {
    if (statusLoading) return
    if (hasReadyReflection) {
      onNavigateReflection?.()
      return
    }
    setSheetOpen(true)
  }, [statusLoading, hasReadyReflection, onNavigateReflection])

  const hasAnyChatCurrentWeek = status?.currentWeek.hasAnyChat ?? false

  return (
    <div className="flex-1 px-5 pb-28 pt-4 overflow-y-auto no-scrollbar">
      {/* Reflection Card */}
      <button
        type="button"
        onClick={handleReflectionClick}
        className="rounded-3xl p-6 mb-6 w-full text-left transition-transform active:scale-[0.98]"
        style={{ backgroundColor: "#AF9D8E", color: "#1A1412" }}
      >
        <h3 className="text-2xl font-serif mb-2 text-balance">
          {hasReadyReflection ? "Your reflection" : "Getting your reflection ready"}
        </h3>
        <p className="text-sm font-sans opacity-80 mb-4">
          {statusLoading
            ? "Loading..."
            : !hasAnyChatCurrentWeek
            ? "Start chatting this week and MindCore will begin forming a reflection for you."
            : "MindCore is quietly collecting this week’s conversations into a reflection."}
        </p>
        <p className="text-xs font-sans font-semibold tracking-[0.12em] opacity-70 uppercase">
          {hasReadyReflection ? "VIEW REFLECTION" : "MINDCORE IS THINKING"}
        </p>
      </button>

      {/* Things to look after */}
      <div>
        <h4 className="text-base font-sans font-semibold text-foreground/90 mb-3">
          Things to look after
        </h4>
        <button
          onClick={onNavigateInsights}
          className="w-full glass rounded-2xl px-5 py-4 flex items-center justify-between"
        >
          <span className="text-sm font-sans text-foreground/80">
            MindCore made some insights
          </span>
          <ChevronRight className="w-5 h-5 text-foreground/40" />
        </button>
      </div>

      <Drawer open={sheetOpen} onOpenChange={setSheetOpen}>
        <DrawerContent className="border-t bg-background rounded-t-3xl flex flex-col">
          <DrawerHeader className="flex flex-col items-center gap-4 pt-6">
            <ReflectionStatusIcon
              size="lg"
              progress={status?.currentWeek.progress ?? 0.3}
            />
            <div className="space-y-2 text-center px-6">
              <p className="text-xs font-sans font-semibold tracking-[0.2em] uppercase text-foreground/70">
                {!hasAnyChatCurrentWeek
                  ? "Start chatting, reflection will form."
                  : "Keep talking, reflection is forming."}
              </p>
              <DrawerDescription className="text-sm text-foreground/75">
                {!hasAnyChatCurrentWeek
                  ? "Once you start chatting this week, we’ll begin forming your weekly reflection in the background."
                  : "Every conversation this week adds more detail to your reflection. You’ll be able to read it once the week is complete."}
              </DrawerDescription>
            </div>
          </DrawerHeader>
          <DrawerFooter>
            <DrawerClose asChild>
              <Button className="w-full" size="lg">
                Back to You
              </Button>
            </DrawerClose>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>
    </div>
  )
}
