"use client"

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react"

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<{ outcome: "accepted" | "dismissed" }>
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>
}

interface PWAInstallContextValue {
  canInstall: boolean
  isInstalled: boolean
  install: () => Promise<void>
}

const PWAInstallContext = createContext<PWAInstallContextValue>({
  canInstall: false,
  isInstalled: false,
  install: async () => {},
})

const SW_URL = "/sw.js"

export function PWAInstallProvider({ children }: { children: ReactNode }) {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [swRegistered, setSwRegistered] = useState(false)

  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) return
    navigator.serviceWorker
      .register(SW_URL, { scope: "/" })
      .then(() => setSwRegistered(true))
      .catch(() => {})
  }, [])

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
    }
    window.addEventListener("beforeinstallprompt", handler)
    return () => window.removeEventListener("beforeinstallprompt", handler)
  }, [])

  const install = useCallback(async () => {
    if (!deferredPrompt) return
    await deferredPrompt.prompt()
    setDeferredPrompt(null)
  }, [deferredPrompt])

  const isStandalone =
    typeof window !== "undefined" &&
    (window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true)

  const canInstall = Boolean(swRegistered && deferredPrompt && !isStandalone)

  return (
    <PWAInstallContext.Provider
      value={{
        canInstall,
        isInstalled: isStandalone,
        install,
      }}
    >
      {children}
    </PWAInstallContext.Provider>
  )
}

export function usePWAInstall(): PWAInstallContextValue {
  return useContext(PWAInstallContext)
}
