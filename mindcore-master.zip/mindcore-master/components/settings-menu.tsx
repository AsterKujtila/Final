"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import {
  ChevronRight,
  Settings,
  UserCircle,
  Info,
  MessageSquare,
  Phone,
  Share2,
  LogOut,
  ArrowLeft,
  Download,
  type LucideIcon,
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { cn } from "@/lib/utils"
import { useCorlTheme } from "@/components/corl-theme-provider"
import { usePWAInstall } from "@/components/pwa-install-provider"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

const MENU_TRANSITION_MS = 350
const PANEL_FADE_MS = 280
const MENU_EASING = "cubic-bezier(0.32, 0.72, 0, 1)"

interface SettingsMenuProps {
  isOpen: boolean
  onClose: () => void
  onItemClick?: (label: string) => void
}

const menuItemIcon: Record<string, LucideIcon> = {
  Preferences: Settings,
  Account: UserCircle,
  About: Info,
  Feedback: MessageSquare,
  "Find a helpline": Phone,
  "Share MindCore": Share2,
  "Install MindCore": Download,
  Logout: LogOut,
}

const MENU_GROUPS_BASE: { label: string }[][] = [
  [
    { label: "Preferences" },
    { label: "Account" },
    { label: "About" },
    { label: "Feedback" },
  ],
  [
    { label: "Find a helpline" },
    { label: "Share MindCore" },
  ],
  [{ label: "Logout" }],
]

const IN_SHEET_ITEMS = new Set([
  "Preferences",
  "Account",
  "About",
  "Feedback",
  "Find a helpline",
  "Share MindCore",
])

interface CountryRow {
  id: string
  name: string
  flag: string
}

const DELETE_PHRASE = "delete my account"

export function SettingsMenu({ isOpen, onClose, onItemClick }: SettingsMenuProps) {
  const [visible, setVisible] = useState(false)
  const [sheetY, setSheetY] = useState(0)
  const [isAnimatingIn, setIsAnimatingIn] = useState(false)
  const [panelStack, setPanelStack] = useState<string[]>([])
  const [panelDirection, setPanelDirection] = useState<"in" | "out">("in")
  const isDragging = useRef(false)
  const startY = useRef(0)
  const lastY = useRef(0)
  const velocity = useRef(0)
  const lastTime = useRef(0)
  const { preferDark, setPreferDark } = useCorlTheme()
  const [experimentalEnabled, setExperimentalEnabled] = useState(false)
  const [loadingExperimental, setLoadingExperimental] = useState(false)
  const [preferredVoice, setPreferredVoice] = useState<string>("alloy")
  const [loadingVoice, setLoadingVoice] = useState(false)
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null)
  const supabase = createClient()

  const TTS_SAMPLE = "Hi, this is your voice."
  const VOICE_OPTIONS: { id: string; name: string }[] = [
    { id: "alloy", name: "Alloy" },
    { id: "nova", name: "Nova" },
    { id: "shimmer", name: "Shimmer" },
  ]

  const activePanel = panelStack[panelStack.length - 1] ?? null

  const openPanel = useCallback((label: string) => {
    setPanelDirection("in")
    setPanelStack((s) => [...s, label])
  }, [])

  const closePanel = useCallback(() => {
    setPanelDirection("out")
    setTimeout(() => {
      setPanelStack((s) => (s.length <= 1 ? [] : s.slice(0, -1)))
    }, PANEL_FADE_MS)
  }, [])

  const goBack = useCallback(() => {
    if (panelStack.length <= 1) closePanel()
    else closePanel()
  }, [panelStack.length, closePanel])

  useEffect(() => {
    if (!isOpen && visible) setPanelStack([])
  }, [isOpen, visible])

  useEffect(() => {
    if (isOpen) {
      setVisible(true)
      setSheetY(window.innerHeight)
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setIsAnimatingIn(true)
          setSheetY(0)
        })
      })
    } else if (visible) {
      setIsAnimatingIn(true)
      setSheetY(window.innerHeight)
      const timer = setTimeout(() => {
        setVisible(false)
        setIsAnimatingIn(false)
      }, MENU_TRANSITION_MS)
      return () => clearTimeout(timer)
    }
  }, [isOpen])

  useEffect(() => {
    if (visible) document.body.style.overflow = "hidden"
    else document.body.style.overflow = ""
    return () => { document.body.style.overflow = "" }
  }, [visible])

  const { canInstall, install } = usePWAInstall()

  const menuGroups: { label: string }[][] = [
    MENU_GROUPS_BASE[0],
    [
      ...MENU_GROUPS_BASE[1],
      ...(canInstall ? [{ label: "Install MindCore" }] : []),
    ],
    MENU_GROUPS_BASE[2],
  ]

  const handleItemClick = useCallback(
    (label: string) => {
      if (label === "Install MindCore") {
        install()
        return
      }
      if (IN_SHEET_ITEMS.has(label)) {
        openPanel(label)
        return
      }
      onItemClick?.(label)
    },
    [openPanel, onItemClick, install]
  )

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    isDragging.current = true
    startY.current = e.touches[0].clientY
    lastY.current = e.touches[0].clientY
    lastTime.current = Date.now()
    velocity.current = 0
    setIsAnimatingIn(false)
  }, [])

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging.current) return
    const currentTouch = e.touches[0].clientY
    const diff = currentTouch - startY.current
    const now = Date.now()
    const dt = now - lastTime.current
    if (dt > 0) velocity.current = (currentTouch - lastY.current) / dt
    lastY.current = currentTouch
    lastTime.current = now
    if (diff > 0) setSheetY(diff)
  }, [])

  const handleTouchEnd = useCallback(() => {
    isDragging.current = false
    if (sheetY > 120 || velocity.current > 0.5) {
      setIsAnimatingIn(true)
      setSheetY(window.innerHeight)
      setTimeout(onClose, MENU_TRANSITION_MS - 50)
    } else {
      setIsAnimatingIn(true)
      setSheetY(0)
    }
  }, [sheetY, onClose])

  useEffect(() => {
    const loadPreferences = async () => {
      setLoadingExperimental(true)
      setLoadingVoice(true)
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        setLoadingExperimental(false)
        setLoadingVoice(false)
        return
      }
      const { data } = await supabase
        .from("profiles")
        .select("experimental_features_enabled, preferred_voice")
        .eq("id", user.id)
        .single()
      if (data && typeof data.experimental_features_enabled === "boolean") {
        setExperimentalEnabled(data.experimental_features_enabled)
      }
      if (data?.preferred_voice && ["alloy", "nova", "shimmer"].includes(data.preferred_voice)) {
        setPreferredVoice(data.preferred_voice)
      }
      setLoadingExperimental(false)
      setLoadingVoice(false)
    }

    if (isOpen && activePanel === "Preferences") {
      loadPreferences()
    }
  }, [isOpen, activePanel, supabase])

  const handleExperimentalToggle = useCallback(
    async (checked: boolean) => {
      setExperimentalEnabled(checked)
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return
      await supabase
        .from("profiles")
        .update({ experimental_features_enabled: checked })
        .eq("id", user.id)
    },
    [supabase]
  )

  const handleVoiceSelect = useCallback(
    async (voiceId: string) => {
      setPreferredVoice(voiceId)
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (user) {
        await supabase
          .from("profiles")
          .update({ preferred_voice: voiceId, updated_at: new Date().toISOString() })
          .eq("id", user.id)
      }
      setPlayingVoiceId(voiceId)
      try {
        const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: TTS_SAMPLE, voice: voiceId }),
        })
        if (!res.ok) return
        const blob = await res.blob()
        const url = URL.createObjectURL(blob)
        const audio = new Audio(url)
        audio.onended = () => {
          URL.revokeObjectURL(url)
          setPlayingVoiceId(null)
        }
        await audio.play()
      } catch {
        setPlayingVoiceId(null)
      }
    },
    [supabase]
  )

  const handlePointerStart = useCallback((e: React.PointerEvent) => {
    if (e.pointerType === "touch") return
    isDragging.current = true
    startY.current = e.clientY
    lastY.current = e.clientY
    lastTime.current = Date.now()
    velocity.current = 0
    setIsAnimatingIn(false)
    ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
  }, [])

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (e.pointerType === "touch" || !isDragging.current) return
    const diff = e.clientY - startY.current
    const now = Date.now()
    const dt = now - lastTime.current
    if (dt > 0) velocity.current = (e.clientY - lastY.current) / dt
    lastY.current = e.clientY
    lastTime.current = now
    if (diff > 0) setSheetY(diff)
  }, [])

  const handlePointerEnd = useCallback(() => {
    isDragging.current = false
    if (sheetY > 120 || velocity.current > 0.5) {
      setIsAnimatingIn(true)
      setSheetY(window.innerHeight)
      setTimeout(onClose, MENU_TRANSITION_MS - 50)
    } else {
      setIsAnimatingIn(true)
      setSheetY(0)
    }
  }, [sheetY, onClose])

  if (!visible) return null

  const showList = panelStack.length === 0
  const listOpacity = showList ? 1 : 0
  const listTranslateX = showList ? 0 : panelDirection === "in" ? -12 : 12
  const panelOpacity = activePanel ? 1 : 0
  const panelTranslateX = activePanel ? 0 : panelDirection === "out" ? 12 : -12

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Settings menu">
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        style={{
          opacity: isOpen && sheetY < 100 ? 1 : 0,
          transition: `opacity ${MENU_TRANSITION_MS}ms ${MENU_EASING}`,
        }}
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="absolute inset-x-0 bottom-0 top-8 bg-background rounded-t-3xl flex flex-col touch-none"
        style={{
          transform: `translateY(${sheetY}px)`,
          transition: isAnimatingIn ? `transform ${MENU_TRANSITION_MS}ms ${MENU_EASING}` : "none",
          willChange: "transform",
        }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onPointerDown={handlePointerStart}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerEnd}
      >
        <div className="flex justify-center pt-3 pb-6 cursor-grab active:cursor-grabbing">
          <div className="w-10 h-1 rounded-full bg-foreground/40" />
        </div>

        <div className="flex-1 overflow-hidden flex flex-col min-h-0">
          <div className="flex-1 flex min-h-0 relative">
            {/* List */}
            <div
              className="absolute inset-y-0 left-0 right-0 overflow-y-auto px-5 pb-10 no-scrollbar"
              style={{
                opacity: listOpacity,
                transform: `translateX(${listTranslateX}px)`,
                transition: `opacity ${PANEL_FADE_MS}ms ${MENU_EASING}, transform ${PANEL_FADE_MS}ms ${MENU_EASING}`,
                visibility: showList ? "visible" : "hidden",
              }}
            >
              {menuGroups.map((group, groupIdx) => (
                <div key={groupIdx} className="glass rounded-2xl mb-4 overflow-hidden">
                  {group.map((item, itemIdx) => {
                    const Icon = menuItemIcon[item.label]
                    return (
                      <button
                        key={itemIdx}
                        onClick={() => handleItemClick(item.label)}
                        className="w-full flex items-center gap-4 px-5 py-4 text-foreground/90 hover:bg-white/5 transition-colors text-left"
                      >
                        {Icon && (
                          <Icon className="w-5 h-5 text-foreground/60 shrink-0" strokeWidth={1.5} />
                        )}
                        <span className="flex-1 text-sm font-sans font-normal">{item.label}</span>
                        <ChevronRight className="w-4 h-4 text-foreground/40 shrink-0" />
                      </button>
                    )
                  })}
                </div>
              ))}
            </div>

            {/* Panel */}
            <div
              className="absolute inset-y-0 left-0 right-0 flex flex-col"
              style={{
                opacity: panelOpacity,
                transform: `translateX(${panelTranslateX}px)`,
                transition: `opacity ${PANEL_FADE_MS}ms ${MENU_EASING}, transform ${PANEL_FADE_MS}ms ${MENU_EASING}`,
                visibility: activePanel ? "visible" : "hidden",
              }}
            >
              <div className="px-5 pb-2 flex items-center gap-3 shrink-0">
                <button
                  onClick={goBack}
                  className="w-10 h-10 rounded-full glass flex items-center justify-center"
                  aria-label="Back"
                >
                  <ArrowLeft className="w-5 h-5 text-foreground" />
                </button>
                <h2 className="text-lg font-sans font-semibold text-foreground">
                  {activePanel ?? ""}
                </h2>
              </div>
              <div className="flex-1 overflow-y-auto px-5 pb-10 no-scrollbar">
                {activePanel === "Preferences" && (
                  <div className="space-y-4">
                    <div className="glass rounded-2xl p-5">
                      <p className="text-sm font-sans font-medium text-foreground mb-3">
                        Preferred voice
                      </p>
                      <p className="text-xs font-sans text-muted-foreground mb-3">
                        Used for Read aloud in chat. Tap a card to select and hear a sample.
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        {VOICE_OPTIONS.map((opt) => {
                          const selected = preferredVoice === opt.id
                          const playing = playingVoiceId === opt.id
                          return (
                            <button
                              key={opt.id}
                              type="button"
                              disabled={loadingVoice}
                              onClick={() => handleVoiceSelect(opt.id)}
                              className={cn(
                                "rounded-xl border p-3 text-center transition-colors",
                                selected
                                  ? "border-foreground/40 bg-foreground/10"
                                  : "border-foreground/15 bg-transparent hover:bg-foreground/5"
                              )}
                            >
                              <p className="text-sm font-sans font-medium text-foreground truncate">
                                {opt.name}
                              </p>
                              {playing && (
                                <p className="text-[10px] font-sans text-foreground/60 mt-1">
                                  Playing…
                                </p>
                              )}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                    <div className="glass rounded-2xl p-5">
                      <div className="flex items-center justify-between gap-4">
                        <div>
                          <p className="text-sm font-sans font-medium text-foreground">Dark mode</p>
                          <p className="text-xs font-sans text-muted-foreground mt-0.5">
                            Use dark theme (off for light theme)
                          </p>
                        </div>
                        <Switch
                          checked={preferDark}
                          onCheckedChange={(checked) => setPreferDark(checked)}
                        />
                      </div>
                    </div>
                    <div className="glass rounded-2xl p-5">
                      <div className="flex items-center justify-between gap-4">
                        <div>
                          <p className="text-sm font-sans font-medium text-foreground">
                            Try experimental features
                          </p>
                          <p className="text-xs font-sans text-muted-foreground mt-0.5">
                            Turn this on to try early features before they&apos;re fully released.
                          </p>
                        </div>
                        <Switch
                          checked={experimentalEnabled}
                          disabled={loadingExperimental}
                          onCheckedChange={handleExperimentalToggle}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {activePanel === "Account" && (
                  <AccountPanelContent onOpenManageAccount={() => openPanel("Manage Account")} />
                )}

                {activePanel === "About" && <AboutPanelContent />}

                {activePanel === "Manage Account" && (
                  <ManageAccountPanelContent onClose={goBack} />
                )}

                {activePanel === "Feedback" && (
                  <FeedbackPanelContent />
                )}

                {activePanel === "Find a helpline" && (
                  <FindAHelplinePanelContent />
                )}

                {activePanel === "Share MindCore" && (
                  <SharePanelContent />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function AccountPanelContent({ onOpenManageAccount }: { onOpenManageAccount: () => void }) {
  return (
    <div className="space-y-4">
      <button
        onClick={() => {}}
        className="w-full glass rounded-2xl px-5 py-4 flex items-center gap-4 text-foreground/90 hover:bg-white/5 transition-colors text-left"
      >
        <Download className="w-5 h-5 text-foreground/60 shrink-0" strokeWidth={1.5} />
        <span className="flex-1 text-sm font-sans font-normal">Get my Data</span>
        <ChevronRight className="w-4 h-4 text-foreground/40 shrink-0" />
      </button>
      <button
        onClick={onOpenManageAccount}
        className="w-full glass rounded-2xl px-5 py-4 flex items-center gap-4 text-foreground/90 hover:bg-white/5 transition-colors text-left"
      >
        <UserCircle className="w-5 h-5 text-foreground/60 shrink-0" strokeWidth={1.5} />
        <span className="flex-1 text-sm font-sans font-normal">Manage Account</span>
        <ChevronRight className="w-4 h-4 text-foreground/40 shrink-0" />
      </button>
      <div className="glass rounded-2xl p-4">
        <p className="text-xs font-sans text-muted-foreground">
          Get my Data: request a copy of your data. Coming soon.
        </p>
      </div>
    </div>
  )
}

function ManageAccountPanelContent({ onClose }: { onClose: () => void }) {
  const supabase = createClient()
  const [profileName, setProfileName] = useState("")
  const [profileCountryId, setProfileCountryId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [locationSheetOpen, setLocationSheetOpen] = useState(false)
  const [locationSheetHeightDvh, setLocationSheetHeightDvh] = useState(70)
  const [deleteSheetOpen, setDeleteSheetOpen] = useState(false)
  const [deleteConfirmText, setDeleteConfirmText] = useState("")
  const [deleteLoading, setDeleteLoading] = useState(false)
  const [countries, setCountries] = useState<CountryRow[]>([])
  const [countriesLoading, setCountriesLoading] = useState(true)
  const countryDragStartY = useRef(0)

  const loadProfile = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data: profile } = await supabase
      .from("profiles")
      .select("name, country_id")
      .eq("id", user.id)
      .single()
    if (profile) {
      setProfileName(profile.name ?? "")
      setProfileCountryId(profile.country_id ?? null)
    }
  }, [])

  useEffect(() => {
    loadProfile()
  }, [loadProfile])

  useEffect(() => {
    supabase
      .from("countries")
      .select("id, name, flag")
      .order("name")
      .then(({ data, error }) => {
        setCountriesLoading(false)
        if (!error && data?.length) setCountries(data as CountryRow[])
      })
  }, [])

  const selectedCountry = countries.find((c) => c.id === profileCountryId)

  const handleSave = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    setSaving(true)
    await supabase
      .from("profiles")
      .update({
        name: profileName.trim(),
        country_id: profileCountryId,
        updated_at: new Date().toISOString(),
      })
      .eq("id", user.id)
    setSaving(false)
  }, [profileName, profileCountryId])

  const handleSelectCountry = useCallback((countryId: string) => {
    setProfileCountryId(countryId)
    setLocationSheetOpen(false)
  }, [])

  const handleDeleteAccount = useCallback(async () => {
    if (deleteConfirmText.trim().toLowerCase() !== DELETE_PHRASE) return
    setDeleteLoading(true)
    const res = await fetch("/api/account/delete", { method: "DELETE" })
    setDeleteLoading(false)
    if (res.ok) {
      await supabase.auth.signOut()
      setDeleteSheetOpen(false)
      setDeleteConfirmText("")
      onClose()
      window.location.href = "/login"
    }
  }, [deleteConfirmText, onClose])

  const handleCountrySheetDragStart = useCallback((clientY: number) => {
    countryDragStartY.current = clientY
  }, [])
  const handleCountrySheetDragMove = useCallback((clientY: number) => {
    const delta = countryDragStartY.current - clientY
    if (delta > 30) setLocationSheetHeightDvh(92)
  }, [])

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5 space-y-5">
        <div>
          <p className="text-sm font-sans font-medium text-foreground mb-2">Name</p>
          <Input
            value={profileName}
            onChange={(e) => setProfileName(e.target.value)}
            placeholder="Your name"
            className="w-full bg-transparent border-foreground/20 rounded-xl px-4 py-3"
          />
        </div>
        <div>
          <p className="text-sm font-sans font-medium text-foreground mb-2">Location</p>
          <button
            onClick={() => setLocationSheetOpen(true)}
            disabled={countriesLoading}
            className="w-full glass rounded-xl px-4 py-3 flex items-center gap-3 text-left text-sm font-sans text-foreground/90"
          >
            {selectedCountry ? (
              <>
                <span className="text-lg">{selectedCountry.flag}</span>
                <span>{selectedCountry.name}</span>
              </>
            ) : (
              <span className="text-foreground/70">
                {countriesLoading ? "Loading…" : "Select country"}
              </span>
            )}
          </button>
        </div>
        <Button
          type="button"
          onClick={handleSave}
          disabled={saving}
          size="lg"
          className="w-full"
        >
          {saving ? "Saving…" : "Save"}
        </Button>
      </div>

      <Sheet
        open={locationSheetOpen}
        onOpenChange={(open) => {
          setLocationSheetOpen(open)
          if (!open) setLocationSheetHeightDvh(70)
        }}
      >
        <SheetContent
          side="bottom"
          className="flex flex-col rounded-t-3xl p-0 gap-0 min-h-0"
          style={{ height: `${locationSheetHeightDvh}dvh` }}
        >
          <div
            className="flex shrink-0 justify-center pt-3 pb-2 cursor-grab active:cursor-grabbing touch-none"
            onTouchStart={(e) => handleCountrySheetDragStart(e.touches[0].clientY)}
            onTouchMove={(e) => handleCountrySheetDragMove(e.touches[0].clientY)}
            onPointerDown={(e) => {
              if (e.pointerType === "mouse") handleCountrySheetDragStart(e.clientY)
            }}
            onPointerMove={(e) => {
              if (e.pointerType === "mouse" && e.buttons === 1)
                handleCountrySheetDragMove(e.clientY)
            }}
          >
            <div className="w-10 h-1 rounded-full bg-foreground/40" />
          </div>
          <SheetHeader className="shrink-0 px-5 pb-2">
            <SheetTitle className="text-foreground">Select country</SheetTitle>
          </SheetHeader>
          <ScrollArea className="flex-1 min-h-0 overflow-hidden px-5">
            <div className="flex flex-col gap-0 pb-6">
              {countries.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleSelectCountry(c.id)}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl text-left hover:bg-white/10 transition-colors"
                >
                  <span className="text-lg">{c.flag}</span>
                  <span className="text-sm font-sans text-foreground/90">{c.name}</span>
                </button>
              ))}
            </div>
          </ScrollArea>
        </SheetContent>
      </Sheet>

      <div className="glass rounded-2xl p-5">
        <p className="text-sm font-sans font-medium text-foreground mb-3">Delete account</p>
        <Button
          type="button"
          onClick={() => setDeleteSheetOpen(true)}
          variant="outline"
          size="lg"
          className="w-full border-destructive/40 text-destructive hover:bg-destructive/10"
        >
          Delete account
        </Button>
        <Sheet open={deleteSheetOpen} onOpenChange={setDeleteSheetOpen}>
          <SheetContent
            side="bottom"
            className="rounded-t-3xl flex flex-col min-h-[55dvh] max-h-[90dvh]"
          >
            <SheetHeader>
              <SheetTitle className="text-foreground">Delete account</SheetTitle>
              <SheetDescription className="text-muted-foreground">
                Type &quot;{DELETE_PHRASE}&quot; below to delete your account. This cannot be undone.
              </SheetDescription>
            </SheetHeader>
            <div className="mt-6 space-y-5 flex-1">
              <Input
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                placeholder={DELETE_PHRASE}
                className="w-full rounded-xl px-4 py-3"
                aria-label="Confirmation phrase"
              />
              <Button
                type="button"
                disabled={
                  deleteConfirmText.trim().toLowerCase() !== DELETE_PHRASE || deleteLoading
                }
                onClick={handleDeleteAccount}
                variant="destructive"
                size="lg"
                className="w-full"
              >
                {deleteLoading ? "Deleting…" : "Delete my account"}
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  )
}

const FEEDBACK_REASONS = [
  { value: "bug", label: "Bug or technical issue" },
  { value: "suggestion", label: "Suggestion or idea" },
  { value: "other", label: "Other" },
] as const

function SharePanelContent() {
  const [sharing, setSharing] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleShare = useCallback(async () => {
    if (sharing) return
    setSharing(true)
    setCopied(false)
    try {
      const url =
        typeof window !== "undefined"
          ? window.location.origin || "https://mindcore-swart.vercel.app"
          : "https://mindcore-swart.vercel.app"
      const shareData = {
        title: "MindCore",
        text: "I’ve been using MindCore as a daily reflection companion.",
        url,
      }
      if (typeof navigator !== "undefined" && (navigator as any).share) {
        await (navigator as any).share(shareData)
      } else if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(url)
        setCopied(true)
      } else if (typeof window !== "undefined") {
        window.open(url, "_blank", "noopener,noreferrer")
      }
    } catch {
      // ignore
    } finally {
      setSharing(false)
    }
  }, [sharing])

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5 space-y-3">
        <p className="text-sm font-sans text-foreground/80">
          Share MindCore with someone who might find a gentle reflection companion helpful.
        </p>
        <Button
          type="button"
          size="lg"
          className="w-full"
          onClick={handleShare}
          disabled={sharing}
        >
          {sharing ? "Sharing…" : copied ? "Link copied" : "Share MindCore"}
        </Button>
      </div>
    </div>
  )
}

function AboutPanelContent() {
  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5 space-y-3">
        <p className="text-sm font-sans text-foreground/80">
          MindCore is an early development therapy app. It&apos;s designed to help you reflect on
          your thoughts and feelings, but it is not a substitute for professional care.
        </p>
        <p className="text-sm font-sans text-foreground/80">
          While using the service you agree to our{" "}
          <a
            href="https://rehalm.com/terms-mindcore"
            target="_blank"
            rel="noreferrer noopener"
            className="underline font-semibold"
          >
            Terms
          </a>
          .
        </p>
        <p className="text-sm font-sans text-foreground/80">
          To learn more about how the app works you can visit{" "}
          <a
            href="https://rehalm.com/mindcore"
            target="_blank"
            rel="noreferrer noopener"
            className="underline font-semibold"
          >
            MindCore
          </a>
          .
        </p>
      </div>
    </div>
  )
}

function FeedbackPanelContent() {
  const supabase = createClient()
  const [reason, setReason] = useState<string>("bug")
  const [message, setMessage] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = useCallback(async () => {
    const text = message.trim()
    if (!text || !reason) return
    setSubmitting(true)
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason, message: text }),
      })
      if (res.ok) {
        setSubmitted(true)
        setMessage("")
      }
    } finally {
      setSubmitting(false)
    }
  }, [reason, message])

  if (submitted) {
    return (
      <div className="glass rounded-2xl p-5">
        <p className="text-sm font-sans text-foreground">
          Thank you. We&apos;ve received your feedback and will try to act on it.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5">
        <p className="text-sm font-sans text-muted-foreground mb-4">
          We really appreciate your feedback and will do our best to improve based on it.
        </p>
        <div className="space-y-3">
          <Label className="text-sm font-sans font-medium text-foreground">Select reason</Label>
          <RadioGroup
            value={reason}
            onValueChange={setReason}
            className="flex flex-col gap-2"
          >
            {FEEDBACK_REASONS.map((r) => (
              <div key={r.value} className="flex items-center gap-3">
                <RadioGroupItem value={r.value} id={`feedback-${r.value}`} />
                <Label htmlFor={`feedback-${r.value}`} className="text-sm font-sans text-foreground/90 cursor-pointer">
                  {r.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
        <div className="mt-4 space-y-2">
          <Label htmlFor="feedback-message" className="text-sm font-sans font-medium text-foreground">
            Your feedback
          </Label>
          <Textarea
            id="feedback-message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your feedback…"
            className="min-h-[120px] w-full rounded-xl px-4 py-3 bg-transparent border-foreground/20 resize-none"
            rows={4}
          />
        </div>
        <Button
          type="button"
          size="lg"
          className="w-full mt-4"
          disabled={!message.trim() || submitting}
          onClick={handleSubmit}
        >
          {submitting ? "Sending…" : "Submit"}
        </Button>
      </div>
    </div>
  )
}

const FIND_A_HELPLINE_BASE = "https://findahelpline.com/countries"

function FindAHelplinePanelContent() {
  const supabase = createClient()
  const [countryCode, setCountryCode] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    const run = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        setLoading(false)
        return
      }
      const { data: profile } = await supabase
        .from("profiles")
        .select("country_id")
        .eq("id", user.id)
        .single()
      if (cancelled || !profile?.country_id) {
        setLoading(false)
        return
      }
      const { data: country } = await supabase
        .from("countries")
        .select("flag")
        .eq("id", profile.country_id)
        .single()
      if (!cancelled) {
        setCountryCode(country?.flag ?? null)
        setLoading(false)
      }
    }
    run()
    return () => { cancelled = true }
  }, [])

  const url = countryCode
    ? `${FIND_A_HELPLINE_BASE}/${String(countryCode).toLowerCase()}`
    : "https://findahelpline.com/"

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5">
        <p className="text-sm font-sans text-muted-foreground mb-4">
          Find free, confidential helplines and hotlines in your country.
        </p>
        <Button
          type="button"
          size="lg"
          className="w-full"
          disabled={loading}
          onClick={() => window.open(url, "_blank", "noopener,noreferrer")}
        >
          {loading ? "Loading…" : "Find a helpline"}
        </Button>
      </div>
    </div>
  )
}
