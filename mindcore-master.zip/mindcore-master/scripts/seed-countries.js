/**
 * Generates SQL to insert countries (name, flag) into public.countries.
 * Flag column stores the country code (e.g. AL, CZ) used for findahelpline.com/countries/{code}.
 * Run migration 001_schema.sql first, then:
 *   node scripts/seed-countries.js > supabase/seed-countries.sql
 * Then in Supabase: run seed-countries.sql
 */

const CountryList = require("country-list-with-dial-code-and-flag").default
// withSecondary: false to avoid duplicate country names (e.g. Dominican Republic x3)
const countries = CountryList.getAll({ withSecondary: false })

const values = countries
  .map((c) => {
    const name = c.name.replace(/'/g, "''")
    // Use alpha-2 code (e.g. AL, CZ) for flag column so URLs work: findahelpline.com/countries/{code}
    const flag = (c.code || c.flag || "").replace(/'/g, "''")
    return `('${name}', '${flag}')`
  })
  .join(",\n")

const sql = `-- Seed countries (name, flag). Helplines column defaults to [].
insert into public.countries (name, flag)
values
${values}
on conflict (name) do update set flag = excluded.flag;
`

console.log(sql)
