'use client'
import { useState } from 'react'

const T = { cr2:'#e8e4de',cr3:'#ddd8d0',br:'#2a1a14',br2:'#5a3a2e',br3:'#8a7a74',tr:'#c4724a',trs:'#f5e8e0',bd:'#e0d8d0' }
const STYLES = ['bold','soft','urgency','story']

const inp: React.CSSProperties = { width:'100%',background:T.cr2,border:`1.5px solid ${T.bd}`,borderRadius:12,padding:'10px 14px',fontSize:16,color:T.br,outline:'none',fontFamily:'inherit',boxSizing:'border-box',transition:'border-color .2s' }

function Spin() {
  return <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:10}}><div style={{display:'flex',gap:5}}>{[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:'50%',background:T.tr,animation:`dot .72s ease-in-out infinite ${i*.15}s`}}/>)}</div><div style={{fontSize:13,color:T.br3,fontStyle:'italic'}}>Writing your offer...</div></div>
}

export default function Offer() {
  const [style, setStyle] = useState('bold')
  const [result, setResult] = useState<string|null>(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string|null>(null)
  const [copied, setCopied] = useState(false)

  const go = async () => {
    const prod  = (document.getElementById('of-prod')  as HTMLInputElement)?.value.trim()
    const aud   = (document.getElementById('of-aud')   as HTMLTextAreaElement)?.value.trim()
    const out   = (document.getElementById('of-out')   as HTMLInputElement)?.value.trim()
    const price = (document.getElementById('of-price') as HTMLInputElement)?.value.trim()
    if (!prod) { setErr('Product name is required.'); return }
    setErr(null); setLoading(true); setResult(null)
    try {
      const prompt = `Write a complete high-converting Whop offer page:\n\nProduct: ${prod}\nAudience: ${aud||'not specified'}\nOutcome: ${out||'not specified'}\nPrice: ${price||'not specified'}\nStyle: ${style}\n\nProvide exactly:\n\n**HEADLINE** (under 10 words, outcome-focused)\n\n**SUBHEADLINE** (1 punchy sentence)\n\n**BULLET POINTS** (5x starting with ✓)\n\n**CTA BUTTON** (under 6 words)\n\n**TRUST LINE** (guarantee or social proof)\n\n---\n**CRITIQUE:** What's strongest, and best A/B test to run first.`
      const r = await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:[{role:'user',content:prompt}]})})
      const d = await r.json()
      if (!r.ok||d.error) throw new Error(d.error||'Error')
      setResult(d.text)
    } catch(e:any) { setErr(e.message) }
    setLoading(false)
  }

  const isMob = typeof window !== 'undefined' && window.innerWidth < 768

  const label = (text: string) => (
    <label style={{display:'block',fontSize:11,fontWeight:700,color:T.br2,marginBottom:5,letterSpacing:'.07em',textTransform:'uppercase' as const}}>{text}</label>
  )

  return (
    <div style={{display:'grid',gridTemplateColumns:isMob?'1fr':'320px 1fr',gap:14,height:'100%'}}>
      <div style={{background:'#fff',borderRadius:18,border:`1px solid ${T.bd}`,padding:20,overflowY:'auto'}}>
        <div style={{fontFamily:"'Fraunces',serif",fontWeight:700,fontSize:20,color:T.br,marginBottom:4}}>Offer Builder</div>
        <div style={{fontSize:13,color:T.br3,marginBottom:18,fontWeight:300}}>SELLR writes your complete offer copy.</div>

        <div style={{marginBottom:13}}>{label('Product / Service')}<input id="of-prod" type="text" placeholder="e.g. Fitness coaching community" style={inp} onFocus={e=>e.target.style.borderColor=T.tr} onBlur={e=>e.target.style.borderColor=T.bd}/></div>
        <div style={{marginBottom:13}}>{label('Target Audience')}<textarea id="of-aud" rows={2} placeholder="e.g. Online coaches under $5k/mo" style={{...inp,resize:'vertical',lineHeight:1.5,minHeight:72} as any} onFocus={e=>e.target.style.borderColor=T.tr} onBlur={e=>e.target.style.borderColor=T.bd}/></div>
        <div style={{marginBottom:13}}>{label('Main Outcome')}<input id="of-out" type="text" placeholder="e.g. Double revenue in 60 days" style={inp} onFocus={e=>e.target.style.borderColor=T.tr} onBlur={e=>e.target.style.borderColor=T.bd}/></div>
        <div style={{marginBottom:16}}>{label('Price Point')}<input id="of-price" type="text" placeholder="e.g. $47/mo, $197 one-time" style={inp} onFocus={e=>e.target.style.borderColor=T.tr} onBlur={e=>e.target.style.borderColor=T.bd}/></div>

        <div style={{marginBottom:18}}>
          {label('Copy Style')}
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:7}}>
            {STYLES.map(s=>(
              <button key={s} onClick={()=>setStyle(s)} style={{padding:'9px 6px',borderRadius:10,fontFamily:'inherit',border:`1.5px solid ${style===s?T.tr:T.bd}`,background:style===s?T.trs:T.cr2,color:style===s?T.tr:T.br3,fontSize:13,fontWeight:500,cursor:'pointer',textTransform:'capitalize',transition:'all .15s'}}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {err && <div onClick={()=>setErr(null)} style={{padding:'9px 13px',borderRadius:10,background:'rgba(239,68,68,.08)',border:'1px solid rgba(239,68,68,.2)',color:'#dc2626',fontSize:13,marginBottom:12,cursor:'pointer'}}>⚠️ {err}</div>}
        <button onClick={go} disabled={loading} style={{width:'100%',padding:13,borderRadius:999,background:loading?T.cr3:T.tr,color:'#fff',fontWeight:700,fontSize:14.5,border:'none',cursor:loading?'not-allowed':'pointer',transition:'all .22s'}}>
          {loading?'Writing...' : 'Generate Offer Copy →'}
        </button>
      </div>

      <div style={{background:'#fff',borderRadius:18,border:`1px solid ${T.bd}`,padding:20,display:'flex',flexDirection:'column',overflowY:'auto',minHeight:260}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16,flexShrink:0}}>
          <div style={{fontFamily:"'Fraunces',serif",fontWeight:700,fontSize:20,color:T.br}}>Generated Copy</div>
          {result && <button onClick={()=>{navigator.clipboard?.writeText(result).catch(()=>{});setCopied(true);setTimeout(()=>setCopied(false),2000)}} style={{padding:'4px 10px',borderRadius:7,background:copied?'rgba(74,222,128,.1)':'rgba(42,26,20,.06)',border:`1px solid ${copied?'rgba(74,222,128,.3)':T.bd}`,fontSize:11,color:copied?'#16a34a':T.br3,cursor:'pointer',fontFamily:'inherit'}}>{copied?'✓ Copied':'⎘ Copy'}</button>}
        </div>
        {loading && <Spin/>}
        {result && !loading && <div style={{fontSize:13.5,color:T.br,lineHeight:1.8,whiteSpace:'pre-wrap',fontWeight:300}}>{result}</div>}
        {!result && !loading && <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:6}}><div style={{fontFamily:"'Fraunces',serif",fontStyle:'italic',fontSize:18,color:'rgba(42,26,20,.18)',textAlign:'center'}}>Your offer copy appears here</div><div style={{fontSize:13,color:'rgba(42,26,20,.12)'}}>Fill the form and click Generate</div></div>}
      </div>
    </div>
  )
}
