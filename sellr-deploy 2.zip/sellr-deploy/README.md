# SELLR.ai

AI Sales Coach for Whop sellers — Next.js 14, Google OAuth, Claude AI.

## Quick Deploy (5 min)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "SELLR.ai init"
git remote add origin https://github.com/YOUR_USER/sellr-ai.git
git push -u origin main
```

### 2. Deploy to Vercel
1. Go to vercel.com → Add New Project → Import from GitHub
2. Select `sellr-ai` → Framework: **Next.js** (auto-detected)
3. Click Deploy → wait → then go to **Settings → Environment Variables**

### 3. Add Environment Variables
```
ANTHROPIC_API_KEY     sk-ant-api03-SSFnr3To1p5k...
NEXTAUTH_SECRET       (run: openssl rand -base64 32)
NEXTAUTH_URL          https://your-project.vercel.app
GOOGLE_CLIENT_ID      xxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET  GOCSPX-xxx
```
→ Then: Deployments → **Redeploy**

---

## Google OAuth Setup (Required for Google sign in)

1. Go to **console.cloud.google.com**
2. New project → APIs & Services → Credentials
3. Create → OAuth 2.0 Client ID → Web application
4. Authorized redirect URIs:
   ```
   http://localhost:3000/api/auth/callback/google
   https://YOUR-SITE.vercel.app/api/auth/callback/google
   ```
5. Copy Client ID + Secret → paste into Vercel env vars

---

## Local Development
```bash
npm install
cp .env.example .env.local
# Fill in values in .env.local
npm run dev
# Open http://localhost:3000
```

---

## Features
- Google OAuth (one-click)
- Email/password login (demo — any credentials)
- Claude claude-opus-4-6 AI chat
- Offer Builder — AI writes full copy
- Store Analyzer — AI revenue diagnosis  
- Voice input 🎤 + Text-to-speech 🔊
- Copy button on all AI responses
- Mobile responsive
- API key secured server-side (never in browser)
- Session: JWT, 30-day
