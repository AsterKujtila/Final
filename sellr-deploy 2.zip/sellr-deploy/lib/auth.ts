import type { NextAuthOptions } from 'next-auth'
import GoogleProvider from 'next-auth/providers/google'
import CredentialsProvider from 'next-auth/providers/credentials'

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    CredentialsProvider({
      name: 'Email',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(creds) {
        if (!creds?.email?.includes('@')) return null
        if ((creds?.password?.length ?? 0) < 4) return null
        const name = creds.email.split('@')[0]
        return {
          id: creds.email,
          name: name.charAt(0).toUpperCase() + name.slice(1),
          email: creds.email,
          image: null,
        }
      },
    }),
  ],
  pages: { signIn: '/login', error: '/login' },
  callbacks: {
    async jwt({ token, user, account }) {
      if (user) token.user = user
      if (account) token.provider = account.provider
      return token
    },
    async session({ session, token }) {
      if (token.provider) session.provider = token.provider as string
      return session
    },
    async redirect({ url, baseUrl }) {
      if (url.startsWith('/')) return `${baseUrl}${url}`
      if (url.startsWith(baseUrl)) return url
      return `${baseUrl}/dashboard`
    },
  },
  session: { strategy: 'jwt', maxAge: 30 * 24 * 60 * 60 },
}
